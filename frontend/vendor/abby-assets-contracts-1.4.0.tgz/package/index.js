export const APPEARANCE_FIELDS = Object.freeze(['body', 'skin', 'outfit', 'head', 'hair_style', 'hair_color', 'face_style', 'face_color']);
export const CONFIGURATION_SCHEMA_VERSION = 2;
export const RELEASE_SCHEMA_VERSION = 1;
export const ASSET_PACK_SCHEMA_VERSION = 1;
export const APPEARANCE_BINDINGS_SCHEMA_VERSION = 1;
export const COMPANION_LIFECYCLE_STAGES = Object.freeze(['baby', 'middle', 'grown']);
export const ASSET_KINDS = Object.freeze(['avatar', 'creature', 'mount', 'prop', 'environment', 'equipment', 'animation-library', 'image']);
export const ASSET_CAPABILITIES = Object.freeze(['model', 'skinned', 'animated', 'image']);
const sha256 = /^[a-f0-9]{64}$/;
const id = /^[a-zA-Z0-9][a-zA-Z0-9._-]*$/;
const validId = value => typeof value === 'string' && id.test(value);
const fail = message => { throw new Error(`Asset contract: ${message}`); };
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export function isSafeRelativePath(value) {
  return typeof value === 'string' && value.length > 0 && !value.includes('\\') && !value.includes(':') && !value.includes('%') && !value.startsWith('/') && value.split('/').every(part => part && part !== '.' && part !== '..' && /^[a-zA-Z0-9._-]+$/.test(part));
}
export function validateManifest(value) {
  if (!plain(value) || value.schema_version !== 1) fail('unsupported release schema');
  if (!validId(value.family_id) || typeof value.release_version !== 'string' || !/^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/.test(value.release_version)) fail('invalid release identity');
  const privateMetadata = entry => {
    if (Array.isArray(entry)) { entry.forEach(privateMetadata); return; }
    if (plain(entry)) { for (const [key, child] of Object.entries(entry)) { if (/^(source(?:_|$)|authoring$|sourcePaths$)/i.test(key)) fail('release contains private authoring metadata'); privateMetadata(child); } }
    else if (typeof entry === 'string' && (/^[a-zA-Z]:[\\/]/.test(entry) || /\.(?:blend[12]?|zip|fbx|unitypackage)(?:$|[/?])/i.test(entry))) fail('release contains an authoring path');
  };
  privateMetadata(value);
  if (!plain(value.appearance) || value.appearance.family_id !== value.family_id) fail('appearance family does not match release');
  if (!Array.isArray(value.files) || !value.files.length) fail('release has no files');
  const files = new Map();
  for (const file of value.files) {
    if (!isSafeRelativePath(file.path) || !sha256.test(file.sha256) || !Number.isSafeInteger(file.bytes) || file.bytes < 1 || files.has(file.path)) fail('invalid or duplicate release file');
    if (!/^objects\/[a-f0-9]{64}\.(?:glb|png)$/.test(file.path) || file.path !== `objects/${file.sha256}.${file.path.split('.').at(-1)}`) fail('file is not content addressed runtime media');
    if (!['model/gltf-binary', 'image/png'].includes(file.media_type)) fail('unsupported runtime media type');
    if ((file.path.endsWith('.glb') ? 'model/gltf-binary' : 'image/png') !== file.media_type) fail('runtime media type does not match extension');
    files.set(file.path, file);
  }
  const catalog = value.appearance;
  if (!Array.isArray(catalog.rig_adapter_ids) || !catalog.rig_adapter_ids.length || catalog.rig_adapter_ids.some(value => !validId(value)) || new Set(catalog.rig_adapter_ids).size !== catalog.rig_adapter_ids.length) fail('missing, invalid or duplicate compatible rigs');
  if (!plain(catalog.selectors) || !plain(catalog.defaults)) fail('missing appearance choices');
  for (const field of APPEARANCE_FIELDS) {
    const choices = catalog.selectors[field];
    if (!Array.isArray(choices) || !choices.length || choices.some(option => !plain(option) || !validId(option.id)) || new Set(choices.map(option => option.id)).size !== choices.length) fail(`invalid or duplicate ${field} choices`);
    if (!validId(catalog.defaults[field]) || !choices.some(option => option.id === catalog.defaults[field])) fail(`invalid ${field} default`);
  }
  const reference = item => {
    if (!plain(item) || !validId(item.id)) fail('invalid catalog entry');
    const file = files.get(item.file || item.path);
    if (!file || item.sha256 !== file.sha256 || item.bytes !== file.bytes) fail(`untracked or mismatched file for ${item.id}`);
    if (item.path && item.path !== item.file) fail(`inconsistent file aliases for ${item.id}`);
  };
  for (const key of ['base_variants', 'modules', 'equipment_overrides', 'textures', 'projectiles']) {
    if (!Array.isArray(catalog[key])) fail(`missing ${key}`);
    const seen = new Set();
    for (const item of catalog[key]) { reference(item); if (seen.has(item.id)) fail(`duplicate ${key} id`); seen.add(item.id); }
  }
  if (!catalog.base_variants.length) fail('release has no prepared bases');
  const combinations = new Set();
  for (const variant of catalog.base_variants) {
    if (!validId(variant.rig_adapter_id) || !catalog.rig_adapter_ids.includes(variant.rig_adapter_id)) fail('base has an unapproved rig adapter');
    for (const field of ['body', 'skin', 'outfit']) if (!validId(variant[field]) || !catalog.selectors[field].some(option => option.id === variant[field])) fail(`base has an unknown ${field} choice`);
    const combination = JSON.stringify([variant.body, variant.skin, variant.outfit]);
    if (combinations.has(combination)) fail('duplicate prepared base combination'); combinations.add(combination);
  }
  for (const module of catalog.modules) if (!['head', 'hair', 'face'].includes(module.category) || typeof module.attachment_node !== 'string' || !module.attachment_node.length) fail('invalid fitted module attachment');
  if (!Array.isArray(value.equipment_catalogs)) fail('missing equipment catalogs');
  for (const entry of value.equipment_catalogs) {
    if (!validId(entry.rig_adapter_id) || !catalog.rig_adapter_ids.includes(entry.rig_adapter_id) || !Array.isArray(entry.items)) fail('equipment has an unapproved adapter');
    const seen = new Set();
    for (const item of entry.items) { reference(item); if (seen.has(item.id) || !validId(item.slot) || typeof item.attachment_node !== 'string' || !item.attachment_node.length) fail('invalid equipment slot or duplicate id'); seen.add(item.id); }
  }
  if (new Set(value.equipment_catalogs.map(entry => entry.rig_adapter_id)).size !== value.equipment_catalogs.length) fail('duplicate equipment adapter');
  if (!plain(value.animations?.actions) || !Array.isArray(value.animations?.clips)) fail('missing animation semantics');
  const clipNames = new Set();
  for (const clip of value.animations.clips) {
    if (!plain(clip) || typeof clip.name !== 'string' || !clip.name.length || clipNames.has(clip.name) || !Number.isFinite(clip.duration) || clip.duration < 0 || typeof clip.loop !== 'boolean' || !['in-place', 'vertical', 'source'].includes(clip.root_motion)) fail('invalid or duplicate animation clip');
    clipNames.add(clip.name);
  }
  for (const [action, name] of Object.entries(value.animations.actions)) if (!validId(action) || typeof name !== 'string' || !clipNames.has(name)) fail('animation action names an unknown clip');
  for (const portrait of value.portraits || []) reference(portrait);
  return value;
}
const LIBRARY_MEDIA = Object.freeze({ glb: 'model/gltf-binary', png: 'image/png', fbx: 'application/octet-stream', json: 'application/json' });
export function validateFileLibraryManifest(value) {
  if (!plain(value) || value.schema_version !== 1 || value.kind !== 'file-library') fail('unsupported file library schema');
  if (Object.keys(value).some(key => !['schema_version', 'kind', 'family_id', 'release_version', 'label', 'entries', 'files'].includes(key))) fail('file library contains unsupported metadata');
  if (typeof value.family_id !== 'string' || !/^[a-z0-9][a-z0-9._-]*$/.test(value.family_id) || typeof value.release_version !== 'string' || !/^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/.test(value.release_version)
    || typeof value.label !== 'string' || !value.label.length || /[a-zA-Z]:[\\/]|\.(?:zip|blend[12]?|unitypackage)(?:$|[/?])/i.test(value.label)) fail('invalid file library identity');
  if (!Array.isArray(value.files) || !value.files.length || !Array.isArray(value.entries) || !value.entries.length) fail('file library has no entries or files');
  const files = new Map(), ids = new Set(), paths = new Set(), references = new Set();
  for (const file of value.files) {
    if (!plain(file) || Object.keys(file).some(key => !['path', 'sha256', 'bytes', 'media_type'].includes(key))
      || !isSafeRelativePath(file.path) || typeof file.sha256 !== 'string' || !sha256.test(file.sha256)
      || !Number.isSafeInteger(file.bytes) || file.bytes < 1 || files.has(file.path)) fail('invalid or duplicate file library payload');
    const extension = file.path.split('.').at(-1);
    if (!Object.hasOwn(LIBRARY_MEDIA, extension) || file.path !== `objects/${file.sha256}.${extension}` || file.media_type !== LIBRARY_MEDIA[extension]) fail('file library media is not content addressed');
    files.set(file.path, file);
  }
  for (const entry of value.entries) {
    if (!plain(entry) || Object.keys(entry).some(key => !['id', 'runtime_path', 'file', 'sha256', 'bytes', 'media_type'].includes(key))
      || !validId(entry.id) || ids.has(entry.id) || !isSafeRelativePath(entry.runtime_path)
      || entry.runtime_path.split('/').some(part => /\.$/.test(part) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part))) fail('invalid file library runtime mapping');
    const runtimePath = entry.runtime_path.toLowerCase(), file = files.get(entry.file);
    if (paths.has(runtimePath) || !file || entry.sha256 !== file.sha256 || entry.bytes !== file.bytes || entry.media_type !== file.media_type
      || entry.runtime_path.split('.').at(-1) !== entry.file.split('.').at(-1)) fail('duplicate or mismatched file library mapping');
    ids.add(entry.id); paths.add(runtimePath); references.add(entry.file);
  }
  for (const runtimePath of paths) {
    const parts = runtimePath.split('/');
    for (let count = 1; count < parts.length; count++) if (paths.has(parts.slice(0, count).join('/'))) fail('file library has conflicting file and directory mappings');
  }
  if (references.size !== files.size) fail('file library contains an unreferenced payload');
  return value;
}
export function validateAnyManifest(value) {
  if (value?.kind === 'file-library') return validateFileLibraryManifest(value);
  if (value?.kind === 'asset-pack') return validateAssetPackManifest(value);
  return validateManifest(value);
}

/** A family is the delivery/compatibility namespace. Asset and variant IDs are
 * scoped to it; relationship edges describe authored lineage, never gameplay. */
export function validateAssetPackManifest(value) {
  const object = (entry, keys, required = keys) => {
    if (!plain(entry) || Object.keys(entry).some(key => !keys.includes(key))
      || required.some(key => !Object.hasOwn(entry, key))) fail('asset pack contains missing or unsupported fields');
  };
  const text = entry => typeof entry === 'string' && entry.length > 0 && !/[\u0000-\u001f\u007f]/.test(entry);
  const privateMetadata = entry => {
    if (Array.isArray(entry)) { entry.forEach(privateMetadata); return; }
    if (plain(entry)) {
      for (const [key, child] of Object.entries(entry)) {
        if (/^(source(?:_|$)|authoring$|sourcePaths$)/i.test(key)) fail('asset pack contains private authoring metadata');
        privateMetadata(child);
      }
    } else if (typeof entry === 'string' && (/^[a-zA-Z]:[\\/]/.test(entry) || /\.(?:blend[12]?|zip|fbx|unitypackage)(?:$|[/?])/i.test(entry))) fail('asset pack contains an authoring path');
  };
  const bounds = entry => {
    if (entry === null) return;
    object(entry, ['min', 'max']);
    if (![entry.min, entry.max].every(vector => Array.isArray(vector) && vector.length === 3 && vector.every(Number.isFinite))
      || entry.min.some((number, axis) => number > entry.max[axis])) fail('invalid asset bounds');
  };
  const animations = entry => {
    if (entry === null) return;
    object(entry, ['root_node', 'actions', 'clips']);
    if (entry.root_node !== null && !text(entry.root_node)) fail('invalid asset animation root');
    if (!plain(entry.actions) || !Array.isArray(entry.clips) || !entry.clips.length) fail('missing asset animation semantics');
    const clips = new Set();
    for (const clip of entry.clips) {
      object(clip, ['name', 'duration', 'loop', 'root_motion', 'bounds']);
      if (!text(clip.name) || clips.has(clip.name)
        || clip.duration !== null && (!Number.isFinite(clip.duration) || clip.duration < 0)
        || clip.loop !== null && typeof clip.loop !== 'boolean'
        || clip.root_motion !== null && !['in-place', 'vertical', 'source'].includes(clip.root_motion)) fail('invalid or duplicate asset animation clip');
      bounds(clip.bounds); clips.add(clip.name);
    }
    for (const [action, clip] of Object.entries(entry.actions)) if (!validId(action) || typeof clip !== 'string' || !clips.has(clip)) fail('asset action names an unknown clip');
  };
  object(value, ['schema_version', 'kind', 'family_id', 'release_version', 'label', 'assets', 'relationships', 'files', 'appearance_bindings'], ['schema_version', 'kind', 'family_id', 'release_version', 'label', 'assets', 'relationships', 'files']);
  if (value.schema_version !== 1 || value.kind !== 'asset-pack') fail('unsupported asset pack schema');
  if (typeof value.family_id !== 'string' || !/^[a-z0-9][a-z0-9._-]*$/.test(value.family_id)
    || typeof value.release_version !== 'string' || !/^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/.test(value.release_version)
    || !text(value.label)) fail('invalid asset pack identity');
  privateMetadata(value);
  if (!Array.isArray(value.files) || !value.files.length || !Array.isArray(value.assets) || !value.assets.length
    || !Array.isArray(value.relationships)) fail('asset pack has no assets/files or relationship list');
  const files = new Map(), assets = new Map(), references = new Set();
  for (const file of value.files) {
    object(file, ['path', 'sha256', 'bytes', 'media_type']);
    if (!isSafeRelativePath(file.path) || !sha256.test(file.sha256) || !Number.isSafeInteger(file.bytes)
      || file.bytes < 1 || files.has(file.path)) fail('invalid or duplicate asset pack file');
    const extension = file.path.split('.').at(-1);
    if (!['glb', 'png'].includes(extension) || file.path !== `objects/${file.sha256}.${extension}`
      || file.media_type !== (extension === 'glb' ? 'model/gltf-binary' : 'image/png')) fail('asset pack media is not content addressed GLB/PNG');
    files.set(file.path, file);
  }
  for (const asset of value.assets) {
    object(asset, ['id', 'label', 'kind', 'capabilities', 'default_variant', 'variants']);
    if (!validId(asset.id) || assets.has(asset.id) || !text(asset.label) || !ASSET_KINDS.includes(asset.kind)
      || !Array.isArray(asset.capabilities) || asset.capabilities.some(capability => !ASSET_CAPABILITIES.includes(capability))
      || new Set(asset.capabilities).size !== asset.capabilities.length || !validId(asset.default_variant)
      || !Array.isArray(asset.variants) || !asset.variants.length) fail('invalid or duplicate typed asset');
    if (asset.kind === 'image' ? asset.capabilities.length !== 1 || asset.capabilities[0] !== 'image' : asset.capabilities.includes('image')) fail('image capability does not match asset kind');
    const variants = new Set();
    for (const variant of asset.variants) {
      object(variant, ['id', 'label', 'file', 'rig_adapter_id', 'bounds', 'animations']);
      const file = files.get(variant.file);
      if (!validId(variant.id) || variants.has(variant.id) || !text(variant.label) || !file
        || (asset.kind === 'image' ? file.media_type !== 'image/png' : file.media_type !== 'model/gltf-binary')
        || variant.rig_adapter_id !== null && !validId(variant.rig_adapter_id)) fail('invalid or duplicate asset variant');
      bounds(variant.bounds); animations(variant.animations);
      if (asset.capabilities.includes('animated') && variant.animations === null) fail('animated capability requires clip metadata');
      if (asset.kind === 'image' && (variant.rig_adapter_id !== null || variant.animations !== null || variant.bounds !== null)) fail('image variants cannot declare 3D features');
      variants.add(variant.id); references.add(variant.file);
    }
    if (!variants.has(asset.default_variant)) fail('asset default names an unknown variant');
    assets.set(asset.id, asset);
  }
  if (references.size !== files.size) fail('asset pack contains an unreferenced file');
  const edges = new Set(), adjacency = new Map([...assets.keys()].map(assetId => [assetId, []]));
  for (const relationship of value.relationships) {
    object(relationship, ['type', 'from_asset_id', 'to_asset_id', 'transition'], ['type', 'from_asset_id', 'to_asset_id']);
    const from = relationship.from_asset_id, to = relationship.to_asset_id, edge = JSON.stringify([from, to]);
    if (relationship.type !== 'evolution' || !assets.has(from) || !assets.has(to) || from === to || edges.has(edge)) fail('invalid or duplicate descriptive evolution relationship');
    if (relationship.transition !== undefined) {
      const transition = relationship.transition;
      object(transition, ['asset_id', 'variant_id', 'action']);
      if (!validId(transition.asset_id) || !validId(transition.variant_id) || !validId(transition.action) || [from, to].includes(transition.asset_id)) fail('invalid evolution transition selection');
      const transitionAsset = assets.get(transition.asset_id);
      const variant = transitionAsset?.variants.find(item => item.id === transition.variant_id);
      const clip = variant?.animations?.actions[transition.action];
      if (!transitionAsset?.capabilities.includes('animated') || !clip || !variant.animations.clips.some(item => item.name === clip && item.loop === false)) fail('evolution transition must reference an existing single-shot action');
    }
    edges.add(edge); adjacency.get(from).push(to);
  }
  const visiting = new Set(), visited = new Set();
  const visit = assetId => {
    if (visiting.has(assetId)) fail('descriptive evolution relationships contain a cycle');
    if (visited.has(assetId)) return;
    visiting.add(assetId); adjacency.get(assetId).forEach(visit); visiting.delete(assetId); visited.add(assetId);
  };
  assets.forEach((_, assetId) => visit(assetId));
  if (value.appearance_bindings !== undefined) {
    const bindings = value.appearance_bindings;
    object(bindings, ['schema_version', 'stages', 'transitions']);
    if (bindings.schema_version !== APPEARANCE_BINDINGS_SCHEMA_VERSION || !Array.isArray(bindings.stages) || !bindings.stages.length || !Array.isArray(bindings.transitions)) fail('unsupported or incomplete appearance bindings');
    const stages = new Map(), motions = new Set(), transitions = new Set();
    const stageKey = entry => JSON.stringify([entry.species_slug, entry.potion_slug, entry.lifecycle_stage]);
    const target = (entry, image = false) => {
      const asset = assets.get(entry.asset_id), variant = asset?.variants.find(item => item.id === entry.variant_id);
      if (!variant || image && asset.kind !== 'image'
        || !image && (!asset.capabilities.includes('model') || !asset.capabilities.includes('animated') || !Object.hasOwn(variant.animations?.actions || {}, entry.action))) fail('appearance binding names an incompatible asset, variant or action');
      return { asset, variant };
    };
    for (const entry of bindings.stages) {
      object(entry, ['species_slug', 'potion_slug', 'lifecycle_stage', 'motion', 'asset_id', 'variant_id', 'action', 'portrait_asset_id', 'portrait_variant_id']);
      if (['species_slug', 'potion_slug', 'motion', 'asset_id', 'variant_id', 'action', 'portrait_asset_id', 'portrait_variant_id'].some(key => !validId(entry[key])) || !COMPANION_LIFECYCLE_STAGES.includes(entry.lifecycle_stage)) fail('invalid companion appearance identity');
      const { asset } = target(entry);
      if (asset.kind !== 'creature') fail('companion appearance must reference a creature');
      target({ asset_id: entry.portrait_asset_id, variant_id: entry.portrait_variant_id }, true);
      const stage = stageKey(entry), motion = JSON.stringify([stage, entry.motion]);
      if (motions.has(motion)) fail('duplicate companion appearance motion binding');
      const identity = JSON.stringify([entry.asset_id, entry.portrait_asset_id, entry.portrait_variant_id]);
      if (stages.has(stage) && stages.get(stage).identity !== identity) fail('companion appearance changes identity or portrait between motions');
      motions.add(motion); stages.set(stage, { identity, asset_id: entry.asset_id });
    }
    for (const entry of bindings.transitions) {
      object(entry, ['species_slug', 'potion_slug', 'from_stage', 'to_stage', 'asset_id', 'variant_id', 'action']);
      if (['species_slug', 'potion_slug', 'asset_id', 'variant_id', 'action'].some(key => !validId(entry[key]))
        || ![entry.from_stage, entry.to_stage].every(stage => COMPANION_LIFECYCLE_STAGES.includes(stage)) || entry.from_stage === entry.to_stage) fail('invalid companion appearance transition identity');
      const from = stages.get(stageKey({ ...entry, lifecycle_stage: entry.from_stage })), to = stages.get(stageKey({ ...entry, lifecycle_stage: entry.to_stage }));
      const { variant } = target(entry), clip = variant.animations.clips.find(clip => clip.name === variant.animations.actions[entry.action]);
      if (!from || !to || [from.asset_id, to.asset_id].includes(entry.asset_id) || clip?.loop !== false) fail('appearance transition requires two bound stages and a separate single-shot payload');
      const key = JSON.stringify([entry.species_slug, entry.potion_slug, entry.from_stage, entry.to_stage]);
      if (transitions.has(key)) fail('duplicate companion appearance transition binding');
      transitions.add(key);
    }
  }
  return value;
}

export function resolveAssetVariant(manifest, selection) {
  validateAssetPackManifest(manifest);
  if (!plain(selection) || Object.keys(selection).some(key => !['family_id', 'asset_id', 'variant_id'].includes(key))
    || !validId(selection.asset_id) || selection.family_id !== undefined && selection.family_id !== manifest.family_id
    || selection.variant_id !== undefined && !validId(selection.variant_id)) fail('asset selection family or identity is incompatible');
  const asset = manifest.assets.find(entry => entry.id === selection.asset_id);
  if (!asset) fail('asset selection names an unknown asset');
  const variant = asset.variants.find(entry => entry.id === (selection.variant_id ?? asset.default_variant));
  if (!variant) fail('asset selection names an unknown variant');
  return { asset, variant, file: manifest.files.find(entry => entry.path === variant.file) };
}

export function resolveEvolution(manifest, fromAssetId, toAssetId) {
  validateAssetPackManifest(manifest);
  const relationship = manifest.relationships.find(edge => edge.from_asset_id === fromAssetId && edge.to_asset_id === toAssetId);
  if (!relationship?.transition) fail('no authored evolution transition for these stages');
  const { asset_id, variant_id, action } = relationship.transition;
  return { relationship, selection: { family_id: manifest.family_id, asset_id, variant_id }, action };
}

const appearanceQuery = (manifest, selection, fields) => {
  validateAssetPackManifest(manifest);
  if (!plain(selection) || Object.keys(selection).some(key => !['family_id', ...fields].includes(key))
    || fields.some(key => !validId(selection[key])) || selection.family_id !== undefined && selection.family_id !== manifest.family_id) fail('appearance selection family or identity is incompatible');
};
const boundSelection = (manifest, entry) => ({ family_id: manifest.family_id, asset_id: entry.asset_id, variant_id: entry.variant_id });

/** Resolve an exact authored appearance/motion tuple. No Base/idle fallback. */
export function resolveCompanionAppearance(manifest, selection) {
  const fields = ['species_slug', 'potion_slug', 'lifecycle_stage', 'motion'];
  appearanceQuery(manifest, selection, fields);
  const binding = manifest.appearance_bindings?.stages.find(entry => fields.every(key => entry[key] === selection[key]));
  if (!binding) fail('no authored companion appearance for this exact stage and motion');
  const modelSelection = boundSelection(manifest, binding), portraitSelection = { family_id: manifest.family_id, asset_id: binding.portrait_asset_id, variant_id: binding.portrait_variant_id };
  return { binding, selection: modelSelection, action: binding.action, ...resolveAssetVariant(manifest, modelSelection), portrait: { selection: portraitSelection, ...resolveAssetVariant(manifest, portraitSelection) } };
}

/** Resolve the treatment baked into both forms of one prepared transition. */
export function resolveAppearanceTransition(manifest, selection) {
  const fields = ['species_slug', 'potion_slug', 'from_stage', 'to_stage'];
  appearanceQuery(manifest, selection, fields);
  const binding = manifest.appearance_bindings?.transitions.find(entry => fields.every(key => entry[key] === selection[key]));
  if (!binding) fail('no authored appearance transition for these exact stages');
  const modelSelection = boundSelection(manifest, binding);
  return { binding, selection: modelSelection, action: binding.action, ...resolveAssetVariant(manifest, modelSelection) };
}
export function defaultConfiguration(manifest) {
  return { schema_version: 2, family_id: manifest.family_id, appearance: { ...manifest.appearance.defaults }, slots: {}, emission_enabled: Boolean(manifest.appearance.emission?.default_enabled) };
}
export function validateConfiguration(value, manifest) {
  if (!plain(value) || value.schema_version !== 2 || value.family_id !== manifest.family_id) fail('configuration family or schema is incompatible');
  for (const key of Object.keys(value)) if (!['schema_version', 'family_id', 'appearance', 'slots', 'emission_enabled'].includes(key)) fail(`configuration contains unsupported field ${key}`);
  if (!plain(value.appearance) || !plain(value.slots) || typeof value.emission_enabled !== 'boolean') fail('configuration is incomplete');
  for (const field of Object.keys(value.appearance)) if (!APPEARANCE_FIELDS.includes(field)) fail(`unknown appearance field ${field}`);
  const config = defaultConfiguration(manifest);
  for (const field of APPEARANCE_FIELDS) {
    const choice = value.appearance[field] ?? config.appearance[field];
    if (!manifest.appearance.selectors[field]?.some(option => option.id === choice)) fail(`unknown ${field} choice`);
    config.appearance[field] = choice;
  }
  config.slots = { ...value.slots }; config.emission_enabled = value.emission_enabled;
  const variant = manifest.appearance.base_variants.find(item => ['body', 'skin', 'outfit'].every(field => item[field] === config.appearance[field]));
  if (!variant) fail('no prepared base for these choices');
  const catalog = manifest.equipment_catalogs.find(entry => entry.rig_adapter_id === variant.rig_adapter_id);
  for (const [slot, itemId] of Object.entries(config.slots)) if (!catalog?.items.some(item => item.id === itemId && item.slot === slot)) fail(`incompatible equipment in ${slot}`);
  return config;
}
export function resolveConfiguration(manifest, value = defaultConfiguration(manifest)) {
  const configuration = validateConfiguration(value, manifest), catalog = manifest.appearance;
  const variant = catalog.base_variants.find(item => ['body', 'skin', 'outfit'].every(field => item[field] === configuration.appearance[field]));
  const equipmentCatalog = manifest.equipment_catalogs.find(entry => entry.rig_adapter_id === variant.rig_adapter_id);
  const equipment = Object.values(configuration.slots).map(itemId => equipmentCatalog.items.find(item => item.id === itemId));
  const effectiveAppearance = { ...configuration.appearance };
  if (effectiveAppearance.hair_style !== 'none') {
    const override = equipment.find(item => item.hair_style_override);
    if (override) effectiveAppearance.hair_style = override.hair_style_override;
  }
  const modules = Object.entries({ head: ['head', 'skin'], face: ['face_style', 'face_color'], hair: ['hair_style', 'hair_color'] }).flatMap(([category, fields]) => {
    if (category === 'hair' && effectiveAppearance.hair_style === 'none') return [];
    const item = catalog.modules.find(item => item.category === category && fields.every(field => item[field] === effectiveAppearance[field]));
    if (!item) fail(`no prepared ${category} module for these choices`);
    return [item];
  });
  return { configuration, variant, equipment, modules, effectiveAppearance, catalog };
}
export function resolveReleaseUrl(base, file) {
  if (!isSafeRelativePath(file)) fail('unsafe release file path');
  return `${String(base).replace(/\/?$/, '/')}${file}`;
}
