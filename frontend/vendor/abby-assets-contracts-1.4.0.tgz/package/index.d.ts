export type AppearanceField = 'body'|'skin'|'outfit'|'head'|'hair_style'|'hair_color'|'face_style'|'face_color';
export type Appearance = Record<AppearanceField,string>;
export interface AvatarConfiguration { schema_version:2; family_id:string; appearance:Appearance; slots:Record<string,string>; emission_enabled:boolean }
export interface RuntimeFile { path:string; sha256:string; bytes:number; media_type:'model/gltf-binary'|'image/png' }
export interface CatalogItem { id:string; file:string; path:string; sha256:string; bytes:number; label?:string; rig_adapter_id?:string; attachment_node?:string; hide_nodes?:string[]; [key:string]:unknown }
export interface AppearanceCatalog { schema_version:1; family_id:string; label:string; rig_adapter_ids:string[]; defaults:Appearance; selectors:Record<AppearanceField,{id:string;label:string}[]>; replacement_nodes:Record<string,string[]>; base_variants:CatalogItem[]; modules:CatalogItem[]; equipment_overrides:CatalogItem[]; textures:CatalogItem[]; projectiles:CatalogItem[]; emission:{default_enabled:boolean;maps:CatalogItem[]} }
export interface ReleaseManifest { schema_version:1; family_id:string; release_version:string; label:string; appearance:AppearanceCatalog; equipment_catalogs:{rig_adapter_id:string;items:CatalogItem[]}[]; animations:{actions:Record<string,string>;root_node:string;clips:{name:string;duration:number;loop:boolean;root_motion:'in-place'|'vertical'|'source'}[]}; files:RuntimeFile[]; portraits?:CatalogItem[] }
export interface LibraryRuntimeFile { path:string; sha256:string; bytes:number; media_type:'model/gltf-binary'|'image/png'|'application/octet-stream'|'application/json' }
export interface FileLibraryEntry { id:string; runtime_path:string; file:string; sha256:string; bytes:number; media_type:LibraryRuntimeFile['media_type'] }
export interface FileLibraryManifest { schema_version:1; kind:'file-library'; family_id:string; release_version:string; label:string; entries:FileLibraryEntry[]; files:LibraryRuntimeFile[] }
export type AssetKind = 'avatar'|'creature'|'mount'|'prop'|'environment'|'equipment'|'animation-library'|'image';
export type AssetCapability = 'model'|'skinned'|'animated'|'image';
export interface AssetBounds { min:[number,number,number]; max:[number,number,number] }
export interface AssetClip { name:string; duration:number|null; loop:boolean|null; root_motion:'in-place'|'vertical'|'source'|null; bounds:AssetBounds|null }
export interface AssetAnimations { root_node:string|null; actions:Record<string,string>; clips:AssetClip[] }
export interface AssetVariant { id:string; label:string; file:string; rig_adapter_id:string|null; bounds:AssetBounds|null; animations:AssetAnimations|null }
export interface TypedAsset { id:string; label:string; kind:AssetKind; capabilities:AssetCapability[]; default_variant:string; variants:AssetVariant[] }
export interface AssetRelationship { type:'evolution'; from_asset_id:string; to_asset_id:string; transition?:{asset_id:string;variant_id:string;action:string} }
export type CompanionLifecycleStage = 'baby'|'middle'|'grown';
export interface CompanionAppearanceSelection { family_id?:string; species_slug:string; potion_slug:string; lifecycle_stage:CompanionLifecycleStage; motion:string }
export interface AppearanceTransitionSelection { family_id?:string; species_slug:string; potion_slug:string; from_stage:CompanionLifecycleStage; to_stage:CompanionLifecycleStage }
export interface CompanionAppearanceBinding extends Omit<CompanionAppearanceSelection,'family_id'> { asset_id:string; variant_id:string; action:string; portrait_asset_id:string; portrait_variant_id:string }
export interface AppearanceTransitionBinding extends Omit<AppearanceTransitionSelection,'family_id'> { asset_id:string; variant_id:string; action:string }
export interface AppearanceBindings { schema_version:1; stages:CompanionAppearanceBinding[]; transitions:AppearanceTransitionBinding[] }
export interface AssetPackManifest { schema_version:1; kind:'asset-pack'; family_id:string; release_version:string; label:string; assets:TypedAsset[]; relationships:AssetRelationship[]; files:RuntimeFile[]; appearance_bindings?:AppearanceBindings }
export interface AssetSelection { family_id?:string; asset_id:string; variant_id?:string }
export interface ResolvedAsset { asset:TypedAsset; variant:AssetVariant; file:RuntimeFile }
export interface ResolvedCompanionAppearance extends ResolvedAsset { binding:CompanionAppearanceBinding; selection:AssetSelection; action:string; portrait:ResolvedAsset & {selection:AssetSelection} }
export interface ResolvedAppearanceTransition extends ResolvedAsset { binding:AppearanceTransitionBinding; selection:AssetSelection; action:string }
export type AnyReleaseManifest = ReleaseManifest | FileLibraryManifest | AssetPackManifest;
export const APPEARANCE_FIELDS:readonly AppearanceField[];
export const CONFIGURATION_SCHEMA_VERSION:2;
export const RELEASE_SCHEMA_VERSION:1;
export const ASSET_PACK_SCHEMA_VERSION:1;
export const APPEARANCE_BINDINGS_SCHEMA_VERSION:1;
export const COMPANION_LIFECYCLE_STAGES:readonly CompanionLifecycleStage[];
export const ASSET_KINDS:readonly AssetKind[];
export const ASSET_CAPABILITIES:readonly AssetCapability[];
export function isSafeRelativePath(value:unknown):boolean;
export function validateManifest(value:unknown):ReleaseManifest;
export function validateFileLibraryManifest(value:unknown):FileLibraryManifest;
export function validateAssetPackManifest(value:unknown):AssetPackManifest;
export function validateAnyManifest(value:unknown):AnyReleaseManifest;
export function resolveAssetVariant(manifest:AssetPackManifest,selection:AssetSelection):ResolvedAsset;
export function resolveEvolution(manifest:AssetPackManifest,fromAssetId:string,toAssetId:string):{relationship:AssetRelationship;selection:AssetSelection;action:string};
export function resolveCompanionAppearance(manifest:AssetPackManifest,selection:CompanionAppearanceSelection):ResolvedCompanionAppearance;
export function resolveAppearanceTransition(manifest:AssetPackManifest,selection:AppearanceTransitionSelection):ResolvedAppearanceTransition;
export function defaultConfiguration(manifest:ReleaseManifest):AvatarConfiguration;
export function validateConfiguration(value:unknown,manifest:ReleaseManifest):AvatarConfiguration;
export function resolveConfiguration(manifest:ReleaseManifest,value?:AvatarConfiguration):{configuration:AvatarConfiguration;variant:CatalogItem;equipment:CatalogItem[];modules:CatalogItem[];effectiveAppearance:Appearance;catalog:AppearanceCatalog};
export function resolveReleaseUrl(base:string,file:string):string;
