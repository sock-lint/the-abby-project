# Asset release contracts

The existing avatar release v1, avatar configuration v2 and file-library v1
formats keep their original structure. `validateAnyManifest` additionally accepts
`kind: "asset-pack"`, schema v1. No previously published manifest is rewritten.

An asset pack's `family_id` is its delivery and compatibility namespace. Refer to
an asset outside the pack with both `family_id` and `asset_id`; a member's `id`
stays stable within the family. A color or mesh variation keeps its own stable
variant ID. Evolution stages are separate members, with explicit descriptive
edges. Families may contain several creatures, a scene set, equipment or other
related media. A kind labels the artwork; it grants no equipment fit, ownership,
progression, unlock or reward behavior.

```js
import { validateAssetPackManifest, resolveAssetVariant } from '@abby-assets/contracts';

validateAssetPackManifest(manifest);
const { asset, variant, file } = resolveAssetVariant(manifest, {
  family_id: 'prepared-bird-lineage',
  asset_id: 'chick',
  // variant_id is optional; omission selects the authored default_variant.
});
```

The wire shape is:

```text
schema_version: 1
kind: asset-pack
family_id, release_version, label
assets[]:
  id, label, kind, capabilities[], default_variant
  variants[]:
    id, label, file
    rig_adapter_id: string | null
    bounds: { min: [x,y,z], max: [x,y,z] } | null
    animations: null | {
      root_node: string | null
      actions: { semantic_action: exact_clip_name }
      clips[]: {
        name, duration: number | null, loop: boolean | null
        root_motion: in-place | vertical | source | null
        bounds: { min: [x,y,z], max: [x,y,z] } | null
      }
    }
relationships[]: { type: evolution, from_asset_id, to_asset_id,
                   transition?: { asset_id, variant_id, action } }
files[]: { path: objects/<sha256>.glb|png, sha256, bytes, media_type }
```

Allowed kinds are `avatar`, `creature`, `mount`, `prop`, `environment`,
`equipment`, `animation-library` and `image`. Capabilities are positive
declarations: `model`, `skinned`, `animated`, `image`. Their presence must come
from the prepared output, not a vendor's product category. An `animated` member
requires animation metadata for every variant. An image member uses exactly
`["image"]`, PNG files, and null 3D metadata. Other members reference GLBs.
FBX remains a file-library input until a checked export produces a usable GLB.

Bounds describe exported Y-up meters, with variant bounds at the identity/rest
pose and clip bounds covering the complete checked motion. They remain null
when not measured. Duration is in seconds; null loop/root motion means unknown,
not an inferred default. Clip root motion describes authored motion and does
not choose a consumer's movement policy. A rig adapter ID identifies an actually
inspected compatible rig; shared bone names do not establish that compatibility.
Animation-library members do not automatically retarget to another member.

Validation rejects duplicate identities, invalid defaults, untracked or unused
files, conflicting media, unknown clips, private authoring metadata, unsupported
fields, and missing/null-required metadata. Evolution edges reference members
of this family only, cannot repeat or point to themselves, and form an acyclic
graph. Branching is allowed. These edges supply no game-level evolution rules.
An optional `transition` identifies a separate, prepared single-shot animation
asset in the same family. Its variant and semantic action must exist, and that
clip must explicitly set `loop: false`. Use `resolveEvolution(manifest, fromId,
toId)` to obtain the exact selection/action for `loadAsset`; this neither grants
evolution nor changes saved application state. Keep the target model loaded
before playing the transition, then switch to its idle when playback finishes.
Different species retain their own rigs; the transition is a baked presentation
containing the source/target meshes, not a promise of cross-rig retargeting.
Cross-family links require a future reviewed contract rather than an ambiguous
bare ID. [asset-pack.schema.json](schemas/asset-pack.schema.json) documents the
structural schema; the JavaScript validator additionally checks references,
content addressing and graph semantics.

Run synthetic contract checks from the workshop root:

```text
node --test packages/contracts/test/*.test.mjs
```

## Companion appearance bindings v1

Contracts **1.4.0** adds the optional `appearance_bindings` extension to asset-pack
v1. Existing packs and their selection APIs keep their structure. Consumers of
packs carrying this extension must install contracts 1.4.0 and runtime 1.3.0 or a
compatible later version; older strict validators reject the additional field.
The independently versioned extension is:

```text
appearance_bindings: {
  schema_version: 1,
  stages[]: {
    species_slug, potion_slug, lifecycle_stage: baby | middle | grown,
    motion, asset_id, variant_id, action,
    portrait_asset_id, portrait_variant_id
  },
  transitions[]: {
    species_slug, potion_slug, from_stage, to_stage,
    asset_id, variant_id, action
  }
}
```

An appearance is selected by the exact species, potion and stage tuple. `motion`
selects an authored native take within that appearance; `variant_id` retains its
native identity such as `source-idle`. The palette is baked into each prepared
GLB and embedded texture. A stage's bindings must share one creature asset and
one portrait while allowing different variants/actions for each motion.
The portrait references a normal image asset in the same pack. Egg inventory
identities stay in the receiving application's existing Base families; this
extension does not define acquisition, incubation, stats or rewards.

```js
import { resolveCompanionAppearance, resolveAppearanceTransition } from '@abby-assets/contracts';

const prepared = resolveCompanionAppearance(pack, {
  family_id: 'abby-elemental-companions',
  species_slug: 'chick', potion_slug: 'fire',
  lifecycle_stage: 'baby', motion: 'idle',
});
// prepared.selection: exact family/asset/native variant for loadAsset.
// prepared.action: semantic action in that variant's checked animation map.
// prepared.portrait: exact image selection, variant and content-addressed file.
const evolution = resolveAppearanceTransition(pack, {
  species_slug: 'chick', potion_slug: 'fire',
  from_stage: 'baby', to_stage: 'middle',
});
```

Missing tuples throw before loading; there is no implicit Base, idle, stage or
element fallback. Transition bindings require both stage appearances and a
separate prepared model with an explicitly non-looping action. Both forms must
already carry their intended palette in that payload; the schema checks the
binding, while artwork and complete-motion review establish visual consistency.
Validation also rejects duplicate tuples, unsupported extension versions,
unknown references/actions and identity/portrait drift between takes.
See [appearance-bindings.schema.json](schemas/appearance-bindings.schema.json).
