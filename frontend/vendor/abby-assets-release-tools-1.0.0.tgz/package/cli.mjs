#!/usr/bin/env node
import { buildArcher, pinRelease, importReleases, verifyImport, verifyRelease, publishRelease, backupWorkspace } from './index.mjs';
const [command, ...args] = process.argv.slice(2), options = {};
for (let index = 0; index < args.length; index += 2) {
  const key = args[index]; if (!key.startsWith('--') || !args[index + 1] || args[index + 1].startsWith('--')) throw new Error(`Expected --option value, got ${key}`);
  options[key.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase())] = args[index + 1];
}
function requireOptions(...names) { for (const name of names) if (!options[name]) throw new Error(`Missing --${name.replace(/[A-Z]/g, letter => `-${letter.toLowerCase()}`)}`); }
try {
  let result;
  switch (command) {
    case 'build-archer': requireOptions('workspace', 'output'); result = await buildArcher(options); break;
    case 'pin': requireOptions('release', 'lock'); result = await pinRelease(options); break;
    case 'import': requireOptions('lock', 'destination'); result = await importReleases(options); break;
    case 'verify': requireOptions('lock', 'destination'); result = await verifyImport(options); break;
    case 'verify-release': requireOptions('release'); { const checked = await verifyRelease(options.release, options.sha256); result = { manifest_sha256: checked.manifest_sha256, family_id: checked.manifest.family_id, release_version: checked.manifest.release_version, files: checked.manifest.files.length }; } break;
    case 'publish': requireOptions('release'); if (!options.destination) requireOptions('s3Bucket', 's3Endpoint', 's3Region'); result = await publishRelease(options); break;
    case 'backup': requireOptions('workspace'); if (!options.destination) requireOptions('s3Bucket', 's3Endpoint', 's3Region', 'snapshot'); result = await backupWorkspace(options); break;
    default: throw new Error('Usage: abby-assets <build-archer|pin|import|verify|verify-release|publish|backup> --option value');
  }
  console.log(JSON.stringify(result, null, 2));
} catch (error) { console.error(`Asset pipeline: ${error.message}`); process.exitCode = 1; }
