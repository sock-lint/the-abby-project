import { createHash } from 'node:crypto';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const missing = error => error?.$metadata?.httpStatusCode === 404 || ['NoSuchKey', 'NotFound'].includes(error?.name);
export function s3Configuration(options = {}, env = process.env) {
  const value = { endpoint: options.s3Endpoint || env.ABBY_ASSETS_S3_ENDPOINT, region: options.s3Region || env.ABBY_ASSETS_S3_REGION, bucket: options.s3Bucket || env.ABBY_ASSETS_S3_BUCKET, prefix: options.s3Prefix ?? env.ABBY_ASSETS_S3_PREFIX ?? '' };
  if (!value.endpoint || !value.region || !value.bucket) throw new Error('Spaces requires explicit endpoint, region and bucket (ABBY_ASSETS_S3_ENDPOINT / _REGION / _BUCKET)');
  const endpoint = new URL(value.endpoint);
  if (endpoint.protocol !== 'https:' || endpoint.username || endpoint.password || endpoint.search || endpoint.hash || endpoint.pathname !== '/') throw new Error('Spaces endpoint must be a plain HTTPS origin');
  if (!/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/.test(value.bucket)) throw new Error('Invalid Spaces bucket name');
  if (value.prefix && !value.prefix.split('/').every(part => /^[a-zA-Z0-9._-]+$/.test(part) && part !== '.' && part !== '..')) throw new Error('Unsafe Spaces key prefix');
  return value;
}
export async function createS3Store(options = {}, { client, sdk, env = process.env } = {}) {
  const config = s3Configuration(options, env);
  sdk ||= await import('@aws-sdk/client-s3');
  const owned = !client;
  client ||= new sdk.S3Client({ endpoint: config.endpoint, region: config.region, forcePathStyle: false, requestChecksumCalculation: 'WHEN_REQUIRED', responseChecksumValidation: 'WHEN_REQUIRED', maxAttempts: 3 });
  const key = relative => { if (!relative || relative.startsWith('/') || relative.includes('\\') || relative.split('/').some(part => !part || part === '.' || part === '..')) throw new Error('Unsafe Spaces object key'); return config.prefix ? `${config.prefix}/${relative}` : relative; };
  async function get(relative) {
    try {
      const result = await client.send(new sdk.GetObjectCommand({ Bucket: config.bucket, Key: key(relative) }));
      return Buffer.from(await result.Body.transformToByteArray());
    } catch (error) { if (missing(error)) return null; throw new Error(`Spaces read failed for ${relative} (${error.name || 'error'})`, { cause: error }); }
  }
  async function putImmutable(relative, bytes, contentType = 'application/octet-stream') {
    bytes = Buffer.from(bytes);
    const original = await get(relative);
    if (original) { if (original.length !== bytes.length || hash(original) !== hash(bytes)) throw new Error(`Immutable Spaces object already exists with different content: ${relative}`); return false; }
    try {
      await client.send(new sdk.PutObjectCommand({ Bucket: config.bucket, Key: key(relative), Body: bytes, ContentType: contentType, ACL: 'private', CacheControl: 'private, max-age=31536000, immutable', Metadata: { sha256: hash(bytes) }, IfNoneMatch: '*' }));
    } catch (error) {
      if (error?.$metadata?.httpStatusCode !== 412 && error.name !== 'PreconditionFailed') throw new Error(`Spaces immutable upload failed for ${relative} (${error.name || 'error'}); conditional-write support is required`, { cause: error });
    }
    const checked = await get(relative);
    if (!checked || checked.length !== bytes.length || hash(checked) !== hash(bytes)) throw new Error(`Spaces upload readback verification failed: ${relative}`);
    return true;
  }
  return { config, get, putImmutable, close() { if (owned) client.destroy(); } };
}
