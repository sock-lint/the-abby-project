# Private asset release tools

This package imports checked runtime releases without Blender, purchased archives,
editable masters, absolute authoring paths, or a dependency on the workshop checkout.
Install its versioned tarball alongside the matching `@abby-assets/contracts` tarball.
The checked-in lock pins the family, semantic release version, immutable directory and
SHA-256 of the **exact manifest bytes**. Files use SHA-256 names, measured byte sizes
and runtime MIME types. The public runtime loader checks the same file digests.

## Consumer commands

```sh
abby-assets import --lock assets.lock.json --destination public/assets/shared --release-root /private/releases
abby-assets verify --lock assets.lock.json --destination public/assets/shared
```

`ABBY_ASSETS_RELEASE_ROOT` supplies the local root when `--release-root` is omitted.
A lock entry can instead contain `source: {"url":"https://private.example/release/"}`
for an HTTPS directory accessible to the build environment. Redirects are refused;
do not put signed URLs, secrets or credentials in committed lockfiles.

For private DigitalOcean Spaces, omit the local release root and configure these
server/build environment variables:

| Variable | Value |
| --- | --- |
| `ABBY_ASSETS_S3_ENDPOINT` | Explicit HTTPS regional S3 endpoint |
| `ABBY_ASSETS_S3_REGION` | Explicit SDK region for that endpoint |
| `ABBY_ASSETS_S3_BUCKET` | Runtime release bucket |
| `ABBY_ASSETS_S3_PREFIX` | Optional prefix, such as `releases` |
| `AWS_ACCESS_KEY_ID` | Bucket-scoped read-only build key |
| `AWS_SECRET_ACCESS_KEY` | Matching secret, held in CI secret storage |

The AWS SDK credential chain is supported, including temporary credentials and
`AWS_SESSION_TOKEN`. None of these settings use a `VITE_` or `NEXT_PUBLIC_` prefix.
Credentials never belong in browser configuration, runtime manifests or saved avatars.
Use different bucket-scoped credentials for workshop publishing and source backup.

Import verifies every byte before swapping its dedicated destination directory.
Existing unmarked files are protected. An invalid/missing source leaves the previous
install in place and fails with a nonzero exit code. Verified installs need no source
credentials to run or build. `verify` never fetches or regenerates missing assets.
Concurrent imports are refused. On Windows, directory swaps retry transient watcher
locks; stop the dev server before import if another process holds the destination.

The generated `index.json` contains `manifest_path` for each pinned release. Resolve
that path beneath the application's served asset base. Saved configurations contain
stable family/appearance/equipment IDs; they never contain release URLs or lab paths.

## Workshop commands

```sh
abby-assets build-archer --workspace /workshop --version 1.0.1 --output /private/releases --portrait /approved/archer-01.png
abby-assets pin --release /private/releases/FAMILY/VERSION/DIGEST --lock assets.lock.json
abby-assets verify-release --release /private/releases/FAMILY/VERSION/DIGEST --sha256 DIGEST
abby-assets publish --release /private/releases/FAMILY/VERSION/DIGEST --destination /private/distribution
```

`build-archer` inspects and checks the current prepared source catalogs. It packages
24 bases, 44 selectable modules, 30 fitted equipment options for three inspected rigs,
five emission maps and one projectile. Shared bytes are stored once. It preserves
the binary GLB buffers, stripping source-file/editor JSON extras in release copies;
the existing source GLBs and Blender masters stay untouched. The optional portrait
is the existing workQuest starter image, with its matching configuration recorded.
Private source-to-runtime hashes are written under `.local/release-evidence/`.
Same-version content changes fail. Select a new release version for changed payloads.

Publish to Spaces only with an explicit bucket, endpoint and region:

```sh
abby-assets publish --release /private/releases/FAMILY/VERSION/DIGEST --s3-bucket RUNTIME_BUCKET --s3-endpoint https://REGION.digitaloceanspaces.com --s3-region REGION --s3-prefix releases
```

All objects use private ACLs and conditional writes. Existing objects must match
exactly. Uploads are downloaded and hashed for verification. A version reservation
prevents a different digest being assigned to an existing family/version; the release
manifest uploads last, after every runtime object verifies. Interrupted publishes can
be retried with identical content. Conditional-write failures stop the publish;
the tool never falls back to overwriting. No buckets, keys, public policies, CDN
settings, versioning settings or remote deletions are created by this command.

## Source backup

Use a new, explicitly selected destination outside the workshop:

```sh
abby-assets backup --workspace /workshop --destination /private-backups/snapshot-id
abby-assets backup --workspace /workshop --snapshot SNAPSHOT_ID --s3-bucket SOURCE_BACKUP_BUCKET --s3-endpoint https://REGION.digitaloceanspaces.com --s3-region REGION --s3-prefix backups
```

Backups cover every regular file under `Meshtint/Originals` and `assets`, including
archives, meshes, editable sources, recipes and evidence. Symlinks are refused.
Local copies are reread and hashed. Cloud payloads are deduplicated by SHA-256 and
verified by readback before the immutable snapshot manifest is uploaded. Backup
credentials should have no relationship to the consumer applications. Configure
bucket versioning separately through the provider's API after selecting the actual
backup bucket; this command never changes account settings.

A backup is not complete until the command reports `verified: true`. Actual external
storage backup and a restoration drill remain operational requirements; this package
does not claim that a local-only generated release supplies disaster recovery.

Provider references: [Spaces SDK support](https://docs.digitalocean.com/products/spaces/reference/aws-sdks/),
[S3 compatibility and versioning](https://docs.digitalocean.com/products/spaces/reference/s3-compatibility/),
[access scopes](https://docs.digitalocean.com/products/spaces/how-to/manage-access/).
