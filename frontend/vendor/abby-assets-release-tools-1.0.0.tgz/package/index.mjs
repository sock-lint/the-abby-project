import { createHash, randomUUID } from 'node:crypto';
import { readFile, writeFile, mkdir, readdir, lstat, realpath, rename, rm, copyFile, open } from 'node:fs/promises';
import path from 'node:path';
import { validateManifest, isSafeRelativePath } from '@abby-assets/contracts';
import { createS3Store } from './s3.mjs';

export const digest = bytes => createHash('sha256').update(bytes).digest('hex');
export const canonicalJson = value => `${JSON.stringify(sort(value), null, 2)}\n`;
function sort(value) {
  if (Array.isArray(value)) return value.map(sort);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key, sort(value[key])]));
  return value;
}
const exists = async target => { try { await lstat(target); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; } };
const retryRename = async (source, target) => {
  for (let attempt = 0; ; attempt++) {
    try { await rename(source, target); return; }
    catch (error) { if (!['EPERM', 'EBUSY', 'EACCES'].includes(error.code) || attempt >= 7) throw error; await new Promise(resolve => setTimeout(resolve, 50 * 2 ** attempt)); }
  }
};
function contained(root, target) { const relative = path.relative(root, target); return relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative); }
async function checkedFile(root, relative) {
  if (!isSafeRelativePath(relative)) throw new Error(`Unsafe relative file path: ${relative}`);
  const absolute = path.resolve(root, relative), resolvedRoot = await realpath(root), resolved = await realpath(absolute);
  if (!contained(resolvedRoot, resolved) || !(await lstat(absolute)).isFile()) throw new Error(`Non-regular or escaped file: ${relative}`);
  return absolute;
}
async function exactTree(root, allowedFiles) {
  const info = await lstat(root);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Asset tree root must be a regular directory');
  const files = new Set(allowedFiles), directories = new Set();
  for (const file of files) {
    const parts = file.split('/');
    for (let count = 1; count < parts.length; count++) directories.add(parts.slice(0, count).join('/'));
  }
  async function visit(relative = '') {
    for (const name of await readdir(path.join(root, relative))) {
      const next = relative ? `${relative}/${name}` : name, info = await lstat(path.join(root, next));
      if (info.isSymbolicLink()) throw new Error(`Asset tree contains a symbolic link: ${next}`);
      if (info.isDirectory()) {
        if (!directories.has(next)) throw new Error(`Unexpected directory in asset tree: ${next}`);
        await visit(next);
      } else if (!info.isFile() || !files.has(next)) throw new Error(`Unexpected file in asset tree: ${next}`);
    }
  }
  await visit();
}
async function plainDirectory(target) {
  const absolute = path.resolve(target);
  for (let current = absolute; ; current = path.dirname(current)) {
    if (await exists(current)) { const info = await lstat(current); if (info.isSymbolicLink() || !info.isDirectory()) throw new Error(`Directory is not a regular directory: ${current}`); }
    if (current === path.dirname(current)) break;
  }
  return absolute;
}
export function readGlb(bytes) {
  if (bytes.length < 20 || bytes.readUInt32LE(0) !== 0x46546c67 || bytes.readUInt32LE(4) !== 2 || bytes.readUInt32LE(8) !== bytes.length || bytes.readUInt32LE(16) !== 0x4e4f534a) throw new Error('Invalid GLB 2.0 header');
  const length = bytes.readUInt32LE(12);
  return { json: JSON.parse(bytes.subarray(20, 20 + length).toString('utf8')), tail: bytes.subarray(20 + length) };
}
export function runtimeGlb(bytes) {
  const { json, tail } = readGlb(bytes);
  // Runtime exports omit source filenames and editor-only metadata. Geometry,
  // textures, transforms, materials, skinning and animation buffers stay exact.
  const scrub = value => {
    if (!value || typeof value !== 'object') return;
    if (value.extras) {
      for (const key of Object.keys(value.extras)) if (/source_(?:file|path|model|archive|input)|^MapChannel|^MaxHandle|before_dense/i.test(key)) delete value.extras[key];
      scrubExtras(value.extras);
      if (!Object.keys(value.extras).length) delete value.extras;
    }
    for (const [key, child] of Object.entries(value)) if (key !== 'extras') { if (Array.isArray(child)) child.forEach(scrub); else scrub(child); }
  };
  const scrubExtras = value => { if (!value || typeof value !== 'object') return; for (const key of Object.keys(value)) { if (/source_(?:file|path|model|archive|input)|before_dense/i.test(key)) delete value[key]; else scrubExtras(value[key]); } };
  scrub(json);
  for (const buffer of json.buffers || []) if (buffer.uri) throw new Error('Runtime GLB contains an external buffer');
  for (const image of json.images || []) if (image.uri) throw new Error('Runtime GLB contains an external image');
  const raw = Buffer.from(JSON.stringify(json));
  const padded = Buffer.alloc(Math.ceil(raw.length / 4) * 4, 0x20); raw.copy(padded);
  const header = Buffer.alloc(20); header.writeUInt32LE(0x46546c67, 0); header.writeUInt32LE(2, 4); header.writeUInt32LE(20 + padded.length + tail.length, 8); header.writeUInt32LE(padded.length, 12); header.writeUInt32LE(0x4e4f534a, 16);
  return Buffer.concat([header, padded, tail]);
}
const fields = ['id', 'label', 'category', 'slot', 'body', 'skin', 'outfit', 'head', 'hair_style', 'hair_color', 'face_style', 'face_color', 'rig_adapter_id', 'attachment_node', 'hide_nodes', 'hair_style_override', 'default_enabled', 'material_names', 'emissive_factor', 'triangles', 'material_count', 'materials', 'texture_count'];
const runtimeFields = item => Object.fromEntries(fields.filter(key => item[key] !== undefined).map(key => [key, item[key]]));

export async function buildArcher({ workspace, version = '1.0.0', output, portrait }) {
  workspace = path.resolve(workspace); output = await plainDirectory(output);
  const appearanceFile = path.join(workspace, 'assets/female-archer-library/appearance/catalog.json');
  const original = JSON.parse(await readFile(appearanceFile, 'utf8'));
  const equipmentFile = path.join(workspace, 'assets/female-archer-jump/accessories/catalog.json');
  const originalEquipment = JSON.parse(await readFile(equipmentFile, 'utf8'));
  const objects = new Map(), audit = [];
  async function asset(item, directory) {
    const absolute = path.resolve(directory, item.file);
    if (!contained(path.join(workspace, 'assets'), absolute)) throw new Error(`Source asset escaped workshop: ${item.id}`);
    const input = await readFile(absolute), inputHash = digest(input);
    if (item.sha256 && item.sha256 !== inputHash) throw new Error(`Source catalog hash mismatch: ${item.id}`);
    const extension = path.extname(absolute).toLowerCase();
    if (!['.glb', '.png'].includes(extension)) throw new Error(`Unapproved runtime file type: ${extension}`);
    const bytes = extension === '.glb' ? runtimeGlb(input) : input;
    const sha256 = digest(bytes), relative = `objects/${sha256}${extension}`;
    objects.set(relative, bytes); audit.push({ id: item.id, source: path.relative(workspace, absolute).split(path.sep).join('/'), source_sha256: inputHash, runtime_sha256: sha256 });
    return { ...runtimeFields(item), file: relative, path: relative, sha256, bytes: bytes.length };
  }
  const appearance = Object.fromEntries(['schema_version', 'family_id', 'label', 'rig_adapter_ids', 'defaults', 'selectors', 'replacement_nodes', 'attachment_contract'].map(key => [key, original[key]]));
  for (const key of ['base_variants', 'modules', 'equipment_overrides', 'textures', 'projectiles']) appearance[key] = await Promise.all(original[key].map(item => asset(item, path.dirname(appearanceFile))));
  appearance.emission = { default_enabled: Boolean(original.emission?.default_enabled), maps: appearance.textures };
  const items = await Promise.all(originalEquipment.items.map(async item => {
    const override = original.equipment_overrides.find(entry => entry.id === item.id);
    return override ? { ...runtimeFields(item), ...await asset({ ...item, ...override }, path.dirname(appearanceFile)) } : asset(item, path.dirname(equipmentFile));
  }));
  const sample = readGlb(objects.get(appearance.base_variants[0].file)).json;
  const clips = sample.animations.map(animation => ({ name: animation.name, duration: Math.max(...animation.samplers.map(sampler => sample.accessors[sampler.input].max?.[0] ?? 0)), loop: animation.name !== 'Jump' && !animation.name.includes('Root Motion'), root_motion: animation.name.includes('Root Motion') ? 'source' : animation.name === 'Jump' ? 'vertical' : 'in-place' }));
  // All bases must expose the same intentional clip names; do not silently ship
  // partially rebuilt families.
  for (const base of appearance.base_variants) {
    const json = readGlb(objects.get(base.file)).json;
    if (JSON.stringify(json.animations.map(clip => clip.name)) !== JSON.stringify(clips.map(clip => clip.name))) throw new Error(`Clip mismatch: ${base.id}`);
    if (!json.nodes.some(node => node.extras?.avatar_rig_adapter_id === base.rig_adapter_id)) throw new Error(`Adapter metadata mismatch: ${base.id}`);
  }
  const portraits = [];
  if (portrait) {
    const bytes = await readFile(portrait), sha256 = digest(bytes), relative = `objects/${sha256}.png`; objects.set(relative, bytes);
    portraits.push({ id: 'workquest-starter', label: 'Existing workQuest Archer starter portrait', file: relative, path: relative, sha256, bytes: bytes.length, configuration: { schema_version: 2, family_id: original.family_id, appearance: { body: '01', skin: 'fair', outfit: 'nature', head: '02', hair_style: '02', hair_color: 'black', face_style: '01', face_color: 'black' }, slots: { 'left-hand': 'bow-greenhorn', back: 'quiver-rook' }, emission_enabled: false } });
  }
  const manifest = validateManifest({ schema_version: 1, family_id: original.family_id, release_version: version, label: original.label, appearance, equipment_catalogs: original.rig_adapter_ids.map(rig_adapter_id => ({ rig_adapter_id, items })), animations: { actions: { idle: 'Idle', walk: 'Walk', run: 'Run', jump: 'Jump' }, clips, root_node: 'JumpRoot' }, portraits, files: [...objects.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([relative, bytes]) => ({ path: relative, sha256: digest(bytes), bytes: bytes.length, media_type: relative.endsWith('.glb') ? 'model/gltf-binary' : 'image/png' })) });
  const bytes = Buffer.from(canonicalJson(manifest)), manifest_sha256 = digest(bytes);
  const directory = `${manifest.family_id}/${version}/${manifest_sha256}`, destination = path.join(output, directory);
  const versionRoot = path.dirname(destination);
  await mkdir(versionRoot, { recursive: true });
  const existing = (await readdir(versionRoot)).filter(entry => !entry.startsWith('.'));
  if (existing.length && !existing.includes(manifest_sha256)) throw new Error(`Immutable version ${version} already exists with different content; choose a new version`);
  if (!await exists(destination)) {
    const stage = path.join(versionRoot, `.build-${randomUUID()}`); await mkdir(path.join(stage, 'objects'), { recursive: true });
    try { for (const [relative, payload] of objects) await writeFile(path.join(stage, relative), payload, { flag: 'wx' }); await writeFile(path.join(stage, 'manifest.json'), bytes, { flag: 'wx' }); await rename(stage, destination); }
    finally { if (await exists(stage)) await rm(stage, { recursive: true }); }
  }
  await verifyRelease(destination, manifest_sha256);
  const evidence = path.join(workspace, '.local/release-evidence', manifest_sha256); await mkdir(evidence, { recursive: true });
  await writeFile(path.join(evidence, 'source-map.json'), canonicalJson({ manifest_sha256, records: audit }));
  return { directory, path: destination, family_id: manifest.family_id, release_version: version, manifest_sha256, files: manifest.files.length, bytes: manifest.files.reduce((sum, file) => sum + file.bytes, 0) };
}

export async function verifyRelease(directory, expectedDigest) {
  const bytes = await readFile(await checkedFile(directory, 'manifest.json'));
  const actual = digest(bytes);
  if (expectedDigest && actual !== expectedDigest) throw new Error(`Release manifest integrity mismatch: expected ${expectedDigest}, got ${actual}`);
  const manifest = validateManifest(JSON.parse(bytes));
  await exactTree(directory, ['manifest.json', ...manifest.files.map(file => file.path)]);
  for (const file of manifest.files) {
    const bytes = await readFile(await checkedFile(directory, file.path));
    if (bytes.length !== file.bytes || digest(bytes) !== file.sha256) throw new Error(`Release file integrity mismatch: ${file.path}`);
  }
  return { manifest, manifest_sha256: actual };
}
export async function pinRelease({ release, lock }) {
  const { manifest, manifest_sha256 } = await verifyRelease(release);
  const entry = { family_id: manifest.family_id, release_version: manifest.release_version, manifest_sha256, directory: `${manifest.family_id}/${manifest.release_version}/${manifest_sha256}` };
  const existing = await exists(lock) ? JSON.parse(await readFile(lock, 'utf8')) : { schema_version: 1, releases: [] };
  validateLock(existing);
  existing.releases = existing.releases.filter(item => item.family_id !== entry.family_id).concat(entry).sort((a, b) => a.family_id.localeCompare(b.family_id));
  await mkdir(path.dirname(path.resolve(lock)), { recursive: true }); await writeFile(lock, canonicalJson(existing));
  return existing;
}
export function validateLock(value) {
  if (!value || value.schema_version !== 1 || !Array.isArray(value.releases)) throw new Error('Unsupported assets.lock.json schema');
  const seen = new Set();
  for (const entry of value.releases) {
    if (!entry || typeof entry !== 'object' || typeof entry.family_id !== 'string' || !/^[a-z0-9][a-z0-9._-]*$/.test(entry.family_id) || typeof entry.release_version !== 'string' || !/^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/.test(entry.release_version) || typeof entry.manifest_sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(entry.manifest_sha256) || entry.directory !== `${entry.family_id}/${entry.release_version}/${entry.manifest_sha256}` || seen.has(entry.family_id)) throw new Error('Invalid or duplicate pinned release');
    if (entry.source?.url && new URL(entry.source.url).protocol !== 'https:') throw new Error('Remote releases require HTTPS');
    seen.add(entry.family_id);
  }
  return value;
}
const indexFor = lock => ({ schema_version: 1, releases: lock.releases.map(({ family_id, release_version, manifest_sha256, directory }) => ({ family_id, release_version, manifest_sha256, manifest_path: `${directory}/manifest.json` })) });
export async function verifyImport({ lock, destination }) {
  const pinned = validateLock(JSON.parse(await readFile(lock, 'utf8')));
  const index = JSON.parse(await readFile(await checkedFile(destination, 'index.json'), 'utf8'));
  if (canonicalJson(index) !== canonicalJson(indexFor(pinned))) throw new Error('Staged asset index does not match assets.lock.json; run asset import');
  const marker = JSON.parse(await readFile(await checkedFile(destination, '.abby-assets-managed.json'), 'utf8'));
  if (canonicalJson(marker) !== canonicalJson({ schema_version: 1, manager: '@abby-assets/release-tools' })) throw new Error('Staged asset manager marker is invalid');
  const allowed = ['index.json', '.abby-assets-managed.json'];
  let bytes = 0, files = 0;
  for (const entry of pinned.releases) {
    const result = await verifyRelease(path.join(destination, entry.directory), entry.manifest_sha256);
    if (result.manifest.family_id !== entry.family_id || result.manifest.release_version !== entry.release_version) throw new Error('Pinned release identity mismatch');
    allowed.push(`${entry.directory}/manifest.json`, ...result.manifest.files.map(file => `${entry.directory}/${file.path}`));
    bytes += result.manifest.files.reduce((sum, file) => sum + file.bytes, 0); files += result.manifest.files.length;
  }
  await exactTree(destination, allowed);
  return { releases: pinned.releases.length, files, bytes };
}
export async function importReleases({ lock, destination, releaseRoot = process.env.ABBY_ASSETS_RELEASE_ROOT, fetch: fetchImpl = globalThis.fetch, store: injectedStore, ...options }) {
  const pinned = validateLock(JSON.parse(await readFile(lock, 'utf8'))); destination = await plainDirectory(destination);
  try { return { ...await verifyImport({ lock, destination }), unchanged: true }; } catch { /* A full verified transaction repairs missing/corrupt staged files. */ }
  await mkdir(path.dirname(destination), { recursive: true });
  const guard = `${destination}.import-lock`, handle = await open(guard, 'wx').catch(error => { if (error.code === 'EEXIST') throw new Error('Another asset import is active; remove its import-lock only after confirming it stopped'); throw error; });
  const stage = path.join(path.dirname(destination), `.${path.basename(destination)}.stage-${randomUUID()}`), previous = path.join(path.dirname(destination), `.${path.basename(destination)}.previous-${randomUUID()}`);
  let store = injectedStore;
  try {
    if (await exists(destination) && (await readdir(destination)).length && !await exists(path.join(destination, '.abby-assets-managed.json'))) throw new Error('Destination contains unmanaged files; use a dedicated empty directory');
    await mkdir(stage);
    for (const entry of pinned.releases) {
      const remote = entry.source?.url;
      const source = releaseRoot && path.resolve(releaseRoot, entry.directory);
      if (!remote && !source && !store) store = await createS3Store(options);
      async function obtain(relative) {
        if (remote) {
          const url = new URL(relative, `${remote.replace(/\/?$/, '/')}`);
          const response = await fetchImpl(url, { redirect: 'error', signal: AbortSignal.timeout(60000) });
          if (!response.ok) throw new Error(`Asset download failed (${response.status}): ${relative}`);
          return Buffer.from(await response.arrayBuffer());
        }
        if (!source && store) { const bytes = await store.get(`${entry.directory}/${relative}`); if (!bytes) throw new Error(`Required Spaces release file is unavailable: ${entry.directory}/${relative}`); return bytes; }
        try { return await readFile(await checkedFile(source, relative)); } catch (error) { throw new Error(`Required private release file is unavailable: ${entry.directory}/${relative}. Restore the approved release and rerun import.`, { cause: error }); }
      }
      const bytes = await obtain('manifest.json');
      if (digest(bytes) !== entry.manifest_sha256) throw new Error('Downloaded manifest does not match the pinned SHA-256');
      const manifest = validateManifest(JSON.parse(bytes));
      if (manifest.family_id !== entry.family_id || manifest.release_version !== entry.release_version) throw new Error('Downloaded release identity mismatch');
      const target = path.join(stage, entry.directory); await mkdir(path.join(target, 'objects'), { recursive: true });
      await writeFile(path.join(target, 'manifest.json'), bytes);
      for (const file of manifest.files) {
        const bytes = await obtain(file.path);
        if (bytes.length !== file.bytes || digest(bytes) !== file.sha256) throw new Error(`Downloaded file integrity mismatch: ${file.path}`);
        await writeFile(path.join(target, file.path), bytes);
      }
    }
    await writeFile(path.join(stage, 'index.json'), canonicalJson(indexFor(pinned)));
    await writeFile(path.join(stage, '.abby-assets-managed.json'), canonicalJson({ schema_version: 1, manager: '@abby-assets/release-tools' }));
    const result = await verifyImport({ lock, destination: stage });
    if (await exists(destination)) await retryRename(destination, previous);
    try { await retryRename(stage, destination); } catch (error) { if (await exists(previous)) await retryRename(previous, destination); throw error; }
    if (await exists(previous)) await rm(previous, { recursive: true });
    return { ...result, unchanged: false };
  } finally { if (!injectedStore) store?.close(); if (await exists(stage)) await rm(stage, { recursive: true }); await handle.close(); await rm(guard, { force: true }); }
}
export async function publishRelease({ release, destination, store: injectedStore, ...options }) {
  const { manifest, manifest_sha256 } = await verifyRelease(release);
  if (!destination) {
    const store = injectedStore || await createS3Store(options);
    const directory = `${manifest.family_id}/${manifest.release_version}/${manifest_sha256}`;
    try {
      await store.putImmutable(`versions/${manifest.family_id}/${manifest.release_version}.json`, Buffer.from(canonicalJson({ family_id: manifest.family_id, release_version: manifest.release_version, manifest_sha256 })), 'application/json');
      for (const file of manifest.files) {
        const bytes = await readFile(await checkedFile(release, file.path));
        if (bytes.length !== file.bytes || digest(bytes) !== file.sha256) throw new Error(`Source changed during publish: ${file.path}`);
        await store.putImmutable(`${directory}/${file.path}`, bytes, file.media_type);
      }
      // Completion is advertised only after every runtime object passed readback.
      await store.putImmutable(`${directory}/manifest.json`, await readFile(path.join(release, 'manifest.json')), 'application/json');
      return { bucket: store.config.bucket, prefix: store.config.prefix, directory, manifest_sha256, files: manifest.files.length, verified: true };
    } finally { if (!injectedStore) store.close(); }
  }
  destination = await plainDirectory(destination);
  const target = path.join(destination, manifest.family_id, manifest.release_version, manifest_sha256), versionRoot = path.dirname(target);
  await mkdir(versionRoot, { recursive: true });
  const existing = (await readdir(versionRoot)).filter(entry => !entry.startsWith('.'));
  if (existing.some(entry => entry !== manifest_sha256)) throw new Error('Destination already has a different immutable release at this version');
  if (await exists(target)) { await verifyRelease(target, manifest_sha256); return { path: target, unchanged: true }; }
  const stage = path.join(versionRoot, `.publish-${randomUUID()}`); await mkdir(path.join(stage, 'objects'), { recursive: true });
  try { await copyFile(path.join(release, 'manifest.json'), path.join(stage, 'manifest.json')); for (const file of manifest.files) await copyFile(await checkedFile(release, file.path), path.join(stage, file.path)); await verifyRelease(stage, manifest_sha256); await rename(stage, target); }
  finally { if (await exists(stage)) await rm(stage, { recursive: true }); }
  return { path: target, unchanged: false };
}
export async function backupWorkspace({ workspace, destination, snapshot, store: injectedStore, ...options }) {
  if (!destination) {
    if (!snapshot || !/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(snapshot)) throw new Error('Cloud backup requires an explicit --snapshot ID');
    const store = injectedStore || await createS3Store(options), records = [];
    workspace = await realpath(workspace);
    const walk = async relative => {
      const absolute = path.join(workspace, relative), info = await lstat(absolute);
      if (info.isSymbolicLink()) throw new Error(`Backup refuses symlink: ${relative}`);
      if (info.isDirectory()) { for (const name of (await readdir(absolute)).sort()) await walk(path.join(relative, name)); return; }
      if (!info.isFile()) throw new Error(`Backup requires regular files: ${relative}`);
      const bytes = await readFile(absolute), normalized = relative.split(path.sep).join('/'), sha256 = digest(bytes);
      await store.putImmutable(`objects/${sha256}`, bytes);
      records.push({ path: normalized, sha256, bytes: bytes.length, object: `objects/${sha256}` });
    };
    try {
      for (const root of ['Meshtint/Originals', 'assets']) await walk(root);
      const bytes = Buffer.from(canonicalJson({ schema_version: 1, snapshot, files: records }));
      await store.putImmutable(`snapshots/${snapshot}/backup-manifest.json`, bytes, 'application/json');
      return { bucket: store.config.bucket, prefix: store.config.prefix, snapshot, manifest_sha256: digest(bytes), files: records.length, bytes: records.reduce((sum, item) => sum + item.bytes, 0), verified: true };
    } finally { if (!injectedStore) store.close(); }
  }
  workspace = await realpath(workspace); destination = await plainDirectory(destination);
  if (contained(workspace, destination) || contained(destination, workspace)) throw new Error('Backup destination must be outside the workspace and cannot contain it');
  if (await exists(destination)) throw new Error('Backup destination must be new so existing backups cannot be overwritten');
  const stage = `${destination}.stage-${randomUUID()}`, records = [];
  async function walk(relative) {
    const absolute = path.join(workspace, relative), info = await lstat(absolute);
    if (info.isSymbolicLink()) throw new Error(`Backup refuses symlink: ${relative}`);
    if (info.isDirectory()) { for (const name of (await readdir(absolute)).sort()) await walk(path.join(relative, name)); return; }
    if (!info.isFile()) throw new Error(`Backup requires regular files: ${relative}`);
    const bytes = await readFile(absolute), normalized = relative.split(path.sep).join('/');
    await mkdir(path.dirname(path.join(stage, relative)), { recursive: true }); await writeFile(path.join(stage, relative), bytes);
    records.push({ path: normalized, sha256: digest(bytes), bytes: bytes.length });
  }
  await mkdir(stage, { recursive: true });
  try {
    for (const root of ['Meshtint/Originals', 'assets']) await walk(root);
    for (const record of records) { const bytes = await readFile(path.join(stage, record.path)); if (bytes.length !== record.bytes || digest(bytes) !== record.sha256) throw new Error(`Backup verification failed: ${record.path}`); }
    await writeFile(path.join(stage, 'backup-manifest.json'), canonicalJson({ schema_version: 1, files: records })); await rename(stage, destination);
  } finally { if (await exists(stage)) await rm(stage, { recursive: true }); }
  return { path: destination, files: records.length, bytes: records.reduce((sum, item) => sum + item.bytes, 0), verified: true };
}
