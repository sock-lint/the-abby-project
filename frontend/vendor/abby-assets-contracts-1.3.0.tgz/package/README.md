# Asset release contracts

The existing avatar release v1, avatar configuration v2 and file-library v1
formats keep their original structure. `validateAnyManifest` additionally accepts
`kind: "asset-pack"`, schema v1. No previously published manifest is rewritten.

An asset pack's `family_id` is its delivery and compatibility namespace. Refer to
an asset outside the pack with both `family_id` and `asset_id`; a member's `id`
stays stable within the family. A color or mesh variation keeps its own stable
variant ID. Evolution stages are separate members, with explicit descriptive
edges. Families may contain several creatures, a scene set, equipment or other
related media. A kind labels the artwork; it grants no equipment fit, ownership,
progression, unlock or reward behavior.

```js
import { validateAssetPackManifest, resolveAssetVariant } from '@abby-assets/contracts';

validateAssetPackManifest(manifest);
const { asset, variant, file } = resolveAssetVariant(manifest, {
  family_id: 'prepared-bird-lineage',
  asset_id: 'chick',
  // variant_id is optional; omission selects the authored default_variant.
});
```

The wire shape is:

```text
schema_version: 1
kind: asset-pack
family_id, release_version, label
assets[]:
  id, label, kind, capabilities[], default_variant
  variants[]:
    id, label, file
    rig_adapter_id: string | null
    bounds: { min: [x,y,z], max: [x,y,z] } | null
    animations: null | {
      root_node: string | null
      actions: { semantic_action: exact_clip_name }
      clips[]: {
        name, duration: number | null, loop: boolean | null
        root_motion: in-place | vertical | source | null
        bounds: { min: [x,y,z], max: [x,y,z] } | null
      }
    }
relationships[]: { type: evolution, from_asset_id, to_asset_id,
                   transition?: { asset_id, variant_id, action } }
files[]: { path: objects/<sha256>.glb|png, sha256, bytes, media_type }
```

Allowed kinds are `avatar`, `creature`, `mount`, `prop`, `environment`,
`equipment`, `animation-library` and `image`. Capabilities are positive
declarations: `model`, `skinned`, `animated`, `image`. Their presence must come
from the prepared output, not a vendor's product category. An `animated` member
requires animation metadata for every variant. An image member uses exactly
`["image"]`, PNG files, and null 3D metadata. Other members reference GLBs.
FBX remains a file-library input until a checked export produces a usable GLB.

Bounds describe exported Y-up meters, with variant bounds at the identity/rest
pose and clip bounds covering the complete checked motion. They remain null
when not measured. Duration is in seconds; null loop/root motion means unknown,
not an inferred default. Clip root motion describes authored motion and does
not choose a consumer's movement policy. A rig adapter ID identifies an actually
inspected compatible rig; shared bone names do not establish that compatibility.
Animation-library members do not automatically retarget to another member.

Validation rejects duplicate identities, invalid defaults, untracked or unused
files, conflicting media, unknown clips, private authoring metadata, unsupported
fields, and missing/null-required metadata. Evolution edges reference members
of this family only, cannot repeat or point to themselves, and form an acyclic
graph. Branching is allowed. These edges supply no game-level evolution rules.
An optional `transition` identifies a separate, prepared single-shot animation
asset in the same family. Its variant and semantic action must exist, and that
clip must explicitly set `loop: false`. Use `resolveEvolution(manifest, fromId,
toId)` to obtain the exact selection/action for `loadAsset`; this neither grants
evolution nor changes saved application state. Keep the target model loaded
before playing the transition, then switch to its idle when playback finishes.
Different species retain their own rigs; the transition is a baked presentation
containing the source/target meshes, not a promise of cross-rig retargeting.
Cross-family links require a future reviewed contract rather than an ambiguous
bare ID. [asset-pack.schema.json](schemas/asset-pack.schema.json) documents the
structural schema; the JavaScript validator additionally checks references,
content addressing and graph semantics.

Run synthetic contract checks from the workshop root:

```text
node --test packages/contracts/test/*.test.mjs
```
