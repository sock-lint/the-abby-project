# Private asset release tools

This package imports checked runtime releases without Blender, purchased archives,
editable masters, absolute authoring paths, or a dependency on the workshop checkout.
Install its versioned tarball alongside the matching `@abby-assets/contracts` tarball.
The checked-in lock pins the family, semantic release version, immutable directory and
SHA-256 of the **exact manifest bytes**. Files use SHA-256 names, measured byte sizes
and runtime MIME types. The public runtime loader checks the same file digests.

Version 1.6.0 preserves the optional `appearance_bindings` version 1 extension
through typed asset-pack building and the verified human/machine handoff. It
requires `@abby-assets/contracts` 1.4.0. Appearance keys remain separate from
native take variant IDs. Existing recipes without the extension produce the
same manifests as before; appearance records are validated against the exact
prepared model, action and portrait targets.

## Consumer commands

```sh
abby-assets import --lock assets.lock.json --destination public/assets/shared --release-root /private/releases
abby-assets verify --lock assets.lock.json --destination public/assets/shared
```

`ABBY_ASSETS_RELEASE_ROOT` supplies the local root when `--release-root` is omitted.
A lock entry can instead contain `source: {"url":"https://private.example/release/"}`
for an HTTPS directory accessible to the build environment. Redirects are refused;
do not put signed URLs, secrets or credentials in committed lockfiles.

For private DigitalOcean Spaces, omit the local release root and configure these
server/build environment variables:

| Variable | Value |
| --- | --- |
| `ABBY_ASSETS_S3_ENDPOINT` | Explicit HTTPS regional S3 endpoint |
| `ABBY_ASSETS_S3_REGION` | Explicit SDK region for that endpoint |
| `ABBY_ASSETS_S3_BUCKET` | Runtime release bucket |
| `ABBY_ASSETS_S3_PREFIX` | Optional prefix, such as `releases` |
| `AWS_ACCESS_KEY_ID` | Bucket-scoped read-only build key |
| `AWS_SECRET_ACCESS_KEY` | Matching secret, held in CI secret storage |

The AWS SDK credential chain is supported, including temporary credentials and
`AWS_SESSION_TOKEN`. None of these settings use a `VITE_` or `NEXT_PUBLIC_` prefix.
Credentials never belong in browser configuration, runtime manifests or saved avatars.
Use different bucket-scoped credentials for workshop publishing and source backup.

Import verifies every byte before swapping its dedicated destination directory.
Existing unmarked files are protected. An invalid/missing source leaves the previous
install in place and fails with a nonzero exit code. Verified installs need no source
credentials to run or build. `verify` never fetches or regenerates missing assets.
Concurrent imports are refused. On Windows, directory swaps retry transient watcher
locks; stop the dev server before import if another process holds the destination.

The generated `index.json` contains `manifest_path` for each pinned release. Resolve
that path beneath the application's served asset base. Saved configurations contain
stable family/appearance/equipment IDs; they never contain release URLs or lab paths.

## Workshop commands

```sh
abby-assets build-archer --workspace /workshop --version 1.0.2 --output /private/releases --portrait /approved/archer-01.png
abby-assets list-families --workspace /workshop
abby-assets build-family --workspace /workshop --family FAMILY_ID --version NEW_VERSION --output /workshop/.local/releases
abby-assets build-avatar --workspace /workshop --recipe recipes/FAMILY.avatar-family.json --version NEW_VERSION --output /workshop/.local/releases
abby-assets build-asset-pack --workspace /workshop --recipe recipes/FAMILY.asset-pack.json --version NEW_VERSION --output /workshop/.local/releases
abby-assets pin --release /private/releases/FAMILY/VERSION/DIGEST --lock assets.lock.json
abby-assets verify-release --release /private/releases/FAMILY/VERSION/DIGEST --sha256 DIGEST
abby-assets publish --release /private/releases/FAMILY/VERSION/DIGEST --destination /private/distribution
```

`build-archer` inspects and checks the current prepared source catalogs. It packages
24 bases, 44 selectable modules, 30 fitted equipment options for three inspected rigs,
five emission maps and one projectile. Shared bytes are stored once. It preserves
the binary GLB buffers, stripping source-file/editor JSON extras in release copies;
the existing source GLBs and Blender masters stay untouched. The optional portrait
is the existing workQuest starter image, with its matching configuration recorded.
Private source-to-runtime hashes are written under `.local/release-evidence/`.
Same-version content changes fail. Select a new release version for changed payloads.

In tools 1.4 / contracts 1.2, `build-avatar` replaces Archer assumptions with an
explicit pinned family recipe: catalogs, compatible equipment adapters, semantic
actions, clip policies, animation root and portraits. `build-archer` retains its
historical defaults for reproducibility. `build-family` selects only the recipe in
`registries/families/<family-id>.json` and refuses source-required entries or recipe
overrides. Registry data belongs to the workshop; consumer import has no registry
or workshop-checkout dependency.

`build-asset-pack` packages typed avatars, creatures, mounts, props, environments,
equipment, animation libraries and PNG images. Every source variant is pinned by
workshop-relative `assets/` path, SHA-256 and byte count. Animations use explicit
semantic mappings, optional measured bounds, declared rig adapters and clip policies;
durations come from the actual GLB. Evolution edges reference members of the same
family and describe lineage only. The runtime does not retarget or grant game rules.
Static/animated parts and incompatible bind poses remain explicit separate variants.

Workshop handoffs are generated separately from immutable runtime payloads:

```sh
abby-assets handoff --workspace /workshop --release .local/releases/FAMILY/VERSION/DIGEST --output deliveries --package-dir .local/packages --qa .local/qa-report.json
abby-assets verify-handoff --workspace /workshop --handoff deliveries/FAMILY/VERSION/DIGEST/handoff.json
```

Omit `--qa` for a preparing draft. A ready handoff requires the registry's named QA
gates plus release integrity and private publication, explicit evidence hashes,
the exact manifest and code artifact digests/SRI. Code archives are checked against
the current package publish files, so stale same-version artifacts fail. Missing
checks remain pending; a path, schema pass or historical app test is not acceptance.
Verified source backup metadata requires a matching hashed snapshot receipt.
Each application adopts the handoff independently and records its own rollback
baseline. Handoff creation never imports into, merges or deploys an application.

`build-file-library` (contracts 1.1 / tools 1.3) packages prepared runtime files with
their existing application URL mapping. It supports PNG, self-contained GLB,
structurally sanitized binary FBX and reviewed runtime JSON. The avatar manifest
validator stays unchanged; `validateFileLibraryManifest` validates this new kind,
and `validateAnyManifest` accepts avatar, file-library and typed asset-pack releases.

```sh
abby-assets build-file-library --workspace /workshop --recipe /private/release-recipe.json --version 1.0.0 --output /private/releases
```

The private recipe contains `schema_version: 1`, `family_id`, `label`, and `entries`.
Each entry pins `id`, `runtime_path`, workshop-relative `file` under `assets/`,
`sha256`, `bytes` and `media_type`. The output manifest has `kind: "file-library"`;
its entries replace the source `file` with `objects/<SHA256>.<extension>` and retain
`runtime_path` (for example `assets/chick/model.fbx`). Payloads are deduplicated by
hash. Import/verify/publish and lockfiles work for both kinds. Applications validate
the manifest and copy only pinned entries to their existing URLs. Source maps,
archives, editable masters and receipts belong outside the runtime tree.

The workshop FBX migration parses typed binary properties and rebuilds node offsets
and footer alignment. Only path-bearing string properties change to safe basenames;
numeric, raw and compressed property bytes remain exact. Unknown binary layouts
fail closed. Source FBXs remain private and untouched. Verification also compares
the receiving Three FBXLoader geometry, skin, transforms and animation numbers;
this check stubs image decoding and does not establish visual or phone performance.

Publish to Spaces only with an explicit bucket, endpoint and region:

```sh
abby-assets publish --release /private/releases/FAMILY/VERSION/DIGEST --s3-bucket RUNTIME_BUCKET --s3-endpoint https://REGION.digitaloceanspaces.com --s3-region REGION --s3-prefix releases
```

All objects use private ACLs and conditional writes. Existing objects must match
exactly. Uploads are downloaded and hashed for verification. A version reservation
prevents a different digest being assigned to an existing family/version; the release
manifest uploads last, after every runtime object verifies. Interrupted publishes can
be retried with identical content. Conditional-write failures stop the publish;
the tool never falls back to overwriting. No buckets, keys, public policies, CDN
settings, versioning settings or remote deletions are created by this command.

Workshop tooling 1.1.1 checks conditional-write capability before sending any new
release or backup object. A shared per-store probe writes synthetic private bytes
under `pipeline-checks/`, requires HTTP 412 for a replacement attempt, and verifies
that the original bytes survived. A failed probe blocks every new upload worker;
there is no overwrite fallback. Existing identical objects still require no PUT,
and imports, reads and restores never run this write probe.

On 14 October 2026, both versioned sfo3 workshop buckets failed that conditional
check even though their version histories worked. GET-before-PUT cannot supply an
atomic reservation. Tooling 1.2.0 supports a permanent write coordinator for this
case; uncoordinated stores still require the conditional capability probe.

Set `ABBY_ASSETS_WRITE_COORDINATOR` or `--write-coordinator` to a pinned JSON
configuration. Before a PUT, an authenticated SSH service durably binds the exact
endpoint, bucket and full object key to its SHA-256 and byte count in SQLite.
Claims never expire, change or get deleted. Identical concurrent/retried uploads
are safe; conflicting bytes are refused even when an earlier writer crashed or
its upload completes late. The server receives only checksums and object names,
not asset bytes or Spaces credentials. Every existing identical object also
adopts its claim before being accepted.

The coordinator UUID and namespace are pinned. Missing state, an unavailable
server or a mismatching response blocks uploads without a provider-only fallback.
Imports and restores remain read-only and never connect to it. All writers for a
namespace must use the same authority; raw S3 commands and older tools do not
participate in this application guarantee. This is not a provider object-lock
policy against an administrator holding write credentials.

See [the workshop coordinator guide](../../docs/write-coordinator.md) for setup
and recovery. A ledger backup is recovery evidence, not permission to roll the
live authority back. Never resume an older same-UUID database as if it held all
claims; recover a complete claim superset or move new writes to an unused
namespace and authority. Keep bucket versioning enabled.

## Source backup

Workshop tooling 1.1.0 adds bounded backup workers, progress, explicit extra roots
and verified restoration. Consumer imports remain compatible with tooling 1.0.0.

Use a new, explicitly selected destination outside the workshop:

```sh
abby-assets backup --workspace /workshop --destination /private-backups/snapshot-id
abby-assets backup --workspace /workshop --snapshot SNAPSHOT_ID --s3-bucket SOURCE_BACKUP_BUCKET --s3-endpoint https://REGION.digitaloceanspaces.com --s3-region REGION --s3-prefix backups
```

Backups cover every regular file under `Meshtint/Originals` and `assets`, including
archives, meshes, editable sources, recipes and evidence. Symlinks are refused.
Local copies are reread and hashed. Cloud payloads are deduplicated by SHA-256 and
verified by readback before the immutable snapshot manifest is uploaded. Backup
credentials should have no relationship to the consumer applications. Configure
bucket versioning separately through the provider's API after selecting the actual
backup bucket; this command never changes account settings.

A backup is not complete until the command reports `verified: true`. Actual external
storage backup and a restoration drill remain operational requirements; this package
does not claim that a local-only generated release supplies disaster recovery.

Backups accept `--include relative/directory` (comma-separated for multiple roots)
and `--concurrency 1` through `4`. Original archives and assets are always included.
Uploaded bytes are deduplicated, read back and hashed before the manifest is
committed. Sources must retain their size and modification time for the snapshot.
Logical progress is written to stderr; the final JSON result remains on stdout.

Restore into a destination that does not exist:

```sh
abby-assets restore --snapshot SNAPSHOT_ID --destination NEW_DIRECTORY --manifest-sha256 PINNED_DIGEST --s3-bucket SOURCE_BACKUP_BUCKET --s3-endpoint https://REGION.digitaloceanspaces.com --s3-region us-east-1 --s3-prefix backups
abby-assets restore --backup LOCAL_SNAPSHOT_DIRECTORY --destination NEW_DIRECTORY --manifest-sha256 PINNED_DIGEST
```

Restore validates source paths, duplicate/case collisions and the optional exact
manifest pin. It verifies each object before writing, rereads the local output,
then renames a complete sibling staging tree into place. Existing destinations
and symlinked paths are refused. Failure leaves no claimed completed restore.

The workshop's `npm run spaces:backup` wrapper includes a clean committed Git
bundle, portrait, recovery context and a consistent ledger evidence snapshot.
A local per-snapshot guard protects input preparation through receipt creation.
Its immutable receipt supplies the pin for
`node tools/releases/spaces.mjs restore SNAPSHOT_ID NEW_DIRECTORY`.

Provider references: [Spaces SDK support](https://docs.digitalocean.com/products/spaces/reference/aws-sdks/),
[S3 compatibility and versioning](https://docs.digitalocean.com/products/spaces/reference/s3-compatibility/),
[access scopes](https://docs.digitalocean.com/products/spaces/how-to/manage-access/).
