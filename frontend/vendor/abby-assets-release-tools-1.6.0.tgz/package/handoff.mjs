import { createHash, randomUUID } from 'node:crypto';
import { readFile, writeFile, mkdir, rename, lstat, readdir, realpath } from 'node:fs/promises';
import path from 'node:path';
import { gunzipSync } from 'node:zlib';
import { canonicalJson, digest, verifyRelease, validateLock } from './index.mjs';
import { readFamilyRegistry, workshopFile } from './families.mjs';

const packageDirectories = ['contracts', 'runtime', 'release-tools'];
const relativeTo = (root, file) => path.relative(root, file).split(path.sep).join('/');
const versionsOf = packages => packages.map(({ name, version }) => ({ name, version })).sort((a, b) => a.name.localeCompare(b.name));
const pinsOf = packages => packages.map(({ name, version, sha256, integrity }) => ({ name, version, sha256: sha256 ?? null, integrity: integrity ?? null })).sort((a, b) => a.name.localeCompare(b.name));
const same = (a, b) => canonicalJson(a) === canonicalJson(b);
const fileExists = async file => { try { await lstat(file); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; } };

function tarEntries(bytes) {
  const tar = gunzipSync(bytes, { maxOutputLength: 16 * 1024 * 1024 });
  const result = new Map();
  for (let offset = 0; offset + 512 <= tar.length;) {
    const name = tar.subarray(offset, offset + 100).toString().replace(/\0.*$/, '');
    if (!name) break;
    const size = parseInt(tar.subarray(offset + 124, offset + 136).toString().replace(/\0.*$/, '').trim(), 8) || 0;
    if (!Number.isSafeInteger(size) || size < 0 || offset + 512 + size > tar.length) throw new Error('Invalid code package tar');
    const type = tar[offset + 156];
    if ((type !== 0 && type !== 48) || !name.startsWith('package/') || result.has(name)) throw new Error('Code package contains a nonregular or duplicate entry');
    result.set(name, tar.subarray(offset + 512, offset + 512 + size));
    offset += 512 + Math.ceil(size / 512) * 512;
  }
  if (!result.has('package/package.json')) throw new Error('Code artifact has no package/package.json');
  return result;
}

async function verifyCodeArtifact(workspace, artifact, expected) {
  const bytes = await readFile(await workshopFile(workspace, artifact)), entries = tarEntries(bytes);
  const metadata = JSON.parse(entries.get('package/package.json'));
  if (metadata.name !== expected.name || metadata.version !== expected.version) throw new Error(`Code artifact identity mismatch: ${artifact}`);
  const directory = packageDirectories.find(name => ({ contracts: '@abby-assets/contracts', runtime: '@abby-assets/avatar-runtime', 'release-tools': '@abby-assets/release-tools' })[name] === metadata.name);
  if (!directory) throw new Error('Unknown code package');
  const sourceRoot = `packages/${directory}`, expectedFiles = new Set(['package.json']);
  async function include(relative) {
    const absolute = path.join(workspace, sourceRoot, relative), info = await lstat(absolute);
    if (info.isSymbolicLink()) throw new Error('Symbolic link in published code sources');
    if (info.isDirectory()) for (const name of await readdir(absolute)) await include(`${relative}/${name}`);
    else if (info.isFile()) expectedFiles.add(relative);
    else throw new Error('Nonregular code source');
  }
  const current = JSON.parse(await readFile(await workshopFile(workspace, `${sourceRoot}/package.json`), 'utf8'));
  for (const entry of current.files || []) await include(entry);
  for (const name of await readdir(path.join(workspace, sourceRoot))) if (/^(?:readme|licen[cs]e)(?:\.|$)/i.test(name)) await include(name);
  if (entries.size !== expectedFiles.size) throw new Error(`Code artifact file list is stale: ${artifact}`);
  for (const file of expectedFiles) {
    const source = await readFile(await workshopFile(workspace, `${sourceRoot}/${file}`));
    if (!entries.get(`package/${file}`)?.equals(source)) throw new Error(`Code artifact differs from current published sources: ${artifact}/${file}`);
  }
  return { bytes, metadata };
}

async function codePackages(workspace, packageDir) {
  const packages = [];
  for (const directory of packageDirectories) {
    const metadata = JSON.parse(await readFile(await workshopFile(workspace, `packages/${directory}/package.json`), 'utf8'));
    const filename = `${metadata.name.replace(/^@/, '').replace('/', '-')}-${metadata.version}.tgz`;
    const artifact = packageDir ? relativeTo(workspace, path.resolve(workspace, packageDir, filename)) : null;
    let hashes = { artifact: null, sha256: null, integrity: null };
    if (artifact && await fileExists(path.join(workspace, artifact))) {
      const { bytes } = await verifyCodeArtifact(workspace, artifact, metadata);
      hashes = { artifact, sha256: digest(bytes), integrity: `sha512-${createHash('sha512').update(bytes).digest('base64')}` };
    }
    packages.push({ name: metadata.name, version: metadata.version, ...hashes });
  }
  return packages;
}

function summarize(manifest) {
  if (!manifest.kind) return {
    assets: [{ id: manifest.family_id, label: manifest.label, kind: 'avatar', capabilities: ['model', 'skinned', 'animated', 'appearance', 'equipment'] }],
    configuration: { schema: 'avatar-configuration-v2', defaults: { schema_version: 2, family_id: manifest.family_id, appearance: manifest.appearance.defaults, slots: {}, emission_enabled: manifest.appearance.emission.default_enabled }, options: [...Object.entries(manifest.appearance.selectors).map(([selector, values]) => ({ selector, values })), { selector: 'equipment', catalogs: manifest.equipment_catalogs }, { selector: 'emission_enabled', values: [false, true] }] },
    actions: Object.entries(manifest.animations.actions).map(([semantic, clip]) => ({ asset_id: null, variant_id: null, semantic, clip })),
    variants: manifest.appearance.base_variants,
    animations: manifest.animations,
  };
  if (manifest.kind === 'asset-pack') return {
    assets: manifest.assets.map(({ variants, ...asset }) => asset),
    configuration: { schema: 'asset-selection-v1', defaults: { family_id: manifest.family_id, selections: manifest.assets.map(asset => ({ asset_id: asset.id, variant_id: asset.default_variant })) }, options: manifest.assets.map(asset => ({ asset_id: asset.id, variants: asset.variants.map(({ id, label }) => ({ id, label })) })) },
    actions: manifest.assets.flatMap(asset => asset.variants.flatMap(variant => Object.entries(variant.animations?.actions || {}).map(([semantic, clip]) => ({ asset_id: asset.id, variant_id: variant.id, semantic, clip })))),
    variants: manifest.assets.flatMap(asset => asset.variants.map(variant => ({ asset_id: asset.id, ...variant }))),
    relationships: manifest.relationships,
    ...(manifest.appearance_bindings ? { appearance_bindings: manifest.appearance_bindings } : {}),
  };
  return { assets: manifest.entries, configuration: { schema: null, defaults: null, options: [] }, actions: [], variants: [] };
}

async function checkEvidence(workspace, check, pin, packages) {
  if (!check || !['passed', 'pending', 'failed', 'not_applicable'].includes(check.status) || typeof check.scope !== 'string' || !check.scope || !Array.isArray(check.evidence) || !Array.isArray(check.notes) || !check.context) throw new Error(`Invalid QA check: ${check?.id}`);
  if (check.status !== 'passed') return;
  if (check.context.release_manifest_sha256 !== pin.manifest_sha256 || !same(pinsOf(check.context.code_packages || []), pinsOf(packages))) throw new Error(`QA context differs from release or exact code artifact pins: ${check.id}`);
  if (!check.evidence.length) throw new Error(`Passed QA check has no evidence: ${check.id}`);
  for (const evidence of check.evidence) {
    const bytes = await readFile(await workshopFile(workspace, evidence.path));
    if (digest(bytes) !== evidence.sha256) throw new Error(`QA evidence integrity mismatch: ${check.id}/${evidence.path}`);
  }
}

async function checkBackup(workspace, backup) {
  if (!backup || !['pending', 'verified', 'not_applicable'].includes(backup.status) || !Array.isArray(backup.notes)) throw new Error('Invalid source backup status');
  if (backup.status !== 'verified') return;
  const pin = backup.pin;
  if (!pin || typeof pin.snapshot !== 'string' || !/^[a-f0-9]{64}$/.test(pin.manifest_sha256) || !pin.receipt?.path || !/^[a-f0-9]{64}$/.test(pin.receipt.sha256)) throw new Error('Verified source backup needs a snapshot/manifest pin and hashed receipt');
  const bytes = await readFile(await workshopFile(workspace, pin.receipt.path)), receipt = JSON.parse(bytes);
  if (digest(bytes) !== pin.receipt.sha256 || receipt.snapshot !== pin.snapshot || receipt.manifest_sha256 !== pin.manifest_sha256) throw new Error('Source backup receipt differs from its pin');
}

const rigIds = manifest => manifest.appearance?.rig_adapter_ids || [...new Set((manifest.assets || []).flatMap(asset => asset.variants.map(variant => variant.rig_adapter_id).filter(Boolean)))];
const runtimeFor = (kind, packages) => {
  const name = kind === 'file-library' ? '@abby-assets/release-tools' : '@abby-assets/avatar-runtime';
  return { package: name, version: packages.find(item => item.name === name).version, loader: kind === 'avatar-family' ? 'loadRelease + loadAvatar' : kind === 'asset-pack' ? 'loadAssetPack + loadAsset (GLB only)' : 'file-library importer' };
};

export async function createHandoff({ workspace, release, output, qa, packageDir }) {
  workspace = await realpath(workspace);
  release = path.resolve(workspace, release);
  const manifestPath = relativeTo(workspace, path.join(release, 'manifest.json'));
  await workshopFile(workspace, manifestPath);
  const { manifest, manifest_sha256 } = await verifyRelease(release);
  const family = (await readFamilyRegistry(workspace)).find(item => item.family_id === manifest.family_id);
  if (!family) throw new Error('Register the family before generating its handoff');
  const pin = { family_id: manifest.family_id, release_version: manifest.release_version, manifest_sha256, directory: `${manifest.family_id}/${manifest.release_version}/${manifest_sha256}` };
  const packages = await codePackages(workspace, packageDir);
  const report = qa ? JSON.parse(await readFile(await workshopFile(workspace, relativeTo(workspace, path.resolve(workspace, qa))), 'utf8')) : { checks: [] };
  if (qa && (report.schema_version !== 1 || report.family_id !== pin.family_id || report.manifest_sha256 !== pin.manifest_sha256 || !Array.isArray(report.checks))) throw new Error('QA report must identify this exact family and manifest');
  if (new Set(report.checks.map(check => check.id)).size !== report.checks.length) throw new Error('Duplicate QA report check');
  const required = [...new Set([...family.qa_policy.required_checks, 'release-integrity', 'private-publication'])];
  const context = { release_manifest_sha256: manifest_sha256, code_packages: pinsOf(packages) };
  const checks = required.map(id => id === 'release-integrity'
    ? { id, required: true, status: 'passed', scope: 'Immutable manifest and every payload byte verified locally', context, evidence: [{ path: manifestPath, sha256: manifest_sha256 }], notes: ['Integrity verification does not establish visual or renderer acceptance.'] }
    : { ...(report.checks.find(check => check.id === id) || { id, status: 'pending', scope: 'Workshop acceptance', context, evidence: [], notes: ['Explicit acceptance evidence is required.'] }), required: true });
  checks.push(...report.checks.filter(check => !required.includes(check.id)).map(check => ({ ...check, required: false })));
  for (const check of checks) await checkEvidence(workspace, check, pin, packages);
  const remaining = checks.filter(check => check.required && check.status !== 'passed').map(check => `${check.id}: ${check.status}`);
  if (packages.some(item => !item.artifact)) remaining.push('Pack the current code packages and regenerate with --package-dir.');
  const kind = manifest.kind || 'avatar-family';
  const handoff = {
    schema_version: 1, kind: 'asset-release-handoff', status: remaining.length ? 'preparing' : 'ready', family_id: pin.family_id, label: manifest.label, release_kind: kind,
    release: { pin, workshop_previous_pin: family.previous_pin || null, manifest_path: manifestPath, files_count: manifest.files.length, total_bytes: manifest.files.reduce((sum, file) => sum + file.bytes, 0), private_delivery: { method: 'digest-pinned-private-import', locator: null, notes: ['Use the configured private release store and least-privilege read credentials. Never paste credentials or expiring signed URLs into this handoff.'] } },
    code_packages: packages, content: summarize(manifest),
    compatibility: { runtime: runtimeFor(kind, packages), rig_adapter_ids: rigIds(manifest), renderers: report.renderers || [], restrictions: [...(family.compatibility?.notes || []), 'A matching bone name or vendor series does not establish animation or equipment compatibility.', 'App registration, selection UI, saved configurations, ownership and rewards are handled in each app session.'] },
    qa: { required_checks: required, checks, remaining },
    source_backup: report.source_backup || { status: 'pending', pin: null, notes: ['No backup verification was supplied for this handoff.'] },
    consumers: family.handoff.consumers.map(consumer_id => ({ consumer_id, adoption_status: 'pending', instructions: ['Read this handoff and the application repository instructions in that application session.', 'Install the digest-verified code packages only if the application needs this API version.', 'Add or update this family in the application asset lock without dropping other families; import from the private store and verify.', 'Register this content in application data and persist family_id with the asset/variant or avatar configuration.', 'Review application-specific changes in a PR and stage before promoting.'], verification: ['Check the selected model and every declared motion in the application renderer.', 'For avatars, check appearance, equipment fit, saved selection and complete idle/walk/run/jump motions.', 'Verify on a real phone and exercise application save/load and authorization behavior.'], rollback: { previous_pin: null, steps: ['Record this application’s current lock, code package versions and configuration data before adoption. Its actual baseline is unknown to the workshop; the previous workshop release is not an app rollback target.', 'Revert the adoption PR and restore the application’s previous pins, then reimport and verify.', 'For a newly introduced family, migrate or clear its saved selections before removing support.'] } })),
  };
  const directory = path.resolve(workspace, output, pin.directory);
  const inside = relativeTo(workspace, directory);
  if (!inside || inside.startsWith('../') || path.isAbsolute(inside)) throw new Error('Handoff output must stay inside the workshop');
  await checkBackup(workspace, handoff.source_backup);
  for (let current = directory; current !== workspace; current = path.dirname(current)) {
    if (await fileExists(current)) {
      const info = await lstat(current);
      if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Handoff output path must contain only regular directories');
    }
  }
  await mkdir(directory, { recursive: true });
  await writeAtomic(path.join(directory, 'handoff.json'), canonicalJson(handoff));
  await writeAtomic(path.join(directory, 'handoff.md'), markdown(handoff));
  await verifyHandoff({ workspace, handoff: path.join(directory, 'handoff.json') });
  return { directory, status: handoff.status, family_id: pin.family_id, manifest_sha256, remaining };
}

export async function verifyHandoff({ workspace = process.cwd(), handoff: filename }) {
  filename = path.resolve(workspace, filename);
  const value = JSON.parse(await readFile(await workshopFile(workspace, relativeTo(workspace, filename)), 'utf8'));
  if (value.schema_version !== 1 || value.kind !== 'asset-release-handoff' || !['preparing', 'ready'].includes(value.status)) throw new Error('Invalid handoff');
  const pin = value.release?.pin; validateLock({ schema_version: 1, releases: [pin] });
  if (value.family_id !== pin.family_id) throw new Error('Handoff family differs from its pin');
  const family = (await readFamilyRegistry(workspace)).find(item => item.family_id === pin.family_id);
  if (!family) throw new Error('Handoff family is not registered');
  const manifestFile = await workshopFile(workspace, value.release.manifest_path || `.local/releases/${pin.directory}/manifest.json`);
  const { manifest } = await verifyRelease(path.dirname(manifestFile), pin.manifest_sha256);
  if (manifest.family_id !== pin.family_id || manifest.release_version !== pin.release_version || value.release_kind !== (manifest.kind || 'avatar-family') || value.label !== manifest.label || value.release.files_count !== manifest.files.length || value.release.total_bytes !== manifest.files.reduce((sum, file) => sum + file.bytes, 0) || !same(value.content, summarize(manifest))) throw new Error('Handoff content differs from the verified release');
  if (!Array.isArray(value.code_packages) || new Set(value.code_packages.map(item => item.name)).size !== packageDirectories.length) throw new Error('Handoff code package set is incomplete or duplicated');
  const expected = await codePackages(workspace, null);
  if (!same(versionsOf(value.code_packages), versionsOf(expected))) throw new Error('Handoff code package versions differ from this workshop; regenerate it');
  if (!same(value.compatibility?.runtime, runtimeFor(value.release_kind, value.code_packages)) || !same(value.compatibility?.rig_adapter_ids, rigIds(manifest))) throw new Error('Handoff runtime compatibility differs from the manifest or code packages');
  for (const item of value.code_packages) if (item.artifact !== null) {
    const { bytes, metadata } = await verifyCodeArtifact(workspace, item.artifact, item);
    if (digest(bytes) !== item.sha256 || `sha512-${createHash('sha512').update(bytes).digest('base64')}` !== item.integrity || metadata.name !== item.name || metadata.version !== item.version) throw new Error(`Handoff code artifact integrity mismatch: ${item.name}`);
  }
  const required = [...new Set([...family.qa_policy.required_checks, 'release-integrity', 'private-publication'])];
  if (!Array.isArray(value.qa?.checks) || new Set(value.qa.checks.map(check => check.id)).size !== value.qa.checks.length) throw new Error('Invalid or duplicate handoff QA checks');
  for (const id of required) if (!value.qa.checks.some(check => check.id === id && check.required === true)) throw new Error(`Handoff omits required gate: ${id}`);
  for (const check of value.qa.checks) await checkEvidence(workspace, check, pin, value.code_packages);
  const ready = value.qa.checks.every(check => !check.required || check.status === 'passed') && value.code_packages.every(item => item.artifact && item.sha256 && item.integrity);
  const remaining = value.qa.checks.filter(check => check.required && check.status !== 'passed').map(check => `${check.id}: ${check.status}`);
  if (value.code_packages.some(item => !item.artifact)) remaining.push('Pack the current code packages and regenerate with --package-dir.');
  if (!same(value.qa.remaining, remaining) || !same(value.qa.required_checks, required)) throw new Error('Handoff remaining gates differ from its actual checks');
  if (value.status !== (ready ? 'ready' : 'preparing')) throw new Error('Handoff status disagrees with acceptance gates');
  if (!Array.isArray(value.consumers) || !same(value.consumers.map(item => item.consumer_id).sort(), [...family.handoff.consumers].sort()) || value.consumers.some(item => item.adoption_status !== 'pending')) throw new Error('Handoff must leave every consumer adoption pending');
  for (const consumer of value.consumers) {
    if (!consumer.rollback || !Array.isArray(consumer.rollback.steps)) throw new Error('Handoff consumer rollback plan is missing');
    if (consumer.rollback.previous_pin !== null) {
      validateLock({ schema_version: 1, releases: [consumer.rollback.previous_pin] });
      if (consumer.rollback.previous_pin.family_id !== pin.family_id) throw new Error('Consumer rollback pin belongs to another family');
    }
  }
  await checkBackup(workspace, value.source_backup);
  return { status: value.status, family_id: pin.family_id, manifest_sha256: pin.manifest_sha256, verified: true };
}

async function writeAtomic(file, content) {
  const temporary = `${file}.${randomUUID()}.tmp`;
  await writeFile(temporary, content, { flag: 'wx' }); await rename(temporary, file);
}

function markdown(value) {
  const pin = value.release.pin;
  const code = text => `\`${String(text).replaceAll('`', '\\`').replaceAll('|', '\\|')}\``;
  const bullets = items => items.length ? items.map(item => `- ${item}`).join('\n') : 'None declared.';
  const json = item => `\`\`\`json\n${JSON.stringify(item, null, 2)}\n\`\`\``;
  const options = value.content.configuration.options.map(option => option.selector === 'equipment'
    ? `Equipment: ${option.catalogs.map(catalog => `${catalog.rig_adapter_id}: ${catalog.items.length} fitted items (${catalog.items.map(item => `${item.slot}/${item.id}`).join(', ')})`).join('; ')}`
    : option.selector ? `${option.selector}: ${(option.values || []).map(item => typeof item === 'object' ? item.id : item).join(', ')}`
      : `${option.asset_id}: ${(option.variants || []).map(item => item.id).join(', ')}`);
  const clips = value.content.animations?.clips?.map(clip => ({ scope: 'all bases', ...clip })) || value.content.variants.flatMap(variant => (variant.animations?.clips || []).map(clip => ({ scope: `${variant.asset_id}/${variant.id}`, ...clip })));
  return [
    `# ${value.label} ${pin.release_version}`,
    `Workshop handoff: **${value.status}**. Adoption remains pending in each application.`,
    bullets([`Family: ${code(pin.family_id)}`, `Manifest SHA-256: ${code(pin.manifest_sha256)}`, `Immutable directory: ${code(pin.directory)}`, `Verification workspace manifest: ${code(value.release.manifest_path)}`, `Release kind: ${code(value.release_kind)}`, `Payload: ${value.release.files_count} files, ${value.release.total_bytes} bytes`, `Private delivery: ${value.release.private_delivery.method}; use configured private reader credentials.`]),
    '## Code packages',
    ...value.code_packages.map(item => `### ${item.name}@${item.version}\n\n${bullets([`Artifact: ${code(item.artifact || 'not packed')}`, `SHA-256: ${code(item.sha256 || 'pending')}`, `npm integrity: ${code(item.integrity || 'pending')}`])}`),
    '## Content and configuration',
    bullets(value.content.assets.map(asset => `${asset.id}: ${asset.label || asset.runtime_path || asset.id}${asset.kind ? ` (${asset.kind})` : ''}${asset.default_variant ? `, default variant ${asset.default_variant}` : ''}`)),
    `Configuration schema: ${code(value.content.configuration.schema || 'none')}. Defaults:`,
    json(value.content.configuration.defaults),
    'Supported options:', bullets(options),
    `${value.content.variants.length} prepared variants. Exact file hashes, clip policies and per-variant compatibility are in the adjacent handoff.json and pinned manifest.`,
    '## Semantic actions',
    value.content.actions.length ? `| Asset | Variant | Action | Clip |\n| --- | --- | --- | --- |\n${value.content.actions.map(action => `| ${code(action.asset_id || 'family')} | ${code(action.variant_id || 'all bases')} | ${code(action.semantic)} | ${code(action.clip)} |`).join('\n')}` : 'No animation actions declared.',
    ...(clips.length ? ['Clip policies:', `| Scope | Clip | Seconds | Loop | Root motion |\n| --- | --- | --- | --- | --- |\n${clips.map(clip => `| ${code(clip.scope)} | ${code(clip.name)} | ${clip.duration ?? 'unknown'} | ${clip.loop ?? 'unknown'} | ${clip.root_motion ?? 'unknown'} |`).join('\n')}`] : []),
    ...(value.content.relationships?.length ? ['Descriptive lineage (application progression rules are separate):', bullets(value.content.relationships.map(edge => `${edge.type}: ${edge.from_asset_id} → ${edge.to_asset_id}${edge.transition ? `; animation ${edge.transition.asset_id}/${edge.transition.variant_id}, action ${edge.transition.action}` : ''}`))] : []),
    ...(value.content.appearance_bindings ? [`Appearance binding extension: ${code('appearance-bindings-v' + value.content.appearance_bindings.schema_version)}. ${value.content.appearance_bindings.stages.length} exact species/potion/stage/motion bindings and ${value.content.appearance_bindings.transitions.length} transition bindings are retained in handoff.json and the immutable manifest. Native variant IDs remain animation identities.`] : []),
    '## Compatibility',
    `Runtime: ${code(value.compatibility.runtime.package)} ${code(value.compatibility.runtime.version)}; ${code(value.compatibility.runtime.loader)}.`,
    `Inspected rig adapters: ${value.compatibility.rig_adapter_ids.length ? value.compatibility.rig_adapter_ids.map(code).join(', ') : 'none declared'}.`,
    `Renderer evidence contexts: ${value.compatibility.renderers.length ? JSON.stringify(value.compatibility.renderers) : 'pending; no current renderer acceptance is inferred'}.`,
    bullets(value.compatibility.restrictions),
    '## Acceptance and evidence',
    ...value.qa.checks.map(check => `### ${check.id}: ${check.status}${check.required ? ' (required)' : ''}\n\n${check.scope}\n\nContext: manifest ${code(check.context.release_manifest_sha256 || 'unknown')}; ${check.context.code_packages.map(item => `${item.name}@${item.version} SHA-256 ${code(item.sha256 || 'unknown')}`).join('; ')}. Exact npm integrity is recorded with the code packages above and in handoff.json.\n\n${bullets(check.evidence.map(item => `${code(item.path)} — SHA-256 ${code(item.sha256 || 'pending')}`))}\n\n${bullets(check.notes)}`),
    'Remaining:', value.qa.remaining.length ? bullets(value.qa.remaining) : 'All required workshop gates passed for this exact release and code artifact context.',
    '## Source backup', `Status: **${value.source_backup.status}**.`, json(value.source_backup.pin), bullets(value.source_backup.notes),
    '## Workshop release history',
    `Previous workshop release (reference only; each app records its own rollback baseline):`, json(value.release.workshop_previous_pin),
    '## Application handoff',
    ...value.consumers.map(consumer => `### ${consumer.consumer_id}\n\nAdoption: **${consumer.adoption_status}**.\n\n${consumer.instructions.map((step, index) => `${index + 1}. ${step}`).join('\n')}\n\nVerify:\n\n${bullets(consumer.verification)}\n\nApplication rollback baseline:\n\n${json(consumer.rollback.previous_pin)}\n\n${bullets(consumer.rollback.steps)}`),
    'The adjacent handoff.json is the machine-readable source for exact configuration, variant, action, evidence and rollback pins. Paid payloads remain in the private release store.',
  ].join('\n\n') + '\n';
}
