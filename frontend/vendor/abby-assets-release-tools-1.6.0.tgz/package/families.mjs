import { readFile, readdir, realpath, lstat } from 'node:fs/promises';
import path from 'node:path';
import { validateAssetPackManifest, isSafeRelativePath } from '@abby-assets/contracts';
import { buildAvatarFamily, buildFileLibrary, digest, readGlb, runtimeGlb, glbClipDuration, writePreparedRelease, validateLock } from './index.mjs';

export async function workshopFile(workspace, relative) {
  if (!isSafeRelativePath(relative)) throw new Error(`Unsafe workshop path: ${relative}`);
  const root = await realpath(workspace), absolute = path.resolve(root, relative), resolved = await realpath(absolute);
  const inside = path.relative(root, resolved);
  if (inside === '..' || inside.startsWith(`..${path.sep}`) || path.isAbsolute(inside)) throw new Error(`Workshop path escaped: ${relative}`);
  for (let current = absolute; current !== root; current = path.dirname(current)) {
    const info = await lstat(current);
    if (info.isSymbolicLink()) throw new Error(`Symbolic link in workshop path: ${relative}`);
  }
  if (!(await lstat(absolute)).isFile()) throw new Error(`Expected workshop file: ${relative}`);
  return absolute;
}

export async function readFamilyRegistry(workspace) {
  const directory = path.join(workspace, 'registries/families'), result = [];
  for (const name of (await readdir(directory)).filter(name => name.endsWith('.json')).sort()) {
    const file = await workshopFile(workspace, `registries/families/${name}`), family = JSON.parse(await readFile(file, 'utf8'));
    if (family.schema_version !== 1 || !/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(family.family_id) || name !== `${family.family_id}.json`
      || !['avatar-family', 'asset-pack', 'file-library'].includes(family.kind) || !['available', 'preparing', 'source-required', 'retired'].includes(family.status)
      || typeof family.label !== 'string' || !family.label || !Array.isArray(family.qa_policy?.required_checks)
      || new Set(family.qa_policy.required_checks).size !== family.qa_policy.required_checks.length
      || family.qa_policy.required_checks.some(id => typeof id !== 'string' || !id)
      || !Array.isArray(family.handoff?.consumers) || (family.status === 'available' && !family.handoff.consumers.length)
      || family.handoff.consumers.some(id => typeof id !== 'string' || !id)) throw new Error(`Invalid family registry: ${name}`);
    for (const key of ['recipe', 'lock']) if (family[key] !== null && (!isSafeRelativePath(family[key]) || typeof family[key] !== 'string')) throw new Error(`Invalid family ${key}: ${name}`);
    for (const key of ['current_pin', 'previous_pin']) if (family[key] != null) {
      validateLock({ schema_version: 1, releases: [family[key]] });
      if (family[key].family_id !== family.family_id) throw new Error(`Cross-family ${key}: ${name}`);
    }
    if (family.lock) {
      const lock = validateLock(JSON.parse(await readFile(await workshopFile(workspace, family.lock), 'utf8')));
      const pin = lock.releases.find(pin => pin.family_id === family.family_id);
      if (!pin || !family.current_pin || pin.manifest_sha256 !== family.current_pin.manifest_sha256 || pin.release_version !== family.current_pin.release_version) throw new Error(`Registry and lock disagree: ${name}`);
    }
    result.push(family);
  }
  return result;
}

export async function buildFamily({ workspace, family: id, ...options }) {
  if (options.recipe) throw new Error('build-family uses the registry recipe; use a direct builder to select a different recipe');
  const family = (await readFamilyRegistry(workspace)).find(item => item.family_id === id);
  if (!family) throw new Error(`Unknown family: ${id}`);
  if (!family.recipe || ['source-required', 'retired'].includes(family.status)) throw new Error(`Family ${id} is ${family.status}; prepare inspected source and a recipe first`);
  await workshopFile(workspace, family.recipe);
  const recipe = path.resolve(workspace, family.recipe), prepared = JSON.parse(await readFile(recipe, 'utf8'));
  if (prepared.family_id !== id) throw new Error('Registry and recipe family disagree');
  const build = { 'avatar-family': buildAvatarFamily, 'asset-pack': buildAssetPack, 'file-library': buildFileLibrary }[family.kind];
  return build({ ...options, workspace, recipe });
}

export async function buildAssetPack({ workspace, recipe, version = '1.0.0', output }) {
  workspace = await realpath(workspace);
  const relative = path.relative(workspace, path.resolve(workspace, recipe)).split(path.sep).join('/');
  const prepared = JSON.parse(await readFile(await workshopFile(workspace, relative), 'utf8'));
  if (prepared.schema_version !== 1 || prepared.kind !== 'asset-pack' || !Array.isArray(prepared.assets)
    || Object.keys(prepared).some(key => !['schema_version', 'kind', 'family_id', 'label', 'assets', 'relationships', 'appearance_bindings'].includes(key))) throw new Error('Invalid typed asset pack recipe');
  const objects = new Map(), audit = [], assets = [];
  for (const asset of prepared.assets) {
    const variants = [];
    for (const variant of asset.variants || []) {
      const pin = variant.file;
      if (!pin || Object.keys(pin).some(key => !['file', 'sha256', 'bytes'].includes(key)) || !pin.file?.startsWith('assets/') || !/^[a-f0-9]{64}$/.test(pin.sha256) || !Number.isSafeInteger(pin.bytes)) throw new Error('Pack variant must pin a prepared assets file, hash and byte count');
      const source = await workshopFile(workspace, pin.file), input = await readFile(source), extension = path.extname(source).toLowerCase();
      if (input.length !== pin.bytes || digest(input) !== pin.sha256) throw new Error(`Prepared variant integrity mismatch: ${asset.id}/${variant.id}`);
      if (extension !== (asset.kind === 'image' ? '.png' : '.glb')) throw new Error(`Variant media mismatch: ${asset.id}/${variant.id}`);
      const bytes = extension === '.glb' ? runtimeGlb(input) : input;
      const sha256 = digest(bytes), file = `objects/${sha256}${extension}`;
      objects.set(file, bytes);
      let animations = variant.animations;
      if (extension === '.glb') {
        const json = readGlb(bytes).json, exported = json.animations || [], nodes = json.nodes || [];
        const visited = new Set();
        const visit = index => { if (!Number.isInteger(index) || !nodes[index]) throw new Error('Invalid GLB scene node'); if (visited.has(index)) return; visited.add(index); for (const child of nodes[index].children || []) visit(child); };
        for (const index of json.scenes?.[json.scene ?? 0]?.nodes || []) visit(index);
        const visible = [...visited].map(index => nodes[index]);
        const model = visible.some(node => json.meshes?.[node.mesh]?.primitives?.some(primitive => json.accessors?.[primitive.attributes?.POSITION]?.count > 0));
        if (model !== asset.capabilities.includes('model')) throw new Error(`Declared model geometry differs from GLB: ${asset.id}/${variant.id}`);
        const skinned = visible.some(node => node.mesh !== undefined && json.skins?.[node.skin]);
        if (skinned !== asset.capabilities.includes('skinned')) throw new Error(`Declared skinning differs from GLB: ${asset.id}/${variant.id}`);
        if (Boolean(exported.length) !== asset.capabilities.includes('animated')) throw new Error(`Declared animation capability differs from GLB: ${asset.id}/${variant.id}`);
        if (variant.rig_adapter_id && !visible.some(node => node.extras?.avatar_rig_adapter_id === variant.rig_adapter_id || node.extras?.asset_rig_adapter_id === variant.rig_adapter_id)) throw new Error(`Variant adapter metadata mismatch: ${asset.id}/${variant.id}`);
        if (Boolean(exported.length) !== Boolean(animations)) throw new Error(`Declare metadata for every exported clip: ${asset.id}/${variant.id}`);
        if (animations) {
          if (!Array.isArray(animations.clips) || animations.clips.length !== exported.length || new Set(animations.clips.map(clip => clip.name)).size !== exported.length) throw new Error('Declare exactly one policy for every exported clip');
          if (animations.root_node && !visible.some(node => node.name === animations.root_node)) throw new Error(`Variant animation root missing: ${asset.id}/${variant.id}`);
          animations = { ...animations, clips: animations.clips.map(clip => {
            const actual = exported.find(item => item.name === clip.name);
            if (!actual) throw new Error(`Clip missing from variant: ${clip.name}`);
            if (!actual.channels?.length || actual.channels.some(channel => !actual.samplers[channel.sampler] || !visited.has(channel.target?.node))) throw new Error(`Clip has no valid scene targets: ${clip.name}`);
            const duration = glbClipDuration(bytes, actual);
            if (clip.duration != null && Math.abs(clip.duration - duration) > 1e-5) throw new Error(`Clip duration differs from GLB: ${clip.name}`);
            return { ...clip, duration };
          }) };
        }
      }
      variants.push({ ...variant, file, animations });
      audit.push({ asset_id: asset.id, variant_id: variant.id, source: pin.file, source_sha256: pin.sha256, runtime_sha256: sha256 });
    }
    assets.push({ ...asset, variants });
  }
  const manifest = validateAssetPackManifest({ schema_version: 1, kind: 'asset-pack', family_id: prepared.family_id, release_version: version, label: prepared.label, assets, relationships: prepared.relationships || [], ...(prepared.appearance_bindings !== undefined ? { appearance_bindings: prepared.appearance_bindings } : {}), files: [...objects].sort(([a], [b]) => a.localeCompare(b)).map(([file, bytes]) => ({ path: file, sha256: digest(bytes), bytes: bytes.length, media_type: file.endsWith('.glb') ? 'model/gltf-binary' : 'image/png' })) });
  return writePreparedRelease({ workspace, output, manifest, objects, audit });
}
