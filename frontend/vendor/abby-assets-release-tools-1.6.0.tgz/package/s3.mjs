import { createHash, randomUUID } from 'node:crypto';
import { createWriteCoordinator } from './coordinator.mjs';
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const missing = error => error?.$metadata?.httpStatusCode === 404 || ['NoSuchKey', 'NotFound'].includes(error?.name);
const preconditionFailed = error => error?.$metadata?.httpStatusCode === 412 || error?.name === 'PreconditionFailed';
export function s3Configuration(options = {}, env = process.env) {
  const value = { endpoint: options.s3Endpoint || env.ABBY_ASSETS_S3_ENDPOINT, region: options.s3Region || env.ABBY_ASSETS_S3_REGION, bucket: options.s3Bucket || env.ABBY_ASSETS_S3_BUCKET, prefix: options.s3Prefix ?? env.ABBY_ASSETS_S3_PREFIX ?? '' };
  if (!value.endpoint || !value.region || !value.bucket) throw new Error('Spaces requires explicit endpoint, region and bucket (ABBY_ASSETS_S3_ENDPOINT / _REGION / _BUCKET)');
  const endpoint = new URL(value.endpoint);
  if (endpoint.protocol !== 'https:' || endpoint.username || endpoint.password || endpoint.search || endpoint.hash || endpoint.pathname !== '/') throw new Error('Spaces endpoint must be a plain HTTPS origin');
  if (!/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/.test(value.bucket)) throw new Error('Invalid Spaces bucket name');
  if (value.prefix && !value.prefix.split('/').every(part => /^[a-zA-Z0-9._-]+$/.test(part) && part !== '.' && part !== '..')) throw new Error('Unsafe Spaces key prefix');
  return value;
}
export async function createS3Store(options = {}, { client, sdk, env = process.env, coordinator: injectedCoordinator } = {}) {
  const config = s3Configuration(options, env);
  sdk ||= await import('@aws-sdk/client-s3');
  const owned = !client;
  const coordinatorOwned = injectedCoordinator == null;
  // Factory creation is local and lazy; read-only get/import/restore never
  // resolves its configuration or opens an SSH connection.
  const coordinator = injectedCoordinator ?? createWriteCoordinator(options, { env });
  const coordinatorConfigured = coordinator != null || injectedCoordinator != null
    || Boolean(options.writeCoordinator || env.ABBY_ASSETS_WRITE_COORDINATOR);
  client ||= new sdk.S3Client({ endpoint: config.endpoint, region: config.region, forcePathStyle: false, requestChecksumCalculation: 'WHEN_REQUIRED', responseChecksumValidation: 'WHEN_REQUIRED', maxAttempts: 3 });
  const key = relative => { if (!relative || relative.startsWith('/') || relative.includes('\\') || relative.split('/').some(part => !part || part === '.' || part === '..')) throw new Error('Unsafe Spaces object key'); return config.prefix ? `${config.prefix}/${relative}` : relative; };
  async function get(relative) {
    try {
      const result = await client.send(new sdk.GetObjectCommand({ Bucket: config.bucket, Key: key(relative) }));
      return Buffer.from(await result.Body.transformToByteArray());
    } catch (error) { if (missing(error)) return null; throw new Error(`Spaces read failed for ${relative} (${error.name || 'error'})`, { cause: error }); }
  }
  let conditionalWriteCheck;
  async function probeConditionalWrites() {
    // These synthetic private bytes are deliberately outside every managed
    // release/snapshot. Never test provider behavior using paid asset content.
    const relative = `pipeline-checks/conditional-write-probe-${randomUUID()}.txt`;
    const original = Buffer.from('AbbyAssets conditional-write probe: original\n');
    const replacement = Buffer.from('AbbyAssets conditional-write probe: rejected replacement\n');
    const upload = bytes => client.send(new sdk.PutObjectCommand({ Bucket: config.bucket, Key: key(relative), Body: bytes,
      ContentType: 'text/plain', ACL: 'private', CacheControl: 'private, no-store',
      Metadata: { sha256: hash(bytes), purpose: 'conditional-write-capability' }, IfNoneMatch: '*' }));
    try {
      await upload(original);
      let rejected = false;
      try { await upload(replacement); }
      catch (error) { if (error?.$metadata?.httpStatusCode !== 412) throw error; rejected = true; }
      const checked = await get(relative);
      if (!rejected || !checked || checked.length !== original.length || hash(checked) !== hash(original)) {
        throw new Error('The provider did not reject the replacement and preserve the original probe bytes');
      }
    } catch (cause) {
      throw Object.assign(new Error('Unsafe conditional-write provider: the private capability probe did not return HTTP 412 and preserve its original bytes. New release and backup uploads are blocked; verified reads remain available.', { cause }),
        { code: 'ABBY_ASSETS_UNSAFE_CONDITIONAL_PROVIDER' });
    }
  }
  function assertConditionalWrites() {
    // Share both success and failure with every backup worker. A failed check
    // cannot be bypassed by racing another first write or retrying this store.
    conditionalWriteCheck ||= probeConditionalWrites();
    return conditionalWriteCheck;
  }
  async function putImmutable(relative, bytes, contentType = 'application/octet-stream') {
    bytes = Buffer.from(bytes);
    const original = await get(relative);
    const sha256 = hash(bytes);
    if (original && (original.length !== bytes.length || hash(original) !== sha256)) throw new Error(`Immutable Spaces object already exists with different content: ${relative}`);
    if (coordinatorConfigured) {
      const binding = { endpoint: new URL(config.endpoint).origin, bucket: config.bucket, key: key(relative), sha256, bytes: bytes.length };
      try {
        const acknowledgement = await coordinator.reserve({ ...binding });
        if (!acknowledgement || !['created', 'matched'].includes(acknowledgement.status)
          || typeof acknowledgement.coordinator_id !== 'string' || !acknowledgement.coordinator_id
          || Object.keys(binding).some(field => acknowledgement[field] !== binding[field])) {
          throw new Error('The coordinator acknowledgement did not match the complete object binding');
        }
      } catch (cause) {
        throw Object.assign(new Error('The permanent object write claim was not verified. New uploads are blocked; no provider-only fallback is allowed.', { cause }),
          { code: 'ABBY_ASSETS_WRITE_CLAIM_FAILED' });
      }
    }
    // Existing bytes must also adopt the permanent claim, so they cannot
    // disagree with a reservation whose original writer has not uploaded yet.
    if (original) return false;
    if (!coordinatorConfigured) await assertConditionalWrites();
    try {
      // The permanent binding is the authority when configured. This header is
      // retained as additional protection, not relied on for versioned Spaces.
      await client.send(new sdk.PutObjectCommand({ Bucket: config.bucket, Key: key(relative), Body: bytes, ContentType: contentType, ACL: 'private', CacheControl: 'private, max-age=31536000, immutable', Metadata: { sha256 }, IfNoneMatch: '*' }));
    } catch (error) {
      if (!preconditionFailed(error)) throw new Error(`Spaces immutable upload failed for ${relative} (${error.name || 'error'}); conditional-write support is required`, { cause: error });
    }
    const checked = await get(relative);
    if (!checked || checked.length !== bytes.length || hash(checked) !== hash(bytes)) throw new Error(`Spaces upload readback verification failed: ${relative}`);
    return true;
  }
  return { config, get, putImmutable, assertConditionalWrites, close() { if (owned) client.destroy(); if (coordinatorOwned) coordinator?.close(); } };
}
