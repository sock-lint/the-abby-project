import { readFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';

const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
const origin = value => {
  try { const url = new URL(value); return url.protocol === 'https:' && value === url.origin; } catch { return false; }
};
const remotePath = value => typeof value === 'string' && /^\/[a-zA-Z0-9_./-]+$/.test(value)
  && value.split('/').every(part => part !== '.' && part !== '..');
function failure(message, code = 'UNAVAILABLE') {
  return Object.assign(new Error(`Write coordinator: ${message}`), { code: `ABBY_ASSETS_COORDINATOR_${code}` });
}
export function validateCoordinatorConfig(config) {
  const ssh = config?.ssh;
  if (config?.schema_version !== 1 || !uuid.test(config.coordinator_id) || !origin(config.endpoint)
    || !Array.isArray(config.buckets) || !config.buckets.length || new Set(config.buckets).size !== config.buckets.length
    || config.buckets.some(bucket => typeof bucket !== 'string' || !/^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$/.test(bucket))
    || !ssh || typeof ssh.host !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9.-]*$/.test(ssh.host)
    || typeof ssh.user !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(ssh.user)
    || typeof ssh.identity_file_env !== 'string' || !/^[A-Z][A-Z0-9_]*$/.test(ssh.identity_file_env) || !remotePath(ssh.script) || !remotePath(ssh.database)) {
    throw failure('invalid pinned configuration', 'CONFIG');
  }
  return config;
}

/** No config reads, SSH connection or network operations until the first RPC. */
export function createWriteCoordinator(options = {}, { env = process.env, spawnProcess = spawn } = {}) {
  const file = options.writeCoordinator || env.ABBY_ASSETS_WRITE_COORDINATOR;
  if (!file) return null;
  let config, child, connection, closed = false, sequence = 0, buffered = '';
  const pending = new Map();
  function stop(error = failure('connection closed')) {
    if (closed) return;
    closed = true;
    for (const item of pending.values()) { clearTimeout(item.timer); item.reject(error); }
    pending.clear();
    child?.stdin?.destroy(); child?.kill();
  }
  function handleLine(line) {
    let response;
    try { response = JSON.parse(line); } catch { stop(failure('invalid JSON response', 'PROTOCOL')); return; }
    if (response?.coordinator_id !== config.coordinator_id || response.protocol !== 1) {
      stop(failure('server identity or protocol mismatch', 'IDENTITY')); return;
    }
    const item = pending.get(response.id);
    if (!item) { stop(failure('unexpected response identity', 'PROTOCOL')); return; }
    pending.delete(response.id); clearTimeout(item.timer);
    if (response.ok !== true) {
      const code = response.error?.code === 'CLAIM_CONFLICT' ? 'CLAIM_CONFLICT' : 'REJECTED';
      item.reject(failure(code === 'CLAIM_CONFLICT' ? 'object name is permanently reserved for different content' : 'request rejected', code));
    } else item.resolve(response);
  }
  function rpc(op, fields = {}) {
    if (closed || !child?.stdin?.writable) return Promise.reject(failure('connection unavailable'));
    return new Promise((success, reject) => {
      const id = ++sequence;
      const timer = setTimeout(() => stop(failure('request timed out', 'TIMEOUT')), 30000);
      pending.set(id, { resolve: success, reject, timer });
      child.stdin.write(JSON.stringify({ ...fields, id, op, coordinator_id: config.coordinator_id }) + '\n', error => {
        if (error) stop(failure('request could not be sent'));
      });
    });
  }
  async function connect() {
    if (closed) throw failure('connection closed');
    if (!connection) connection = (async () => {
      try {
        config = validateCoordinatorConfig(JSON.parse(await readFile(resolve(file), 'utf8')));
        const identity = env[config.ssh.identity_file_env];
        if (!identity || /[\r\n\x00]/.test(identity)) throw failure('configured SSH identity is unavailable', 'CONFIG');
        if (closed) throw failure('connection closed');
        const command = `python3 ${config.ssh.script} --serve --db ${config.ssh.database} --coordinator-id ${config.coordinator_id}`;
        child = spawnProcess('ssh', ['-T', '-i', identity, '-o', 'BatchMode=yes', '-o', 'StrictHostKeyChecking=yes',
          '-o', 'ConnectTimeout=10', '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=2',
          `${config.ssh.user}@${config.ssh.host}`, command], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
        child.on('error', () => stop(failure('SSH could not start')));
        child.on('exit', () => stop(failure('SSH connection ended')));
        child.stdin.on('error', () => stop(failure('SSH input closed')));
        child.stdout.setEncoding('utf8');
        child.stdout.on('error', () => stop(failure('SSH output closed')));
        child.stdout.on('data', chunk => {
          buffered += chunk;
          if (Buffer.byteLength(buffered) > 96 * 1024 * 1024) { stop(failure('oversized response', 'PROTOCOL')); return; }
          let split;
          while (!closed && (split = buffered.indexOf('\n')) >= 0) {
            const line = buffered.slice(0, split); buffered = buffered.slice(split + 1);
            if (line.trim()) handleLine(line);
          }
        });
        // Never echo SSH diagnostics, credentials or remote tracebacks.
        child.stderr.resume();
        child.stderr.on('error', () => stop(failure('SSH diagnostics closed')));
        await rpc('hello');
      } catch (error) {
        stop(error.code?.startsWith('ABBY_ASSETS_COORDINATOR_') ? error : failure('configuration or SSH handshake failed'));
        throw error.code?.startsWith('ABBY_ASSETS_COORDINATOR_') ? error : failure('configuration or SSH handshake failed');
      }
    })();
    await connection;
  }
  return {
    async reserve(binding) {
      await connect();
      if (binding?.endpoint !== config.endpoint || !config.buckets.includes(binding.bucket)
        || typeof binding.key !== 'string' || !binding.key || Buffer.byteLength(binding.key) > 1024 || /[\\\x00-\x1f]/.test(binding.key)
        || binding.key.split('/').some(part => !part || part === '.' || part === '..')
        || !/^[a-f0-9]{64}$/.test(binding.sha256) || !Number.isSafeInteger(binding.bytes) || binding.bytes < 0) {
        throw failure('object binding is outside the configured namespace', 'CONFIG');
      }
      const response = await rpc('reserve', binding);
      if (!['created', 'matched'].includes(response.status) || ['endpoint', 'bucket', 'key', 'sha256', 'bytes'].some(key => response[key] !== binding[key])) {
        stop(failure('reservation response does not match the requested content', 'PROTOCOL'));
        throw failure('reservation response does not match the requested content', 'PROTOCOL');
      }
      return response;
    },
    async snapshot() {
      await connect();
      const response = await rpc('snapshot');
      const data = typeof response.snapshot_base64 === 'string' ? Buffer.from(response.snapshot_base64, 'base64') : Buffer.alloc(0);
      if (!data.length || data.length !== response.bytes || digest(data) !== response.sha256) throw failure('ledger snapshot failed integrity verification', 'PROTOCOL');
      return { data, sha256: response.sha256, bytes: data.length, coordinator_id: config.coordinator_id };
    },
    close() { stop(); },
  };
}
