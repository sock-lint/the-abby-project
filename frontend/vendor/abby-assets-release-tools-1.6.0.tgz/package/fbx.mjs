// Binary FBX metadata migration. Numeric, raw and compressed properties are
// copied verbatim; only parsed string properties containing paths can change.
import { createHash } from 'node:crypto';
const MAGIC = Buffer.from('Kaydara FBX Binary  \0\x1a\0', 'binary');
const END_MAGIC = Buffer.from('f85a8c6adef5d97eece90ce3758f290b', 'hex');
const scalar = { Y: 2, C: 1, I: 4, F: 4, D: 8, L: 8 };
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
function fail(message) { throw new Error(`FBX: ${message}`); }
export function parseBinaryFbx(input) {
  const bytes = Buffer.from(input);
  if (bytes.length < 27 || !bytes.subarray(0, 23).equals(MAGIC)) fail('expected a binary FBX');
  const version = bytes.readUInt32LE(23), wide = version >= 7500, width = wide ? 25 : 13;
  let cursor = 27;
  const integer = offset => { const n = wide ? Number(bytes.readBigUInt64LE(offset)) : bytes.readUInt32LE(offset); if (!Number.isSafeInteger(n)) fail('unsafe node offset'); return n; };
  function node() {
    const start = cursor;
    if (start + width > bytes.length) fail('truncated node');
    if (bytes.subarray(start, start + width).every(value => value === 0)) { cursor += width; return null; }
    const end = integer(start), count = integer(start + (wide ? 8 : 4)), propertyBytes = integer(start + (wide ? 16 : 8));
    const nameLength = bytes[start + width - 1]; cursor += width;
    if (end <= cursor || end > bytes.length || nameLength > end - cursor) fail('invalid node boundary');
    const name = bytes.subarray(cursor, cursor + nameLength); cursor += nameLength;
    const propertiesStart = cursor, properties = [];
    if (count > propertyBytes || propertyBytes > end - cursor) fail('invalid property count or length');
    for (let index = 0; index < count; index++) {
      const begin = cursor, type = String.fromCharCode(bytes[cursor++]);
      if (Object.hasOwn(scalar, type)) cursor += scalar[type];
      else if ('fdlibc'.includes(type)) {
        if (cursor + 12 > end) fail('truncated array');
        const encoding = bytes.readUInt32LE(cursor + 4), length = bytes.readUInt32LE(cursor + 8);
        if (![0, 1].includes(encoding)) fail('unknown array encoding');
        cursor += 12 + length;
      } else if (type === 'S' || type === 'R') {
        if (cursor + 4 > end) fail('truncated string or raw property');
        const length = bytes.readUInt32LE(cursor); cursor += 4 + length;
      } else fail('unsupported property type');
      if (cursor > end || cursor > propertiesStart + propertyBytes) fail('property escaped its node');
      properties.push({ type, raw: bytes.subarray(begin, cursor) });
    }
    if (cursor !== propertiesStart + propertyBytes) fail('property length mismatch');
    const children = []; let terminated = false;
    while (cursor < end) { const child = node(); if (!child) { terminated = true; break; } children.push(child); }
    if (cursor !== end) fail('node end offset mismatch');
    return { name, properties, children, terminated };
  }
  const nodes = [];
  while (true) { const next = node(); if (!next) break; nodes.push(next); }
  return { version, width, header: bytes.subarray(0, 27), nodes, footer: bytes.subarray(cursor), footerOffset: cursor };
}
function encodeFooter(document, offset) {
  if (offset === document.footerOffset) return document.footer;
  const footer = document.footer;
  // The vendor and Blender exporters use this version/alignment trailer. Fail
  // closed for unknown layouts rather than emitting a guessed FBX footer.
  const versionOffset = footer.length - 140;
  if (versionOffset < 21 || versionOffset > 36 || footer.readUInt32LE(versionOffset) !== document.version
    || !footer.subarray(20, versionOffset).every(value => value === 0)
    || !footer.subarray(versionOffset + 4, versionOffset + 124).every(value => value === 0)
    || !footer.subarray(-16).equals(END_MAGIC)) fail('unsupported footer layout');
  const alignment = (document.footerOffset + versionOffset) % 16;
  const padding = (alignment - ((offset + 20) % 16) + 16) % 16 || 16;
  return Buffer.concat([footer.subarray(0, 20), Buffer.alloc(padding), footer.subarray(versionOffset)]);
}
export function encodeBinaryFbx(document) {
  const { width } = document, wide = width === 25;
  function encodeNode(node, offset) {
    const header = Buffer.alloc(width), properties = Buffer.concat(node.properties.map(property => property.raw));
    let next = offset + width + node.name.length + properties.length;
    const children = node.children.map(child => { const output = encodeNode(child, next); next += output.length; return output; });
    const terminator = node.terminated ? Buffer.alloc(width) : Buffer.alloc(0); next += terminator.length;
    const write = (value, position) => wide ? header.writeBigUInt64LE(BigInt(value), position) : header.writeUInt32LE(value, position);
    write(next, 0); write(node.properties.length, wide ? 8 : 4); write(properties.length, wide ? 16 : 8); header[width - 1] = node.name.length;
    return Buffer.concat([header, node.name, properties, ...children, terminator]);
  }
  let offset = 27;
  const nodes = document.nodes.map(node => { const bytes = encodeNode(node, offset); offset += bytes.length; return bytes; });
  offset += width;
  return Buffer.concat([document.header, ...nodes, Buffer.alloc(width), encodeFooter(document, offset)]);
}
export function fbxProperties(document) {
  const result = [];
  function visit(node, ancestors) {
    const path = [...ancestors, node.name.toString('utf8')];
    node.properties.forEach((property, index) => result.push({ ...property, node_path: path, index, ...(property.type === 'S' ? { value: property.raw.subarray(5).toString('utf8') } : {}) }));
    node.children.forEach(child => visit(child, path));
  }
  document.nodes.forEach(node => visit(node, [])); return result;
}
export function fbxNumericFingerprint(document) {
  const hasher = createHash('sha256'); let properties = 0, bytes = 0;
  for (const property of fbxProperties(document)) if (property.type !== 'S') {
    hasher.update(JSON.stringify([property.node_path, property.index, property.type])); hasher.update(property.raw);
    properties++; bytes += property.raw.length;
  }
  return { sha256: hasher.digest('hex'), properties, bytes };
}
export function isAuthorPath(value) {
  return /\b[a-z]:[\\/]|^\\\\|^file:\/\/|^(?:\.\.[\\/])+|^\/(?:Users|home|mnt|Volumes|private|tmp)\//i.test(value);
}
export function scrubBinaryFbx(input) {
  const document = parseBinaryFbx(input), roundtrip = encodeBinaryFbx(document);
  if (!roundtrip.equals(input)) fail('unmodified structure did not round trip exactly');
  const numeric = fbxNumericFingerprint(document), changes = [];
  function visit(node, ancestors = []) {
    const location = [...ancestors, node.name.toString('utf8')];
    for (const [index, property] of node.properties.entries()) {
      if (property.type !== 'S') continue;
      const value = property.raw.subarray(5).toString('utf8');
      if (!isAuthorPath(value)) continue;
      const basename = value.split(/[\\/]/).filter(Boolean).at(-1);
      if (!basename || /[\x00-\x1f\x7f]/.test(basename) || basename === '..' || basename === '.' || /^[a-z]:/i.test(basename)) fail('unsafe author path basename');
      const text = Buffer.from(basename), header = Buffer.alloc(5); header[0] = 83; header.writeUInt32LE(text.length, 1);
      node.properties[index] = { type: 'S', raw: Buffer.concat([header, text]) };
      changes.push({ node_path: location, index, original: value, replacement: basename });
    }
    node.children.forEach(child => visit(child, location));
  }
  document.nodes.forEach(node => visit(node));
  const bytes = encodeBinaryFbx(document), parsed = parseBinaryFbx(bytes), after = fbxNumericFingerprint(parsed);
  if (JSON.stringify(after) !== JSON.stringify(numeric)) fail('numeric or raw properties changed');
  if (fbxProperties(parsed).some(property => property.type === 'S' && isAuthorPath(property.value))) fail('residual author path');
  return { bytes, evidence: { source_sha256: hash(input), runtime_sha256: hash(bytes), numeric, changes, version: document.version, exact_unmodified_roundtrip: true } };
}
