import { createHash, randomUUID } from 'node:crypto';
import { readFile, writeFile, mkdir, readdir, lstat, realpath, rename, rm, copyFile, open } from 'node:fs/promises';
import path from 'node:path';
import { validateAnyManifest as validateManifest, isSafeRelativePath } from '@abby-assets/contracts';
import { createS3Store } from './s3.mjs';
import { parseBinaryFbx, fbxProperties, isAuthorPath } from './fbx.mjs';
export { buildAssetPack, buildFamily, readFamilyRegistry } from './families.mjs';
export { createHandoff, verifyHandoff } from './handoff.mjs';

export const digest = bytes => createHash('sha256').update(bytes).digest('hex');
export const canonicalJson = value => `${JSON.stringify(sort(value), null, 2)}\n`;
function sort(value) {
  if (Array.isArray(value)) return value.map(sort);
  if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key, sort(value[key])]));
  return value;
}
const exists = async target => { try { await lstat(target); return true; } catch (error) { if (error.code === 'ENOENT') return false; throw error; } };
const retryRename = async (source, target) => {
  for (let attempt = 0; ; attempt++) {
    try { await rename(source, target); return; }
    catch (error) { if (!['EPERM', 'EBUSY', 'EACCES'].includes(error.code) || attempt >= 7) throw error; await new Promise(resolve => setTimeout(resolve, 50 * 2 ** attempt)); }
  }
};
function contained(root, target) { const relative = path.relative(root, target); return relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative); }
async function checkedFile(root, relative) {
  if (!isSafeRelativePath(relative)) throw new Error(`Unsafe relative file path: ${relative}`);
  const absolute = path.resolve(root, relative), resolvedRoot = await realpath(root), resolved = await realpath(absolute);
  if (!contained(resolvedRoot, resolved) || !(await lstat(absolute)).isFile()) throw new Error(`Non-regular or escaped file: ${relative}`);
  return absolute;
}
async function exactTree(root, allowedFiles) {
  const info = await lstat(root);
  if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Asset tree root must be a regular directory');
  const files = new Set(allowedFiles), directories = new Set();
  for (const file of files) {
    const parts = file.split('/');
    for (let count = 1; count < parts.length; count++) directories.add(parts.slice(0, count).join('/'));
  }
  async function visit(relative = '') {
    for (const name of await readdir(path.join(root, relative))) {
      const next = relative ? `${relative}/${name}` : name, info = await lstat(path.join(root, next));
      if (info.isSymbolicLink()) throw new Error(`Asset tree contains a symbolic link: ${next}`);
      if (info.isDirectory()) {
        if (!directories.has(next)) throw new Error(`Unexpected directory in asset tree: ${next}`);
        await visit(next);
      } else if (!info.isFile() || !files.has(next)) throw new Error(`Unexpected file in asset tree: ${next}`);
    }
  }
  await visit();
}
async function plainDirectory(target) {
  const absolute = path.resolve(target);
  for (let current = absolute; ; current = path.dirname(current)) {
    if (await exists(current)) { const info = await lstat(current); if (info.isSymbolicLink() || !info.isDirectory()) throw new Error(`Directory is not a regular directory: ${current}`); }
    if (current === path.dirname(current)) break;
  }
  return absolute;
}
export function readGlb(bytes) {
  if (bytes.length < 20 || bytes.readUInt32LE(0) !== 0x46546c67 || bytes.readUInt32LE(4) !== 2 || bytes.readUInt32LE(8) !== bytes.length || bytes.readUInt32LE(16) !== 0x4e4f534a) throw new Error('Invalid GLB 2.0 header');
  const length = bytes.readUInt32LE(12);
  return { json: JSON.parse(bytes.subarray(20, 20 + length).toString('utf8')), tail: bytes.subarray(20 + length) };
}
export function runtimeGlb(bytes) {
  const { json, tail } = readGlb(bytes);
  // Runtime exports omit source filenames and editor-only metadata. Geometry,
  // textures, transforms, materials, skinning and animation buffers stay exact.
  const scrub = value => {
    if (!value || typeof value !== 'object') return;
    if (value.extras) {
      for (const key of Object.keys(value.extras)) if (/source_(?:file|path|model|archive|input)|^MapChannel|^MaxHandle|before_dense/i.test(key)) delete value.extras[key];
      scrubExtras(value.extras);
      if (!Object.keys(value.extras).length) delete value.extras;
    }
    for (const [key, child] of Object.entries(value)) if (key !== 'extras') { if (Array.isArray(child)) child.forEach(scrub); else scrub(child); }
  };
  const scrubExtras = value => { if (!value || typeof value !== 'object') return; for (const key of Object.keys(value)) { if (/source_(?:file|path|model|archive|input)|before_dense/i.test(key)) delete value[key]; else scrubExtras(value[key]); } };
  scrub(json);
  for (const buffer of json.buffers || []) if (buffer.uri) throw new Error('Runtime GLB contains an external buffer');
  for (const image of json.images || []) if (image.uri) throw new Error('Runtime GLB contains an external image');
  const raw = Buffer.from(JSON.stringify(json));
  const padded = Buffer.alloc(Math.ceil(raw.length / 4) * 4, 0x20); raw.copy(padded);
  const header = Buffer.alloc(20); header.writeUInt32LE(0x46546c67, 0); header.writeUInt32LE(2, 4); header.writeUInt32LE(20 + padded.length + tail.length, 8); header.writeUInt32LE(padded.length, 12); header.writeUInt32LE(0x4e4f534a, 16);
  return Buffer.concat([header, padded, tail]);
}
const fields = ['id', 'label', 'category', 'slot', 'body', 'skin', 'outfit', 'head', 'hair_style', 'hair_color', 'face_style', 'face_color', 'rig_adapter_id', 'attachment_node', 'hide_nodes', 'hair_style_override', 'default_enabled', 'material_names', 'emissive_factor', 'triangles', 'material_count', 'materials', 'texture_count'];
const runtimeFields = item => Object.fromEntries(fields.filter(key => item[key] !== undefined).map(key => [key, item[key]]));

// Compatibility entry point for already-published Archer recipes. New families
// use buildAvatarFamily and explicitly declare their semantic clip policies.
export async function buildArcher({ workspace, version = '1.0.0', output, portrait }) {
  const prepared = { appearance_catalog: { file: 'assets/female-archer-library/appearance/catalog.json' }, equipment_catalog: { file: 'assets/female-archer-jump/accessories/catalog.json' } };
  if (portrait) prepared.portraits = [{ id: 'workquest-starter', label: 'Existing workQuest Archer starter portrait', absolute: path.resolve(portrait) }];
  return buildAvatarRecipe({ workspace, version, output }, prepared, true);
}

export async function buildAvatarFamily(options) {
  const workspace = await realpath(options.workspace);
  const relative = path.relative(workspace, path.resolve(workspace, options.recipe)).split(path.sep).join('/');
  const prepared = JSON.parse(await readFile(await checkedFile(workspace, relative), 'utf8'));
  if (prepared.schema_version !== 1 || prepared.kind !== 'avatar-family' || !prepared.family_id || !prepared.label || !prepared.animations
    || Object.keys(prepared).some(key => !['schema_version', 'kind', 'family_id', 'label', 'appearance_catalog', 'equipment_catalog', 'equipment_rig_adapter_ids', 'animations', 'portraits'].includes(key))) throw new Error('Invalid avatar family recipe');
  if (typeof prepared.animations.root_node !== 'string' || !prepared.animations.root_node.trim() || !prepared.animations.actions || typeof prepared.animations.actions !== 'object' || Array.isArray(prepared.animations.actions)
    || !Array.isArray(prepared.equipment_rig_adapter_ids) || new Set(prepared.equipment_rig_adapter_ids).size !== prepared.equipment_rig_adapter_ids.length || !Array.isArray(prepared.portraits)) throw new Error('Avatar recipe requires an explicit animation root, actions, equipment adapter list and portraits');
  return buildAvatarRecipe({ ...options, workspace }, prepared, false);
}

async function buildAvatarRecipe({ workspace, version = '1.0.0', output }, prepared, legacy) {
  workspace = await realpath(workspace); output = await plainDirectory(output);
  async function catalog(pin, optional = false) {
    if (pin === null && optional) return { file: null, value: { items: [] } };
    if (!pin || !pin.file?.startsWith('assets/') || (!legacy && !/^[a-f0-9]{64}$/.test(pin.sha256))) throw new Error('Avatar recipe must pin its prepared catalog inside assets');
    const file = await checkedFile(workspace, pin.file); await plainDirectory(path.dirname(file));
    const bytes = await readFile(file);
    if (pin.sha256 && pin.sha256 !== digest(bytes)) throw new Error(`Prepared catalog hash mismatch: ${pin.file}`);
    return { file, value: JSON.parse(bytes) };
  }
  const appearanceInput = await catalog(prepared.appearance_catalog), appearanceFile = appearanceInput.file, original = appearanceInput.value;
  const equipmentInput = await catalog(prepared.equipment_catalog, true), equipmentFile = equipmentInput.file, originalEquipment = equipmentInput.value;
  if (!legacy && (original.family_id !== prepared.family_id || original.label !== prepared.label)) throw new Error('Recipe and appearance catalog family identity disagree');
  if (!legacy && (prepared.equipment_rig_adapter_ids || []).some(id => !original.rig_adapter_ids.includes(id))) throw new Error('Equipment compatibility names an unknown adapter');
  const objects = new Map(), audit = [];
  async function asset(item, directory) {
    const absolute = path.resolve(directory, item.file);
    if (!contained(path.join(workspace, 'assets'), absolute)) throw new Error(`Source asset escaped workshop: ${item.id}`);
    const relativeSource = path.relative(workspace, absolute).split(path.sep).join('/');
    await checkedFile(workspace, relativeSource); await plainDirectory(path.dirname(absolute));
    const input = await readFile(absolute), inputHash = digest(input);
    if (!legacy && !/^[a-f0-9]{64}$/.test(item.sha256)) throw new Error(`Unpinned prepared asset: ${item.id}`);
    if (item.sha256 && item.sha256 !== inputHash) throw new Error(`Source catalog hash mismatch: ${item.id}`);
    const extension = path.extname(absolute).toLowerCase();
    if (!['.glb', '.png'].includes(extension)) throw new Error(`Unapproved runtime file type: ${extension}`);
    const bytes = extension === '.glb' ? runtimeGlb(input) : input;
    const sha256 = digest(bytes), relative = `objects/${sha256}${extension}`;
    objects.set(relative, bytes); audit.push({ id: item.id, source: path.relative(workspace, absolute).split(path.sep).join('/'), source_sha256: inputHash, runtime_sha256: sha256 });
    return { ...runtimeFields(item), file: relative, path: relative, sha256, bytes: bytes.length };
  }
  const appearance = Object.fromEntries(['schema_version', 'family_id', 'label', 'rig_adapter_ids', 'defaults', 'selectors', 'replacement_nodes', 'attachment_contract'].map(key => [key, original[key]]));
  for (const key of ['base_variants', 'modules', 'equipment_overrides', 'textures', 'projectiles']) appearance[key] = await Promise.all(original[key].map(item => asset(item, path.dirname(appearanceFile))));
  appearance.emission = { default_enabled: Boolean(original.emission?.default_enabled), maps: appearance.textures };
  const items = await Promise.all(originalEquipment.items.map(async item => {
    const override = original.equipment_overrides.find(entry => entry.id === item.id);
    return override ? { ...runtimeFields(item), ...await asset({ ...item, ...override }, path.dirname(appearanceFile)) } : asset(item, path.dirname(equipmentFile));
  }));
  const sample = readGlb(objects.get(appearance.base_variants[0].file)).json;
  const policies = legacy ? sample.animations.map(animation => ({ name: animation.name, loop: animation.name !== 'Jump' && !animation.name.includes('Root Motion'), root_motion: animation.name.includes('Root Motion') ? 'source' : animation.name === 'Jump' ? 'vertical' : 'in-place' })) : prepared.animations.clips;
  if (!Array.isArray(policies) || new Set(policies.map(clip => clip.name)).size !== policies.length || policies.length !== sample.animations.length) throw new Error('Declare a unique policy for every exported avatar clip');
  const clips = sample.animations.map(animation => {
    const policy = policies.find(clip => clip.name === animation.name);
    if (!policy || typeof policy.loop !== 'boolean' || !['in-place', 'vertical', 'source'].includes(policy.root_motion) || Object.keys(policy).some(key => !['name', 'loop', 'root_motion'].includes(key))) throw new Error(`Invalid or missing clip policy: ${animation.name}`);
    return { name: animation.name, duration: glbClipDuration(objects.get(appearance.base_variants[0].file), animation, legacy), loop: policy.loop, root_motion: policy.root_motion };
  });
  // All bases must expose the same intentional clip names; do not silently ship
  // partially rebuilt families.
  for (const base of appearance.base_variants) {
    const json = readGlb(objects.get(base.file)).json;
    if (JSON.stringify(json.animations.map(clip => clip.name)) !== JSON.stringify(clips.map(clip => clip.name))) throw new Error(`Clip mismatch: ${base.id}`);
    if (!json.nodes.some(node => node.extras?.avatar_rig_adapter_id === base.rig_adapter_id)) throw new Error(`Adapter metadata mismatch: ${base.id}`);
    if (!legacy) {
      if (prepared.animations.root_node && !json.nodes.some(node => node.name === prepared.animations.root_node)) throw new Error(`Animation root missing: ${base.id}`);
      for (const animation of json.animations) if (Math.abs(glbClipDuration(objects.get(base.file), animation) - clips.find(clip => clip.name === animation.name).duration) > 1e-5) throw new Error(`Clip duration mismatch: ${base.id}/${animation.name}`);
    }
  }
  const portraits = [];
  for (const item of prepared.portraits || []) {
    if (!legacy && (!item.file?.startsWith('assets/') || !/^[a-f0-9]{64}$/.test(item.sha256))) throw new Error('Portrait must pin a prepared assets file');
    const bytes = await readFile(legacy ? item.absolute : await checkedFile(workspace, item.file)), sha256 = digest(bytes), relative = `objects/${sha256}.png`;
    if (item.sha256 && sha256 !== item.sha256) throw new Error(`Portrait hash mismatch: ${item.id}`);
    objects.set(relative, bytes);
    portraits.push({ id: item.id, label: item.label, file: relative, path: relative, sha256, bytes: bytes.length, configuration: legacy ? { schema_version: 2, family_id: original.family_id, appearance: { body: '01', skin: 'fair', outfit: 'nature', head: '02', hair_style: '02', hair_color: 'black', face_style: '01', face_color: 'black' }, slots: { 'left-hand': 'bow-greenhorn', back: 'quiver-rook' }, emission_enabled: false } : item.configuration });
  }
  if (!legacy && items.some(item => !item.rig_adapter_id && !prepared.equipment_rig_adapter_ids?.length)) throw new Error('Equipment needs an explicit compatible adapter list');
  if (!legacy && items.some(item => item.rig_adapter_id && !original.rig_adapter_ids.includes(item.rig_adapter_id))) throw new Error('Equipment item names an unknown adapter');
  const manifest = validateManifest({ schema_version: 1, family_id: original.family_id, release_version: version, label: original.label, appearance, equipment_catalogs: original.rig_adapter_ids.map(rig_adapter_id => ({ rig_adapter_id, items: legacy ? items : items.filter(item => item.rig_adapter_id ? item.rig_adapter_id === rig_adapter_id : prepared.equipment_rig_adapter_ids.includes(rig_adapter_id)) })), animations: { actions: legacy ? { idle: 'Idle', walk: 'Walk', run: 'Run', jump: 'Jump' } : prepared.animations.actions, clips, root_node: legacy ? 'JumpRoot' : prepared.animations.root_node }, portraits, files: [...objects.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([relative, bytes]) => ({ path: relative, sha256: digest(bytes), bytes: bytes.length, media_type: relative.endsWith('.glb') ? 'model/gltf-binary' : 'image/png' })) });
  return writePreparedRelease({ workspace, output, manifest, objects, audit });
}

// Read float animation input samples when an exporter omits accessor.max.
// Unknown or compressed timing must be fixed in preparation, never guessed.
export function glbClipDuration(bytes, animation, legacy = false) {
  const { json, tail } = readGlb(bytes);
  const durations = animation.samplers.map(sampler => {
    const accessor = json.accessors?.[sampler.input];
    if (accessor?.max && Number.isFinite(accessor.max[0])) return accessor.max[0];
    if (legacy) return 0;
    const view = json.bufferViews?.[accessor?.bufferView];
    if (!accessor || accessor.type !== 'SCALAR' || accessor.componentType !== 5126 || accessor.sparse || !view || view.buffer !== 0 || !accessor.count || tail.length < 8 || tail.readUInt32LE(4) !== 0x004e4942) throw new Error(`Cannot measure clip timing: ${animation.name}`);
    const binary = tail.subarray(8), start = (view.byteOffset || 0) + (accessor.byteOffset || 0), stride = view.byteStride || 4;
    if (stride < 4 || start + (accessor.count - 1) * stride + 4 > Math.min(binary.length, (view.byteOffset || 0) + view.byteLength)) throw new Error(`Clip timing buffer is out of bounds: ${animation.name}`);
    let maximum = 0;
    for (let index = 0; index < accessor.count; index++) {
      const value = binary.readFloatLE(start + index * stride);
      if (!Number.isFinite(value) || value < 0) throw new Error(`Invalid animation time: ${animation.name}`);
      maximum = Math.max(maximum, value);
    }
    return maximum;
  });
  if (!durations.length || durations.some(value => !Number.isFinite(value) || value < 0)) throw new Error(`Invalid clip duration: ${animation.name}`);
  return Math.max(...durations);
}

export async function writePreparedRelease({ workspace, output, manifest, objects, audit = [] }) {
  manifest = validateManifest(manifest); output = await plainDirectory(output);
  if (!(objects instanceof Map) || objects.size !== manifest.files.length) throw new Error('Prepared payload set differs from manifest');
  for (const [file, payload] of objects) {
    const expected = manifest.files.find(entry => entry.path === file);
    if (!expected || !Buffer.isBuffer(payload) || payload.length !== expected.bytes || digest(payload) !== expected.sha256) throw new Error(`Prepared payload differs from manifest: ${file}`);
  }
  const version = manifest.release_version;
  const bytes = Buffer.from(canonicalJson(manifest)), manifest_sha256 = digest(bytes);
  const directory = `${manifest.family_id}/${version}/${manifest_sha256}`, destination = path.join(output, directory);
  const versionRoot = path.dirname(destination);
  await mkdir(versionRoot, { recursive: true });
  await plainDirectory(versionRoot);
  const guard = path.join(versionRoot, '.build-lock'), handle = await open(guard, 'wx').catch(error => { if (error.code === 'EEXIST') throw new Error('Another release build is active; confirm it stopped before removing its build lock'); throw error; });
  const stage = path.join(versionRoot, `.build-${randomUUID()}`);
  try {
    const existing = (await readdir(versionRoot)).filter(entry => !entry.startsWith('.'));
    if (existing.some(entry => entry !== manifest_sha256)) throw new Error(`Immutable version ${version} already exists with different content; choose a new version`);
    if (!await exists(destination)) {
      await mkdir(path.join(stage, 'objects'), { recursive: true });
      for (const [relative, payload] of objects) await writeFile(path.join(stage, relative), payload, { flag: 'wx' });
      await writeFile(path.join(stage, 'manifest.json'), bytes, { flag: 'wx' });
      await verifyRelease(stage, manifest_sha256); await rename(stage, destination);
    }
    await verifyRelease(destination, manifest_sha256);
  } finally { if (await exists(stage)) await rm(stage, { recursive: true }); await handle.close(); await rm(guard); }
  const evidence = path.join(workspace, '.local/release-evidence', manifest_sha256); await mkdir(evidence, { recursive: true });
  await writeFile(path.join(evidence, 'source-map.json'), canonicalJson({ manifest_sha256, records: audit }));
  return { directory, path: destination, family_id: manifest.family_id, release_version: version, manifest_sha256, files: manifest.files.length, bytes: manifest.files.reduce((sum, file) => sum + file.bytes, 0) };
}

export async function buildFileLibrary({ workspace, recipe, version = '1.0.0', output }) {
  workspace = await realpath(workspace); output = await plainDirectory(output);
  const prepared = JSON.parse(await readFile(recipe, 'utf8'));
  if (!prepared || prepared.schema_version !== 1 || !Array.isArray(prepared.entries) || !prepared.entries.length
    || Object.keys(prepared).some(key => !['schema_version', 'family_id', 'label', 'entries'].includes(key))) throw new Error('Invalid file library recipe');
  const objects = new Map(), audit = [], entries = [];
  const media = { '.fbx': 'application/octet-stream', '.png': 'image/png', '.glb': 'model/gltf-binary', '.json': 'application/json' };
  for (const entry of prepared.entries) {
    if (!entry || Object.keys(entry).some(key => !['id', 'runtime_path', 'file', 'sha256', 'bytes', 'media_type'].includes(key))
      || !isSafeRelativePath(entry.file) || !entry.file.startsWith('assets/')) throw new Error('Library recipe must pin prepared files inside workshop assets');
    const source = await checkedFile(workspace, entry.file), extension = path.extname(source), bytes = await readFile(source);
    await plainDirectory(path.dirname(source));
    const sha256 = digest(bytes);
    if (!media[extension] || bytes.length !== entry.bytes || sha256 !== entry.sha256 || entry.media_type !== media[extension]) throw new Error(`Prepared library file integrity or media mismatch: ${entry.id}`);
    if (extension === '.fbx' && fbxProperties(parseBinaryFbx(bytes)).some(property => property.type === 'S' && isAuthorPath(property.value))) throw new Error(`FBX contains an author path: ${entry.id}`);
    if (extension === '.json' || extension === '.glb') {
      const json = extension === '.json' ? JSON.parse(bytes) : readGlb(bytes).json;
      const inspect = value => {
        if (typeof value === 'string' && isAuthorPath(value)) throw new Error(`Runtime metadata contains an author path: ${entry.id}`);
        if (value && typeof value === 'object') for (const [key, child] of Object.entries(value)) {
          if (/^(?:source(?:_|Sha256|Path|Archive|File|Model|Input)|archive(?:Sha256)?$|preparation$)/i.test(key)
            || (key === 'source' && typeof child !== 'number')) throw new Error(`Runtime metadata contains private provenance: ${entry.id}`);
          inspect(child);
        }
      };
      inspect(json);
      if (extension === '.glb' && [...(json.buffers || []), ...(json.images || [])].some(value => value.uri)) throw new Error(`Library GLB is not self contained: ${entry.id}`);
    }
    const file = `objects/${sha256}${extension}`; objects.set(file, bytes);
    entries.push({ id: entry.id, runtime_path: entry.runtime_path, file, sha256, bytes: bytes.length, media_type: media[extension] });
    audit.push({ id: entry.id, source: entry.file, source_sha256: sha256, runtime_path: entry.runtime_path });
  }
  const manifest = validateManifest({ schema_version: 1, kind: 'file-library', family_id: prepared.family_id, release_version: version, label: prepared.label,
    entries: entries.sort((a, b) => a.runtime_path.localeCompare(b.runtime_path)),
    files: [...objects].sort(([a], [b]) => a.localeCompare(b)).map(([file, bytes]) => ({ path: file, sha256: digest(bytes), bytes: bytes.length, media_type: media[path.extname(file)] })) });
  const bytes = Buffer.from(canonicalJson(manifest)), manifest_sha256 = digest(bytes), directory = `${manifest.family_id}/${version}/${manifest_sha256}`;
  const destination = path.join(output, directory), versionRoot = path.dirname(destination);
  await mkdir(versionRoot, { recursive: true });
  await plainDirectory(versionRoot);
  const guard = path.join(versionRoot, '.build-lock'), handle = await open(guard, 'wx').catch(error => { if (error.code === 'EEXIST') throw new Error('Another library build is active; confirm it stopped before removing its build lock'); throw error; });
  const stage = path.join(versionRoot, `.build-${randomUUID()}`);
  try {
    const existing = (await readdir(versionRoot)).filter(entry => !entry.startsWith('.'));
    if (existing.some(value => value !== manifest_sha256)) throw new Error(`Immutable version ${version} already exists with different content; choose a new version`);
    if (!await exists(destination)) {
      await mkdir(path.join(stage, 'objects'), { recursive: true });
      for (const [file, payload] of objects) await writeFile(path.join(stage, file), payload, { flag: 'wx' });
      await writeFile(path.join(stage, 'manifest.json'), bytes, { flag: 'wx' }); await rename(stage, destination);
    }
    await verifyRelease(destination, manifest_sha256);
  } finally { if (await exists(stage)) await rm(stage, { recursive: true }); await handle.close(); await rm(guard); }
  const evidence = path.join(workspace, '.local/release-evidence', manifest_sha256); await mkdir(evidence, { recursive: true });
  await writeFile(path.join(evidence, 'source-map.json'), canonicalJson({ manifest_sha256, records: audit }));
  return { directory, path: destination, family_id: manifest.family_id, release_version: version, manifest_sha256, entries: entries.length, files: manifest.files.length, bytes: manifest.files.reduce((sum, file) => sum + file.bytes, 0) };
}

export async function verifyRelease(directory, expectedDigest) {
  const bytes = await readFile(await checkedFile(directory, 'manifest.json'));
  const actual = digest(bytes);
  if (expectedDigest && actual !== expectedDigest) throw new Error(`Release manifest integrity mismatch: expected ${expectedDigest}, got ${actual}`);
  const manifest = validateManifest(JSON.parse(bytes));
  await exactTree(directory, ['manifest.json', ...manifest.files.map(file => file.path)]);
  for (const file of manifest.files) {
    const bytes = await readFile(await checkedFile(directory, file.path));
    if (bytes.length !== file.bytes || digest(bytes) !== file.sha256) throw new Error(`Release file integrity mismatch: ${file.path}`);
  }
  return { manifest, manifest_sha256: actual };
}
export async function pinRelease({ release, lock }) {
  const { manifest, manifest_sha256 } = await verifyRelease(release);
  const entry = { family_id: manifest.family_id, release_version: manifest.release_version, manifest_sha256, directory: `${manifest.family_id}/${manifest.release_version}/${manifest_sha256}` };
  const existing = await exists(lock) ? JSON.parse(await readFile(lock, 'utf8')) : { schema_version: 1, releases: [] };
  validateLock(existing);
  existing.releases = existing.releases.filter(item => item.family_id !== entry.family_id).concat(entry).sort((a, b) => a.family_id.localeCompare(b.family_id));
  await mkdir(path.dirname(path.resolve(lock)), { recursive: true }); await writeFile(lock, canonicalJson(existing));
  return existing;
}
export function validateLock(value) {
  if (!value || value.schema_version !== 1 || !Array.isArray(value.releases)) throw new Error('Unsupported assets.lock.json schema');
  const seen = new Set();
  for (const entry of value.releases) {
    if (!entry || typeof entry !== 'object' || typeof entry.family_id !== 'string' || !/^[a-z0-9][a-z0-9._-]*$/.test(entry.family_id) || typeof entry.release_version !== 'string' || !/^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/.test(entry.release_version) || typeof entry.manifest_sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(entry.manifest_sha256) || entry.directory !== `${entry.family_id}/${entry.release_version}/${entry.manifest_sha256}` || seen.has(entry.family_id)) throw new Error('Invalid or duplicate pinned release');
    if (entry.source?.url && new URL(entry.source.url).protocol !== 'https:') throw new Error('Remote releases require HTTPS');
    seen.add(entry.family_id);
  }
  return value;
}
const indexFor = lock => ({ schema_version: 1, releases: lock.releases.map(({ family_id, release_version, manifest_sha256, directory }) => ({ family_id, release_version, manifest_sha256, manifest_path: `${directory}/manifest.json` })) });
export async function verifyImport({ lock, destination }) {
  const pinned = validateLock(JSON.parse(await readFile(lock, 'utf8')));
  const index = JSON.parse(await readFile(await checkedFile(destination, 'index.json'), 'utf8'));
  if (canonicalJson(index) !== canonicalJson(indexFor(pinned))) throw new Error('Staged asset index does not match assets.lock.json; run asset import');
  const marker = JSON.parse(await readFile(await checkedFile(destination, '.abby-assets-managed.json'), 'utf8'));
  if (canonicalJson(marker) !== canonicalJson({ schema_version: 1, manager: '@abby-assets/release-tools' })) throw new Error('Staged asset manager marker is invalid');
  const allowed = ['index.json', '.abby-assets-managed.json'];
  let bytes = 0, files = 0;
  for (const entry of pinned.releases) {
    const result = await verifyRelease(path.join(destination, entry.directory), entry.manifest_sha256);
    if (result.manifest.family_id !== entry.family_id || result.manifest.release_version !== entry.release_version) throw new Error('Pinned release identity mismatch');
    allowed.push(`${entry.directory}/manifest.json`, ...result.manifest.files.map(file => `${entry.directory}/${file.path}`));
    bytes += result.manifest.files.reduce((sum, file) => sum + file.bytes, 0); files += result.manifest.files.length;
  }
  await exactTree(destination, allowed);
  return { releases: pinned.releases.length, files, bytes };
}
export async function importReleases({ lock, destination, releaseRoot = process.env.ABBY_ASSETS_RELEASE_ROOT, fetch: fetchImpl = globalThis.fetch, store: injectedStore, ...options }) {
  const pinned = validateLock(JSON.parse(await readFile(lock, 'utf8'))); destination = await plainDirectory(destination);
  try { return { ...await verifyImport({ lock, destination }), unchanged: true }; } catch { /* A full verified transaction repairs missing/corrupt staged files. */ }
  await mkdir(path.dirname(destination), { recursive: true });
  const guard = `${destination}.import-lock`, handle = await open(guard, 'wx').catch(error => { if (error.code === 'EEXIST') throw new Error('Another asset import is active; remove its import-lock only after confirming it stopped'); throw error; });
  const stage = path.join(path.dirname(destination), `.${path.basename(destination)}.stage-${randomUUID()}`), previous = path.join(path.dirname(destination), `.${path.basename(destination)}.previous-${randomUUID()}`);
  let store = injectedStore;
  try {
    if (await exists(destination) && (await readdir(destination)).length && !await exists(path.join(destination, '.abby-assets-managed.json'))) throw new Error('Destination contains unmanaged files; use a dedicated empty directory');
    await mkdir(stage);
    for (const entry of pinned.releases) {
      const remote = entry.source?.url;
      const source = releaseRoot && path.resolve(releaseRoot, entry.directory);
      if (!remote && !source && !store) store = await createS3Store(options);
      async function obtain(relative) {
        if (remote) {
          const url = new URL(relative, `${remote.replace(/\/?$/, '/')}`);
          const response = await fetchImpl(url, { redirect: 'error', signal: AbortSignal.timeout(60000) });
          if (!response.ok) throw new Error(`Asset download failed (${response.status}): ${relative}`);
          return Buffer.from(await response.arrayBuffer());
        }
        if (!source && store) { const bytes = await store.get(`${entry.directory}/${relative}`); if (!bytes) throw new Error(`Required Spaces release file is unavailable: ${entry.directory}/${relative}`); return bytes; }
        try { return await readFile(await checkedFile(source, relative)); } catch (error) { throw new Error(`Required private release file is unavailable: ${entry.directory}/${relative}. Restore the approved release and rerun import.`, { cause: error }); }
      }
      const bytes = await obtain('manifest.json');
      if (digest(bytes) !== entry.manifest_sha256) throw new Error('Downloaded manifest does not match the pinned SHA-256');
      const manifest = validateManifest(JSON.parse(bytes));
      if (manifest.family_id !== entry.family_id || manifest.release_version !== entry.release_version) throw new Error('Downloaded release identity mismatch');
      const target = path.join(stage, entry.directory); await mkdir(path.join(target, 'objects'), { recursive: true });
      await writeFile(path.join(target, 'manifest.json'), bytes);
      for (const file of manifest.files) {
        const bytes = await obtain(file.path);
        if (bytes.length !== file.bytes || digest(bytes) !== file.sha256) throw new Error(`Downloaded file integrity mismatch: ${file.path}`);
        await writeFile(path.join(target, file.path), bytes);
      }
    }
    await writeFile(path.join(stage, 'index.json'), canonicalJson(indexFor(pinned)));
    await writeFile(path.join(stage, '.abby-assets-managed.json'), canonicalJson({ schema_version: 1, manager: '@abby-assets/release-tools' }));
    const result = await verifyImport({ lock, destination: stage });
    if (await exists(destination)) await retryRename(destination, previous);
    try { await retryRename(stage, destination); } catch (error) { if (await exists(previous)) await retryRename(previous, destination); throw error; }
    if (await exists(previous)) await rm(previous, { recursive: true });
    return { ...result, unchanged: false };
  } finally { if (!injectedStore) store?.close(); if (await exists(stage)) await rm(stage, { recursive: true }); await handle.close(); await rm(guard, { force: true }); }
}
export async function publishRelease({ release, destination, store: injectedStore, ...options }) {
  const { manifest, manifest_sha256 } = await verifyRelease(release);
  if (!destination) {
    const store = injectedStore || await createS3Store(options);
    const directory = `${manifest.family_id}/${manifest.release_version}/${manifest_sha256}`;
    try {
      await store.putImmutable(`versions/${manifest.family_id}/${manifest.release_version}.json`, Buffer.from(canonicalJson({ family_id: manifest.family_id, release_version: manifest.release_version, manifest_sha256 })), 'application/json');
      for (const file of manifest.files) {
        const bytes = await readFile(await checkedFile(release, file.path));
        if (bytes.length !== file.bytes || digest(bytes) !== file.sha256) throw new Error(`Source changed during publish: ${file.path}`);
        await store.putImmutable(`${directory}/${file.path}`, bytes, file.media_type);
      }
      // Completion is advertised only after every runtime object passed readback.
      await store.putImmutable(`${directory}/manifest.json`, await readFile(path.join(release, 'manifest.json')), 'application/json');
      return { bucket: store.config.bucket, prefix: store.config.prefix, directory, manifest_sha256, files: manifest.files.length, verified: true };
    } finally { if (!injectedStore) store.close(); }
  }
  destination = await plainDirectory(destination);
  const target = path.join(destination, manifest.family_id, manifest.release_version, manifest_sha256), versionRoot = path.dirname(target);
  await mkdir(versionRoot, { recursive: true });
  const existing = (await readdir(versionRoot)).filter(entry => !entry.startsWith('.'));
  if (existing.some(entry => entry !== manifest_sha256)) throw new Error('Destination already has a different immutable release at this version');
  if (await exists(target)) { await verifyRelease(target, manifest_sha256); return { path: target, unchanged: true }; }
  const stage = path.join(versionRoot, `.publish-${randomUUID()}`); await mkdir(path.join(stage, 'objects'), { recursive: true });
  try { await copyFile(path.join(release, 'manifest.json'), path.join(stage, 'manifest.json')); for (const file of manifest.files) await copyFile(await checkedFile(release, file.path), path.join(stage, file.path)); await verifyRelease(stage, manifest_sha256); await rename(stage, target); }
  finally { if (await exists(stage)) await rm(stage, { recursive: true }); }
  return { path: target, unchanged: false };
}
// Source filenames may contain spaces and Unicode. Runtime catalog paths use a
// narrower alphabet; source recovery still forbids filesystem aliases/escapes.
function backupPath(value) {
  if (typeof value !== 'string' || !value || /[\\:\x00-\x1f]/.test(value) || value.startsWith('/')) throw new Error('Unsafe backup file path');
  const parts = value.split('/');
  if (parts.some(part => !part || part === '.' || part === '..' || /[. ]$/.test(part)
    || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part))) throw new Error('Unsafe backup file path');
  return value;
}
function workerCount(value = 4) {
  const count = Number(value);
  if (!Number.isInteger(count) || count < 1 || count > 4) throw new Error('Backup/restore concurrency must be an integer from 1 through 4');
  return count;
}
async function pooled(items, concurrency, task) {
  let cursor = 0, failure;
  const workers = Array.from({ length: Math.min(items.length, concurrency) }, async () => {
    while (!failure) {
      const index = cursor++;
      if (index >= items.length) return;
      try { await task(items[index], index); } catch (error) { failure ||= error; }
    }
  });
  // A failure never leaves a sibling upload or write running after rejection.
  await Promise.allSettled(workers);
  if (failure) throw failure;
}
async function backupInventory(workspace, roots) {
  const files = [], paths = new Set();
  const walk = async relative => {
    const normalized = backupPath(relative.split(path.sep).join('/')), absolute = path.join(workspace, normalized);
    const info = await lstat(absolute);
    if (info.isSymbolicLink()) throw new Error(`Backup refuses symlink: ${normalized}`);
    if (info.isDirectory()) { for (const name of (await readdir(absolute)).sort()) await walk(`${normalized}/${name}`); return; }
    if (!info.isFile()) throw new Error(`Backup requires regular files: ${normalized}`);
    const identity = normalized.toLowerCase();
    if (paths.has(identity)) throw new Error(`Duplicate or overlapping backup path: ${normalized}`);
    paths.add(identity); files.push({ path: normalized, absolute, bytes: info.size, mtimeMs: info.mtimeMs });
  };
  for (const root of roots) {
    backupPath(root);
    // Explicit extra roots can start below a symlink; inspect their ancestors.
    const parts = root.split('/');
    for (let index = 1; index < parts.length; index++) if ((await lstat(path.join(workspace, ...parts.slice(0, index)))).isSymbolicLink()) throw new Error(`Backup refuses symlink parent: ${root}`);
    await walk(root);
  }
  return files.sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
}
async function unchanged(file) {
  const info = await lstat(file.absolute);
  if (!info.isFile() || info.isSymbolicLink() || info.size !== file.bytes || info.mtimeMs !== file.mtimeMs) throw new Error(`Source changed during backup: ${file.path}`);
}
async function removeBackupStage(stage, destination) {
  // Both resolved absolute targets are constrained to this operation's sibling
  // staging name before recursive cleanup; no source directory is removed.
  if (path.dirname(stage) !== path.dirname(destination) || !path.basename(stage).startsWith(`${path.basename(destination)}.stage-`)) throw new Error('Invalid backup staging cleanup target');
  if (await exists(stage)) await rm(stage, { recursive: true });
}
export async function backupWorkspace({ workspace, destination, snapshot, extraRoots = [], concurrency = 4, onProgress, store: injectedStore, ...options }) {
  const count = workerCount(concurrency);
  if (!Array.isArray(extraRoots)) throw new Error('Backup extraRoots must be a list');
  const roots = ['Meshtint/Originals', 'assets', ...extraRoots.map(backupPath)];
  if (!destination && (!snapshot || !/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(snapshot))) throw new Error('Cloud backup requires an explicit --snapshot ID');
  workspace = await realpath(workspace);
  if (destination) {
    destination = await plainDirectory(destination);
    if (contained(workspace, destination) || contained(destination, workspace)) throw new Error('Backup destination must be outside the workspace and cannot contain it');
    if (await exists(destination)) throw new Error('Backup destination must be new so existing backups cannot be overwritten');
  }
  const inventory = await backupInventory(workspace, roots), totalBytes = inventory.reduce((sum, file) => sum + file.bytes, 0);
  const records = Array(inventory.length), seen = new Map();
  let completed = 0, verifiedBytes = 0, uniqueObjects = 0, uniqueBytes = 0;
  const progress = (phase, detail = {}) => onProgress?.({ phase, files: completed, totalFiles: inventory.length, bytes: verifiedBytes, totalBytes, uniqueObjects, uniqueBytes, ...detail });
  await progress('scanned');
  const store = destination ? null : injectedStore || await createS3Store(options);
  const stage = destination ? `${destination}.stage-${randomUUID()}` : null;
  try {
    if (stage) await mkdir(stage, { recursive: true });
    await pooled(inventory, count, async (file, index) => {
      await unchanged(file);
      const bytes = await readFile(file.absolute), sha256 = digest(bytes);
      if (bytes.length !== file.bytes) throw new Error(`Source changed during backup: ${file.path}`);
      const duplicate = seen.has(sha256);
      if (store) {
        if (!duplicate) {
          const pending = store.putImmutable(`objects/${sha256}`, bytes).then(() => { uniqueObjects++; uniqueBytes += bytes.length; });
          // Mark the promise handled immediately; another worker may still be
          // awaiting an unrelated upload when this one fails.
          pending.catch(() => {}); seen.set(sha256, pending);
        }
        await seen.get(sha256);
      } else {
        if (!duplicate) seen.set(sha256, true);
        const target = path.join(stage, file.path); await mkdir(path.dirname(target), { recursive: true });
        await writeFile(target, bytes, { flag: 'wx' });
        const checked = await readFile(target);
        if (checked.length !== bytes.length || digest(checked) !== sha256) throw new Error(`Backup verification failed: ${file.path}`);
        if (!duplicate) { uniqueObjects++; uniqueBytes += bytes.length; }
      }
      await unchanged(file);
      records[index] = { path: file.path, sha256, bytes: bytes.length, ...(store ? { object: `objects/${sha256}` } : {}) };
      completed++; verifiedBytes += bytes.length; await progress('verified', { path: file.path, duplicate });
    });
    // A stable file's metadata does not reveal a newly added sibling. Rewalk
    // the selected roots before advertising the snapshot, then check the
    // original files again for removal or modification during the upload.
    const finalInventory = await backupInventory(workspace, roots);
    if (finalInventory.length !== inventory.length || finalInventory.some((file, index) => file.path !== inventory[index].path)) throw new Error('Backup inventory changed during upload');
    for (const file of inventory) await unchanged(file);
    const manifest = Buffer.from(canonicalJson({ schema_version: 1, ...(snapshot ? { snapshot } : {}), roots, files: records }));
    if (store) await store.putImmutable(`snapshots/${snapshot}/backup-manifest.json`, manifest, 'application/json');
    else { await writeFile(path.join(stage, 'backup-manifest.json'), manifest, { flag: 'wx' }); await rename(stage, destination); }
    await progress('complete');
    return { ...(store ? { bucket: store.config.bucket, prefix: store.config.prefix, snapshot } : { path: destination }), manifest_sha256: digest(manifest), files: records.length, bytes: totalBytes, unique_objects: uniqueObjects, unique_bytes: uniqueBytes, verified: true };
  } finally { if (store && !injectedStore) store.close(); if (stage) await removeBackupStage(stage, destination); }
}

function parseBackupManifest(bytes, expected) {
  if (expected && (!/^[a-f0-9]{64}$/.test(expected) || digest(bytes) !== expected)) throw new Error('Backup manifest SHA-256 does not match the recovery pin');
  const manifest = JSON.parse(bytes.toString('utf8'));
  if (manifest.schema_version !== 1 || !Array.isArray(manifest.files)) throw new Error('Unsupported backup manifest');
  const paths = new Set();
  for (const file of manifest.files) {
    backupPath(file.path);
    const identity = file.path.toLowerCase();
    if (paths.has(identity)) throw new Error(`Duplicate backup file path: ${file.path}`);
    paths.add(identity);
    if (!/^[a-f0-9]{64}$/.test(file.sha256) || !Number.isSafeInteger(file.bytes) || file.bytes < 0 || (file.object != null && file.object !== `objects/${file.sha256}`)) throw new Error('Invalid backup file record');
  }
  for (const item of paths) {
    const parts = item.split('/');
    for (let index = 1; index < parts.length; index++) if (paths.has(parts.slice(0, index).join('/'))) throw new Error('Conflicting backup file and directory paths');
  }
  return manifest;
}
export async function restoreWorkspace({ destination, backup, snapshot, manifestSha256, concurrency = 4, onProgress, store: injectedStore, ...options }) {
  if (!destination) throw new Error('Restore requires a new destination');
  const count = workerCount(concurrency);
  destination = await plainDirectory(destination);
  if (await exists(destination)) throw new Error('Restore destination must be new; existing files cannot be overwritten');
  if (backup) {
    backup = await plainDirectory(backup);
    if (!(await lstat(backup)).isDirectory()) throw new Error('Backup source must be a regular directory');
    backup = await realpath(backup);
    if (contained(backup, destination) || contained(destination, backup)) throw new Error('Restore destination must be outside the backup source');
  } else if (!snapshot || !/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/.test(snapshot)) throw new Error('Cloud restore requires an explicit --snapshot ID');
  const store = backup ? null : injectedStore || await createS3Store(options);
  const stage = `${destination}.stage-${randomUUID()}`;
  try {
    let bytes;
    if (backup) {
      const file = path.join(backup, 'backup-manifest.json');
      if (!(await lstat(file)).isFile() || (await lstat(file)).isSymbolicLink()) throw new Error('Backup manifest must be a regular file');
      bytes = await readFile(file);
    } else bytes = await store.get(`snapshots/${snapshot}/backup-manifest.json`);
    if (!bytes) throw new Error('Backup snapshot manifest is missing');
    const manifest = parseBackupManifest(bytes, manifestSha256);
    if (!backup && manifest.snapshot !== snapshot) throw new Error('Backup snapshot identity does not match');
    const totalBytes = manifest.files.reduce((sum, file) => sum + file.bytes, 0);
    let completed = 0, verifiedBytes = 0;
    const progress = (phase, detail = {}) => onProgress?.({ phase, files: completed, totalFiles: manifest.files.length, bytes: verifiedBytes, totalBytes, ...detail });
    await progress('scanned'); await mkdir(stage, { recursive: true });
    await pooled(manifest.files, count, async file => {
      let payload;
      if (backup) {
        const source = path.join(backup, file.path), parts = file.path.split('/');
        for (let index = 1; index <= parts.length; index++) if ((await lstat(path.join(backup, ...parts.slice(0, index)))).isSymbolicLink()) throw new Error(`Restore refuses symlink source: ${file.path}`);
        if (!(await lstat(source)).isFile()) throw new Error('Restore source must be a regular file');
        payload = await readFile(source);
      } else {
        if (file.object !== `objects/${file.sha256}`) throw new Error('Cloud backup file has no matching content object');
        payload = await store.get(file.object);
      }
      if (!payload || payload.length !== file.bytes || digest(payload) !== file.sha256) throw new Error(`Backup restoration integrity failed: ${file.path}`);
      const target = path.resolve(stage, file.path);
      if (!contained(stage, target)) throw new Error('Restored file escaped the staging directory');
      await mkdir(path.dirname(target), { recursive: true }); await writeFile(target, payload, { flag: 'wx' });
      const checked = await readFile(target);
      if (checked.length !== file.bytes || digest(checked) !== file.sha256) throw new Error(`Restored file readback failed: ${file.path}`);
      completed++; verifiedBytes += file.bytes; await progress('verified', { path: file.path });
    });
    if (await exists(destination)) throw new Error('Restore destination appeared during recovery; refusing overwrite');
    await rename(stage, destination); await progress('complete');
    return { path: destination, snapshot: manifest.snapshot || null, manifest_sha256: digest(bytes), files: completed, bytes: verifiedBytes, verified: true };
  } finally { if (store && !injectedStore) store.close(); await removeBackupStage(stage, destination); }
}
