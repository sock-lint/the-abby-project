export type AppearanceField = 'body'|'skin'|'outfit'|'head'|'hair_style'|'hair_color'|'face_style'|'face_color';
export type Appearance = Record<AppearanceField,string>;
export interface AvatarConfiguration { schema_version:2; family_id:string; appearance:Appearance; slots:Record<string,string>; emission_enabled:boolean }
export interface RuntimeFile { path:string; sha256:string; bytes:number; media_type:'model/gltf-binary'|'image/png' }
export interface CatalogItem { id:string; file:string; path:string; sha256:string; bytes:number; label?:string; rig_adapter_id?:string; attachment_node?:string; hide_nodes?:string[]; [key:string]:unknown }
export interface AppearanceCatalog { schema_version:1; family_id:string; label:string; rig_adapter_ids:string[]; defaults:Appearance; selectors:Record<AppearanceField,{id:string;label:string}[]>; replacement_nodes:Record<string,string[]>; base_variants:CatalogItem[]; modules:CatalogItem[]; equipment_overrides:CatalogItem[]; textures:CatalogItem[]; projectiles:CatalogItem[]; emission:{default_enabled:boolean;maps:CatalogItem[]} }
export interface ReleaseManifest { schema_version:1; family_id:string; release_version:string; label:string; appearance:AppearanceCatalog; equipment_catalogs:{rig_adapter_id:string;items:CatalogItem[]}[]; animations:{actions:Record<string,string>;root_node:string;clips:{name:string;duration:number;loop:boolean;root_motion:'in-place'|'vertical'|'source'}[]}; files:RuntimeFile[]; portraits?:CatalogItem[] }
export const APPEARANCE_FIELDS:readonly AppearanceField[];
export const CONFIGURATION_SCHEMA_VERSION:2;
export const RELEASE_SCHEMA_VERSION:1;
export function isSafeRelativePath(value:unknown):boolean;
export function validateManifest(value:unknown):ReleaseManifest;
export function defaultConfiguration(manifest:ReleaseManifest):AvatarConfiguration;
export function validateConfiguration(value:unknown,manifest:ReleaseManifest):AvatarConfiguration;
export function resolveConfiguration(manifest:ReleaseManifest,value?:AvatarConfiguration):{configuration:AvatarConfiguration;variant:CatalogItem;equipment:CatalogItem[];modules:CatalogItem[];effectiveAppearance:Appearance;catalog:AppearanceCatalog};
export function resolveReleaseUrl(base:string,file:string):string;
