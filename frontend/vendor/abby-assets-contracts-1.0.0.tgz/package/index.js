export const APPEARANCE_FIELDS = Object.freeze(['body', 'skin', 'outfit', 'head', 'hair_style', 'hair_color', 'face_style', 'face_color']);
export const CONFIGURATION_SCHEMA_VERSION = 2;
export const RELEASE_SCHEMA_VERSION = 1;
const sha256 = /^[a-f0-9]{64}$/;
const id = /^[a-zA-Z0-9][a-zA-Z0-9._-]*$/;
const validId = value => typeof value === 'string' && id.test(value);
const fail = message => { throw new Error(`Asset contract: ${message}`); };
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export function isSafeRelativePath(value) {
  return typeof value === 'string' && value.length > 0 && !value.includes('\\') && !value.includes(':') && !value.includes('%') && !value.startsWith('/') && value.split('/').every(part => part && part !== '.' && part !== '..' && /^[a-zA-Z0-9._-]+$/.test(part));
}
export function validateManifest(value) {
  if (!plain(value) || value.schema_version !== 1) fail('unsupported release schema');
  if (!validId(value.family_id) || typeof value.release_version !== 'string' || !/^\d+\.\d+\.\d+(?:-[a-z0-9.-]+)?$/.test(value.release_version)) fail('invalid release identity');
  const privateMetadata = entry => {
    if (Array.isArray(entry)) { entry.forEach(privateMetadata); return; }
    if (plain(entry)) { for (const [key, child] of Object.entries(entry)) { if (/^(source(?:_|$)|authoring$|sourcePaths$)/i.test(key)) fail('release contains private authoring metadata'); privateMetadata(child); } }
    else if (typeof entry === 'string' && (/^[a-zA-Z]:[\\/]/.test(entry) || /\.(?:blend[12]?|zip|fbx|unitypackage)(?:$|[/?])/i.test(entry))) fail('release contains an authoring path');
  };
  privateMetadata(value);
  if (!plain(value.appearance) || value.appearance.family_id !== value.family_id) fail('appearance family does not match release');
  if (!Array.isArray(value.files) || !value.files.length) fail('release has no files');
  const files = new Map();
  for (const file of value.files) {
    if (!isSafeRelativePath(file.path) || !sha256.test(file.sha256) || !Number.isSafeInteger(file.bytes) || file.bytes < 1 || files.has(file.path)) fail('invalid or duplicate release file');
    if (!/^objects\/[a-f0-9]{64}\.(?:glb|png)$/.test(file.path) || file.path !== `objects/${file.sha256}.${file.path.split('.').at(-1)}`) fail('file is not content addressed runtime media');
    if (!['model/gltf-binary', 'image/png'].includes(file.media_type)) fail('unsupported runtime media type');
    if ((file.path.endsWith('.glb') ? 'model/gltf-binary' : 'image/png') !== file.media_type) fail('runtime media type does not match extension');
    files.set(file.path, file);
  }
  const catalog = value.appearance;
  if (!Array.isArray(catalog.rig_adapter_ids) || !catalog.rig_adapter_ids.length || catalog.rig_adapter_ids.some(value => !validId(value)) || new Set(catalog.rig_adapter_ids).size !== catalog.rig_adapter_ids.length) fail('missing, invalid or duplicate compatible rigs');
  if (!plain(catalog.selectors) || !plain(catalog.defaults)) fail('missing appearance choices');
  for (const field of APPEARANCE_FIELDS) {
    const choices = catalog.selectors[field];
    if (!Array.isArray(choices) || !choices.length || choices.some(option => !plain(option) || !validId(option.id)) || new Set(choices.map(option => option.id)).size !== choices.length) fail(`invalid or duplicate ${field} choices`);
    if (!validId(catalog.defaults[field]) || !choices.some(option => option.id === catalog.defaults[field])) fail(`invalid ${field} default`);
  }
  const reference = item => {
    if (!plain(item) || !validId(item.id)) fail('invalid catalog entry');
    const file = files.get(item.file || item.path);
    if (!file || item.sha256 !== file.sha256 || item.bytes !== file.bytes) fail(`untracked or mismatched file for ${item.id}`);
    if (item.path && item.path !== item.file) fail(`inconsistent file aliases for ${item.id}`);
  };
  for (const key of ['base_variants', 'modules', 'equipment_overrides', 'textures', 'projectiles']) {
    if (!Array.isArray(catalog[key])) fail(`missing ${key}`);
    const seen = new Set();
    for (const item of catalog[key]) { reference(item); if (seen.has(item.id)) fail(`duplicate ${key} id`); seen.add(item.id); }
  }
  if (!catalog.base_variants.length) fail('release has no prepared bases');
  const combinations = new Set();
  for (const variant of catalog.base_variants) {
    if (!validId(variant.rig_adapter_id) || !catalog.rig_adapter_ids.includes(variant.rig_adapter_id)) fail('base has an unapproved rig adapter');
    for (const field of ['body', 'skin', 'outfit']) if (!validId(variant[field]) || !catalog.selectors[field].some(option => option.id === variant[field])) fail(`base has an unknown ${field} choice`);
    const combination = JSON.stringify([variant.body, variant.skin, variant.outfit]);
    if (combinations.has(combination)) fail('duplicate prepared base combination'); combinations.add(combination);
  }
  for (const module of catalog.modules) if (!['head', 'hair', 'face'].includes(module.category) || typeof module.attachment_node !== 'string' || !module.attachment_node.length) fail('invalid fitted module attachment');
  if (!Array.isArray(value.equipment_catalogs)) fail('missing equipment catalogs');
  for (const entry of value.equipment_catalogs) {
    if (!validId(entry.rig_adapter_id) || !catalog.rig_adapter_ids.includes(entry.rig_adapter_id) || !Array.isArray(entry.items)) fail('equipment has an unapproved adapter');
    const seen = new Set();
    for (const item of entry.items) { reference(item); if (seen.has(item.id) || !validId(item.slot) || typeof item.attachment_node !== 'string' || !item.attachment_node.length) fail('invalid equipment slot or duplicate id'); seen.add(item.id); }
  }
  if (new Set(value.equipment_catalogs.map(entry => entry.rig_adapter_id)).size !== value.equipment_catalogs.length) fail('duplicate equipment adapter');
  if (!plain(value.animations?.actions) || !Array.isArray(value.animations?.clips)) fail('missing animation semantics');
  const clipNames = new Set();
  for (const clip of value.animations.clips) {
    if (!plain(clip) || typeof clip.name !== 'string' || !clip.name.length || clipNames.has(clip.name) || !Number.isFinite(clip.duration) || clip.duration < 0 || typeof clip.loop !== 'boolean' || !['in-place', 'vertical', 'source'].includes(clip.root_motion)) fail('invalid or duplicate animation clip');
    clipNames.add(clip.name);
  }
  for (const [action, name] of Object.entries(value.animations.actions)) if (!validId(action) || typeof name !== 'string' || !clipNames.has(name)) fail('animation action names an unknown clip');
  for (const portrait of value.portraits || []) reference(portrait);
  return value;
}
export function defaultConfiguration(manifest) {
  return { schema_version: 2, family_id: manifest.family_id, appearance: { ...manifest.appearance.defaults }, slots: {}, emission_enabled: Boolean(manifest.appearance.emission?.default_enabled) };
}
export function validateConfiguration(value, manifest) {
  if (!plain(value) || value.schema_version !== 2 || value.family_id !== manifest.family_id) fail('configuration family or schema is incompatible');
  for (const key of Object.keys(value)) if (!['schema_version', 'family_id', 'appearance', 'slots', 'emission_enabled'].includes(key)) fail(`configuration contains unsupported field ${key}`);
  if (!plain(value.appearance) || !plain(value.slots) || typeof value.emission_enabled !== 'boolean') fail('configuration is incomplete');
  for (const field of Object.keys(value.appearance)) if (!APPEARANCE_FIELDS.includes(field)) fail(`unknown appearance field ${field}`);
  const config = defaultConfiguration(manifest);
  for (const field of APPEARANCE_FIELDS) {
    const choice = value.appearance[field] ?? config.appearance[field];
    if (!manifest.appearance.selectors[field]?.some(option => option.id === choice)) fail(`unknown ${field} choice`);
    config.appearance[field] = choice;
  }
  config.slots = { ...value.slots }; config.emission_enabled = value.emission_enabled;
  const variant = manifest.appearance.base_variants.find(item => ['body', 'skin', 'outfit'].every(field => item[field] === config.appearance[field]));
  if (!variant) fail('no prepared base for these choices');
  const catalog = manifest.equipment_catalogs.find(entry => entry.rig_adapter_id === variant.rig_adapter_id);
  for (const [slot, itemId] of Object.entries(config.slots)) if (!catalog?.items.some(item => item.id === itemId && item.slot === slot)) fail(`incompatible equipment in ${slot}`);
  return config;
}
export function resolveConfiguration(manifest, value = defaultConfiguration(manifest)) {
  const configuration = validateConfiguration(value, manifest), catalog = manifest.appearance;
  const variant = catalog.base_variants.find(item => ['body', 'skin', 'outfit'].every(field => item[field] === configuration.appearance[field]));
  const equipmentCatalog = manifest.equipment_catalogs.find(entry => entry.rig_adapter_id === variant.rig_adapter_id);
  const equipment = Object.values(configuration.slots).map(itemId => equipmentCatalog.items.find(item => item.id === itemId));
  const effectiveAppearance = { ...configuration.appearance };
  if (effectiveAppearance.hair_style !== 'none') {
    const override = equipment.find(item => item.hair_style_override);
    if (override) effectiveAppearance.hair_style = override.hair_style_override;
  }
  const modules = Object.entries({ head: ['head', 'skin'], face: ['face_style', 'face_color'], hair: ['hair_style', 'hair_color'] }).flatMap(([category, fields]) => {
    if (category === 'hair' && effectiveAppearance.hair_style === 'none') return [];
    const item = catalog.modules.find(item => item.category === category && fields.every(field => item[field] === effectiveAppearance[field]));
    if (!item) fail(`no prepared ${category} module for these choices`);
    return [item];
  });
  return { configuration, variant, equipment, modules, effectiveAppearance, catalog };
}
export function resolveReleaseUrl(base, file) {
  if (!isSafeRelativePath(file)) fail('unsafe release file path');
  return `${String(base).replace(/\/?$/, '/')}${file}`;
}
