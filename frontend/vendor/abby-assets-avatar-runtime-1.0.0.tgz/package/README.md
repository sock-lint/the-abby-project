# Shared avatar runtime

Private source package. Purchased models are distributed separately in private,
immutable releases; this package contains no licensed artwork. Install the packed
contracts and runtime packages together. React, Three.js and R3F are supplied by
the application. The core entry point does not import React or create a renderer.

```js
import { loadRelease, loadAvatar } from '@abby-assets/avatar-runtime';

const pin = lock.releases.find(item => item.family_id === 'meshtint-female-archer-pack-01');
const baseUrl = `/assets/shared/${pin.directory}/`;
const release = await loadRelease(`${baseUrl}manifest.json`, { sha256: pin.manifest_sha256 });
const avatar = await loadAvatar(release, savedConfiguration, { baseUrl, signal });
scene.add(avatar.scene);
const playback = avatar.createAnimationController();
playback.play('idle'); // Manifest semantics: idle, walk, run, jump.
// In the application's own frame loop:
playback.update(delta, { active: visible, paused, reducedMotion });
// When removed:
scene.remove(avatar.scene);
avatar.dispose(); // Includes mixers, geometry, materials, textures and skeletons.
```

For bundlers, supply `resolveUrl(file)` instead of `baseUrl`. It must map the
original release-relative file names to bundled URLs; hashes remain verified.
Every call parses an independent instance without a global cache. Do not share
one instance between scenes or mount it twice. Application transforms belong on
`avatar.scene`; authored meters, proportions and pivots remain intact. Scene
framing, lighting, Canvas, frame scheduling, movement and entitlements stay in the
application.

```jsx
import { AvatarModel } from '@abby-assets/avatar-runtime/react';

// Inside an existing Canvas. The component owns this loaded instance.
<AvatarModel release={release} configuration={configuration} baseUrl={baseUrl}
  action="idle" active={visible} reducedMotion={reducedMotion}
  onError={setError} />
// Or supply avatar={loadedAvatar}; its creator remains responsible for disposal.
```

`useAvatar` exposes `{ avatar, loading, error }` when the application needs an
explicit loading UI. `onError` surfaces load/clip failures. `animation` selects an
exact clip name instead of the `action` semantic. `rootMotion="in-place"` cancels
horizontal translation through a dedicated wrapper and preserves jump height;
`"source"` retains authored travel. Animation defaults come from release metadata.
Paused, inactive and reduced-motion instances do not advance. Playback alone does
not schedule demand-rendered Canvas frames; the application supplies that clock.

The Asset Lab imports the same attachment, emission, export, disposal and playback
functions. Catalog acquisition and diagnostic controls remain workshop concerns.
The core loader verifies file sizes/hashes, embedded GLBs, inspected rig metadata,
the matching equipment catalog and named sockets. An aborted or failed load waits
for its outstanding resource tasks and disposes them before rejecting.

Run focused checks from AbbyAssets with:

```
node --import ./packages/runtime/test/register.mjs --test packages/runtime/test/*.test.mjs
```

Tests resolve the lab's installed Three peer without modifying either isolated
renderer dependency tree. Browser acceptance still requires both lab profiles
and the actual consumer scenes; phone performance is a separate check.
