import type { AnimationAction, AnimationClip, AnimationMixer, Group, Object3D } from 'three';
import type { AvatarConfiguration, ReleaseManifest } from '@abby-assets/contracts';
export type { AvatarConfiguration, ReleaseManifest } from '@abby-assets/contracts';
export type AvatarConfigurationV2 = AvatarConfiguration;
export type RootMotion = 'source' | 'in-place';
export interface LoadOptions {
  baseUrl?: string;
  resolveUrl?: (file: string) => string;
  signal?: AbortSignal;
  fetch?: typeof globalThis.fetch;
  shadows?: boolean;
  wireframe?: boolean;
}
export interface AnimationController {
  mixer: AnimationMixer;
  readonly action: AnimationAction | null;
  readonly time: number;
  play(name: string, options?: { loop?: boolean; fadeSeconds?: number; speed?: number; rootMotion?: RootMotion }): AnimationAction;
  update(delta: number, options?: { active?: boolean; paused?: boolean; reducedMotion?: boolean; maxDelta?: number }): void;
  seek(seconds: number): void;
  setRootMotion(value: RootMotion): void;
  onFinished(listener: (event: { action: AnimationAction; direction: number }) => void): () => void;
  stop(): void;
  dispose(): void;
}
export interface LoadedAvatar {
  scene: Group;
  model: Object3D;
  motion: Group;
  animations: AnimationClip[];
  configuration: AvatarConfiguration;
  rigAdapterId: string;
  release: ReleaseManifest;
  identityBounds: { min: number[]; max: number[]; size: number[] };
  createAnimationController(options?: { rootMotion?: RootMotion }): AnimationController;
  dispose(): void;
}
export function loadRelease(url: string, options?: Pick<LoadOptions, 'fetch'|'signal'> & { sha256?: string }): Promise<ReleaseManifest>;
export function loadAvatar(release: ReleaseManifest, configuration?: AvatarConfiguration, options?: LoadOptions): Promise<LoadedAvatar>;
export function createAnimationController(model: Object3D, clips: AnimationClip[], options?: { animations?: ReleaseManifest['animations']; motionRoot?: Object3D; rootNodeName?: string; rootMotion?: RootMotion }): AnimationController;
export function disposeObject(root: Object3D): void;
export function attachAppearance(model: Object3D, appearance: any, options?: { wireframe?: boolean; shadows?: boolean }): { dispose(): void };
export function attachEquipment(model: Object3D, equipment?: any[], options?: { wireframe?: boolean; shadows?: boolean }): { attached: Object3D[]; dispose(): void };
export function applyEmission(model: Object3D, emission: any): { dispose(): void };
export function exportEquippedGlb(asset: any, equipment: any[], metadata: any, appearance?: any): Promise<ArrayBuffer>;
