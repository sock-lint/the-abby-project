# Shared avatar runtime

Private source package. Purchased models are distributed separately in private,
immutable releases; this package contains no licensed artwork. Install the packed
contracts and runtime packages together. React, Three.js and R3F are supplied by
the application. The core entry point does not import React or create a renderer.

```js
import { loadRelease, loadAvatar } from '@abby-assets/avatar-runtime';

const pin = lock.releases.find(item => item.family_id === 'meshtint-female-archer-pack-01');
const baseUrl = `/assets/shared/${pin.directory}/`;
const release = await loadRelease(`${baseUrl}manifest.json`, { sha256: pin.manifest_sha256 });
const avatar = await loadAvatar(release, savedConfiguration, { baseUrl, signal });
scene.add(avatar.scene);
const playback = avatar.createAnimationController();
playback.play('idle'); // Manifest semantics: idle, walk, run, jump.
// In the application's own frame loop:
playback.update(delta, { active: visible, paused, reducedMotion });
// When removed:
scene.remove(avatar.scene);
avatar.dispose(); // Includes mixers, geometry, materials, textures and skeletons.
```

For bundlers, supply `resolveUrl(file)` instead of `baseUrl`. It must map the
original release-relative file names to bundled URLs; hashes remain verified.
Every call parses an independent instance without a global cache. Do not share
one instance between scenes or mount it twice. Application transforms belong on
`avatar.scene`; authored meters, proportions and pivots remain intact. Scene
framing, lighting, Canvas, frame scheduling, movement and entitlements stay in the
application.

```jsx
import { AvatarModel } from '@abby-assets/avatar-runtime/react';

// Inside an existing Canvas. The component owns this loaded instance.
<AvatarModel release={release} configuration={configuration} baseUrl={baseUrl}
  action="idle" active={visible} reducedMotion={reducedMotion}
  onError={setError} />
// Or supply avatar={loadedAvatar}; its creator remains responsible for disposal.
```

`useAvatar` exposes `{ avatar, loading, error }` when the application needs an
explicit loading UI. `onError` surfaces load/clip failures. `animation` selects an
exact clip name instead of the `action` semantic. `rootMotion="in-place"` cancels
horizontal translation through a dedicated wrapper and preserves jump height;
`"source"` retains authored travel. Animation defaults come from release metadata.
Paused, inactive and reduced-motion instances do not advance. Playback alone does
not schedule demand-rendered Canvas frames; the application supplies that clock.

The Asset Lab imports the same attachment, emission, export, disposal and playback
functions. Catalog acquisition and diagnostic controls remain workshop concerns.
The core loader verifies file sizes/hashes, embedded GLBs, inspected rig metadata,
the matching equipment catalog and named sockets. An aborted or failed load waits
for its outstanding resource tasks and disposes them before rejecting.

## Typed assets

`loadRelease` and `loadAvatar` retain their avatar-specific contracts. For a
prepared creature, mount, prop, environment, equipment item, complete avatar
variant or animation-library GLB, use the additive typed pack API:

```js
import { loadAssetPack, loadAsset } from '@abby-assets/avatar-runtime';

const pack = await loadAssetPack(`${baseUrl}manifest.json`, {
  sha256: pin.manifest_sha256,
  signal,
});
const asset = await loadAsset(pack, {
  family_id: pin.family_id,
  asset_id: 'chick',
  // variant_id: 'aqua', // Otherwise the member's authored default.
}, { baseUrl, signal });
scene.add(asset.scene);
const animation = asset.createAnimationController();
animation.play('idle'); // Uses this variant's exact action map.
animation.update(delta, { active: visible, paused, reducedMotion });
scene.remove(asset.scene);
asset.dispose();
```

These instances use the same playback controller as avatars. Generic playback
preserves authored travel by default (`rootMotion: "source"`). Explicit
`"in-place"` playback requires the variant's inspected named animation root;
it cancels horizontal translation while retaining vertical travel. Authored
clip `root_motion` describes motion and does not select an application movement
policy. Supply an explicit `loop` when its metadata is null and the shared
playback default does not suit the application.

In-place compensation subtracts displacement from the root's captured authored
rest point in the motion wrapper's parent frame. Nonzero pivots and nested
rotations/nonuniform scale retain their baseline. Application transforms above
that wrapper remain intact. A motion wrapper outside the root's ancestor chain,
or one with a manually managed matrix, cannot safely receive this compensation;
explicit in-place playback rejects those bases while source playback remains
available.

The GLB loader verifies content-addressed file bytes, embedded buffers/textures,
and declared geometry, skinning, animation names/durations, root node and any
nonnull inspected rig ID against the parsed model. Null compatibility metadata
stays null; it does not infer adapters or retarget clips between assets or
families. Manifest rest/motion bounds and root-motion descriptions remain
authoring QA evidence rather than claims of full runtime motion validation.
`identityBounds` is the finite rest-pose mesh box actually measured during load,
or null for an animation-only scene. Authored scale, orientation and pivots stay
intact; no universal normalization is applied.

Every call owns its parsed scenes and resources. Disposal stops all its mixers
and releases geometry, materials, textures and skeletons once, including shared
resources across multiple GLB scenes. Load aborts or failed post-parse checks
dispose the parsed instance before rejecting. Neither API creates a renderer,
implements acquisition/evolution/slots, fits equipment, or schedules frames.
An `evolution` relationship is descriptive authoring metadata only.

When a relationship declares an authored transition, the contracts helper selects
its exact payload and action:

```js
import { resolveEvolution } from '@abby-assets/contracts';

const next = resolveEvolution(pack, 'chick', 'fledgling');
const effect = await loadAsset(pack, next.selection, { baseUrl, signal });
const playback = effect.createAnimationController({ rootMotion: 'source' });
playback.play(next.action, { loop: false });
```

The app adds that instance to its scene, updates the controller each frame, and
uses `playback.onFinished` to replace it with the destination's idle variant.
Dispose the previous instance and cancel stale completion handlers if selection
changes during loading or playback. Preload the destination idle to avoid a
network gap. Each Bird family motion carries its own native rig; switch variant
instances rather than copying actions between skeletons. Completion does not
commit progression or saved state.

PNG artwork can be distributed and selected through the asset-pack contract;
`loadAsset` clearly rejects it because it needs an image renderer. The loader
also rejects a file-library manifest rather than treating an FBX as a GLB.
Existing React avatar components remain avatar-specific; a generic Three/R3F
consumer adds the owned `asset.scene` to its existing scene/primitive and owns
its lifecycle.

Run focused checks from AbbyAssets with:

```
node --import ./packages/runtime/test/register.mjs --test packages/runtime/test/*.test.mjs
```

Tests resolve the lab's installed Three peer without modifying either isolated
renderer dependency tree. Browser acceptance still requires both lab profiles
and the actual consumer scenes; phone performance is a separate check.
