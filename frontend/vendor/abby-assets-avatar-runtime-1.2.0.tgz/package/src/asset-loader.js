import { Box3, Group, Vector3 } from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { resolveAssetVariant, resolveReleaseUrl, validateAssetPackManifest } from '@abby-assets/contracts';
import { abort, inspectEmbeddedGlb, requestBytes } from './loader.js';
import { createAnimationController } from './animation.js';
import { disposeObjects } from './resources.js';

/** Load a typed pack without widening the existing avatar loadRelease API. */
export async function loadAssetPack(url, options = {}) {
  const bytes = await requestBytes(url, options, { sha256: options.sha256 });
  return validateAssetPackManifest(JSON.parse(new TextDecoder().decode(bytes)));
}

/** Load one prepared GLB variant. Every call owns independent parsed resources;
 * this does not retarget clips, fit equipment, evolve pets or grant ownership. */
export async function loadAsset(release, selection, options = {}) {
  const { asset, variant, file } = resolveAssetVariant(release, selection);
  if (file.media_type !== 'model/gltf-binary') throw new Error('loadAsset supports prepared GLB variants only; image assets require an image renderer.');
  if (!options.baseUrl && !options.resolveUrl) throw new Error('loadAsset requires the release directory baseUrl or resolveUrl.');
  const url = options.resolveUrl ? options.resolveUrl(file.path) : resolveReleaseUrl(options.baseUrl, file.path);
  const controllers = new Set();
  let gltf, disposed = false;
  const dispose = () => {
    if (disposed) return;
    disposed = true;
    controllers.forEach(controller => controller.dispose()); controllers.clear();
    disposeObjects(gltf?.scenes?.length ? gltf.scenes : [gltf?.scene]);
  };
  try {
    const bytes = await requestBytes(url, options, file);
    inspectEmbeddedGlb(bytes);
    gltf = await new GLTFLoader().parseAsync(bytes, '');
    abort(options.signal);
    const model = gltf.scene, adapters = new Set();
    let meshes = 0, skinnedMeshes = 0;
    model.updateMatrixWorld(true);
    model.traverse(node => {
      for (const key of ['asset_rig_adapter_id', 'avatar_rig_adapter_id', 'rig_adapter_id']) {
        if (typeof node.userData[key] === 'string') adapters.add(node.userData[key]);
      }
      if (node.skeleton) node.skeleton.update();
      if (!node.isMesh) return;
      meshes++;
      if (node.isSkinnedMesh && node.skeleton?.bones?.length) skinnedMeshes++;
      node.castShadow = Boolean(options.shadows); node.receiveShadow = Boolean(options.shadows);
      for (const material of Array.isArray(node.material) ? node.material : node.material ? [node.material] : []) material.wireframe = Boolean(options.wireframe);
    });
    const box = new Box3().setFromObject(model, true), size = box.getSize(new Vector3());
    let identityBounds = null;
    if (!box.isEmpty()) {
      if (![...box.min.toArray(), ...box.max.toArray(), ...size.toArray()].every(Number.isFinite)) throw new Error('The asset has non-finite identity mesh bounds.');
      identityBounds = { min: box.min.toArray(), max: box.max.toArray(), size: size.toArray() };
    }
    if (asset.capabilities.includes('model') && (!meshes || !identityBounds)) throw new Error('The asset does not contain its declared model geometry.');
    if (asset.capabilities.includes('skinned') && !skinnedMeshes) throw new Error('The asset does not contain its declared skinned model.');
    if (asset.capabilities.includes('animated') && !gltf.animations.length) throw new Error('The asset does not contain its declared animations.');
    if (variant.rig_adapter_id !== null && !adapters.has(variant.rig_adapter_id)) throw new Error('The asset does not contain its declared inspected rig adapter.');
    if (variant.animations) {
      if (variant.animations.root_node !== null && !model.getObjectByName(variant.animations.root_node)) throw new Error('The asset does not contain its declared animation root.');
      for (const declared of variant.animations.clips) {
        const matches = gltf.animations.filter(clip => clip.name === declared.name);
        if (matches.length !== 1) throw new Error(`The asset does not contain one declared animation clip: ${declared.name}`);
        if (declared.duration !== null && Math.abs(matches[0].duration - declared.duration) > Math.max(.0001, declared.duration * .00001)) throw new Error(`The asset animation duration differs from its release: ${declared.name}`);
      }
    }
    const scene = new Group(), motion = new Group();
    scene.name = 'SharedAsset'; motion.name = 'SharedAssetMotion'; motion.add(model); scene.add(motion); scene.updateMatrixWorld(true);
    const requireRoot = rootMotion => {
      if (rootMotion !== undefined && !['source', 'in-place'].includes(rootMotion)) throw new Error('Asset playback rootMotion must be source or in-place.');
      if (rootMotion === 'in-place' && !variant.animations?.root_node) throw new Error('In-place asset playback requires an inspected animation root.');
    };
    return {
      scene, model, motion, animations: gltf.animations, identityBounds, rigAdapterId: variant.rig_adapter_id,
      familyId: release.family_id, assetId: asset.id, variantId: variant.id, release, asset, variant, dispose,
      createAnimationController(settings = {}) {
        if (disposed) throw new Error('This asset has been disposed.');
        requireRoot(settings.rootMotion);
        // Preserve authored travel by default; root_motion metadata describes
        // the clip and never invents an application movement policy.
        const controller = createAnimationController(model, gltf.animations, {
          animations: variant.animations || {}, motionRoot: motion, rootMotion: settings.rootMotion ?? 'source',
        });
        const play = controller.play, setRootMotion = controller.setRootMotion, disposeController = controller.dispose;
        controller.play = (name, playback = {}) => { requireRoot(playback.rootMotion); return play(name, playback); };
        controller.setRootMotion = value => { requireRoot(value); setRootMotion(value); };
        controller.dispose = () => { disposeController(); controllers.delete(controller); };
        controllers.add(controller); return controller;
      },
    };
  } catch (error) { dispose(); throw error; }
}
