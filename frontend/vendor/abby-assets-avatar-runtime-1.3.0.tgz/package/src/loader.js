import { Box3, Group, TextureLoader, SRGBColorSpace, Vector3 } from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { validateManifest, resolveConfiguration, resolveReleaseUrl } from '@abby-assets/contracts';
import { attachAppearance, attachEquipment, applyEmission } from './assembly.js';
import { createAnimationController } from './animation.js';
import { disposeObject } from './resources.js';

export const abort = signal => { if (signal?.aborted) throw signal.reason || new DOMException('Loading was aborted.', 'AbortError'); };
async function digest(buffer) {
  return [...new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', buffer))].map(byte => byte.toString(16).padStart(2, '0')).join('');
}
export async function requestBytes(url, { fetch: fetcher = globalThis.fetch, signal } = {}, record = {}) {
  abort(signal);
  const response = await fetcher(url, { signal });
  if (!response.ok) throw new Error(`Asset request failed (${response.status}): ${url}`);
  const bytes = await response.arrayBuffer(); abort(signal);
  if (record.bytes != null && record.bytes !== bytes.byteLength) throw new Error(`Asset byte size does not match the release: ${record.file || url}`);
  if (record.sha256 && await digest(bytes) !== record.sha256) throw new Error(`Asset SHA-256 does not match the release: ${record.file || url}`);
  abort(signal); return bytes;
}

/** Fetch and validate a pinned manifest. sha256 is the digest from assets.lock.json. */
export async function loadRelease(url, options = {}) {
  const buffer = await requestBytes(url, options, { sha256: options.sha256 });
  const manifest = JSON.parse(new TextDecoder().decode(buffer));
  validateManifest(manifest); return manifest;
}

export function inspectEmbeddedGlb(buffer) {
  if (buffer.byteLength < 20) throw new Error('Release model is too short to be a GLB.');
  const view = new DataView(buffer);
  if (view.getUint32(0, true) !== 0x46546c67 || view.getUint32(4, true) !== 2 || view.getUint32(8, true) !== buffer.byteLength || view.getUint32(16, true) !== 0x4e4f534a) throw new Error('Release model must be a complete GLB 2.0.');
  const size = view.getUint32(12, true);
  if (size > buffer.byteLength - 20) throw new Error('Release GLB JSON chunk is invalid.');
  const json = JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, 20, size)));
  if (json.asset?.version !== '2.0' || [...(json.buffers || []), ...(json.images || [])].some(item => item.uri)) throw new Error('Release GLBs must embed every buffer and texture.');
}

/** Each call owns its parsed scenes, skeletons, textures and mixers. No global
 * cache or renderer is created. Failure/abort disposes everything loaded so far. */
export async function loadAvatar(release, input, options = {}) {
  validateManifest(release);
  const resolved = resolveConfiguration(release, input);
  const configuration = resolved.configuration;
  const baseUrl = options.baseUrl;
  if (!baseUrl && !options.resolveUrl) throw new Error('loadAvatar requires the release directory baseUrl or resolveUrl.');
  const resourceUrl = item => options.resolveUrl ? options.resolveUrl(item.file || item.path) : resolveReleaseUrl(baseUrl, item.file || item.path);
  const sources = [], textures = [], controllers = new Set();
  let appearance, equipment, emission, disposed = false;
  const dispose = () => {
    if (disposed) return;
    disposed = true; controllers.forEach(controller => controller.dispose()); controllers.clear();
    emission?.dispose(); equipment?.dispose(); appearance?.dispose();
    sources.forEach(source => disposeObject(source.gltf.scene));
    textures.forEach(texture => { texture.dispose(); texture.image?.close?.(); });
  };
  const loadModel = async item => {
    const bytes = await requestBytes(resourceUrl(item), options, item);
    inspectEmbeddedGlb(bytes);
    const gltf = await new GLTFLoader().parseAsync(bytes, '');
    const result = { gltf, stats: { sha256: item.sha256, bytes: bytes.byteLength } };
    sources.push(result); abort(options.signal); return { item, asset: result };
  };
  try {
    const { asset } = await loadModel(resolved.variant), model = asset.gltf.scene;
    model.updateMatrixWorld(true); model.traverse(node => node.skeleton?.update());
    const identityBox = new Box3().setFromObject(model, true), identitySize = identityBox.getSize(new Vector3());
    if (identityBox.isEmpty() || !identitySize.toArray().every(Number.isFinite) || identitySize.length() === 0) throw new Error('The avatar has no finite identity mesh bounds.');
    const identityBounds = { min: identityBox.min.toArray(), max: identityBox.max.toArray(), size: identitySize.toArray() };
    const rigAdapterId = resolved.variant.rig_adapter_id || release.appearance.rig_adapter_id;
    const actualAdapters = new Set();
    model.traverse(node => { const id = node.userData.avatar_rig_adapter_id || node.userData.rig_adapter_id; if (id) actualAdapters.add(id); });
    if (!rigAdapterId || !actualAdapters.has(rigAdapterId)) throw new Error('The release model does not contain its declared inspected rig adapter.');
    const catalog = release.equipment_catalogs.find(item => item.rig_adapter_id === rigAdapterId);
    if (resolved.equipment.length && !catalog) throw new Error('No fitted equipment catalog exists for this rig adapter.');
    const selectedEquipment = resolved.equipment.map(item => {
      const fitted = catalog?.items.find(candidate => candidate.id === item.id && candidate.slot === item.slot);
      if (!fitted) throw new Error(`Equipment is incompatible with ${rigAdapterId}: ${item.id}`);
      return fitted;
    });
    // Wait for every outstanding task before cleanup, including sibling failures.
    const tasks = await Promise.allSettled([...resolved.modules, ...selectedEquipment].map(loadModel));
    const failure = tasks.find(task => task.status === 'rejected');
    if (failure) throw failure.reason;
    const loaded = tasks.map(task => task.value);
    const modules = loaded.slice(0, resolved.modules.length), fitted = loaded.slice(resolved.modules.length);
    const texturePool = {};
    if (configuration.emission_enabled) {
      const textureResults = await Promise.allSettled((release.appearance.textures || []).map(async item => {
        const bytes = await requestBytes(resourceUrl(item), options, item);
        const url = URL.createObjectURL(new Blob([bytes], { type: 'image/png' }));
        let texture;
        try { texture = await new TextureLoader().loadAsync(url); } finally { URL.revokeObjectURL(url); }
        textures.push(texture); abort(options.signal);
        texture.colorSpace = SRGBColorSpace; texture.flipY = false; texture.name = item.id;
        texturePool[item.id] = texture;
      }));
      const failure = textureResults.find(result => result.status === 'rejected');
      if (failure) throw failure.reason;
    }
    abort(options.signal);
    model.traverse(node => {
      if (!node.isMesh) return;
      node.castShadow = Boolean(options.shadows); node.receiveShadow = Boolean(options.shadows);
      for (const material of Array.isArray(node.material) ? node.material : [node.material]) material.wireframe = Boolean(options.wireframe);
    });
    const appearanceState = { catalog: release.appearance, modules, effective: resolved.effectiveAppearance };
    appearance = attachAppearance(model, appearanceState, options);
    equipment = attachEquipment(model, fitted, options);
    emission = applyEmission(model, { enabled: configuration.emission_enabled, maps: release.appearance.textures || [], textures: texturePool });
    const scene = new Group(), motion = new Group(); scene.name = 'SharedAvatar'; motion.name = 'SharedAvatarMotion';
    motion.add(model); scene.add(motion); scene.updateMatrixWorld(true);
    const animations = asset.gltf.animations;
    return {
      scene, model, motion, animations, configuration, rigAdapterId, release, identityBounds, dispose,
      createAnimationController(settings = {}) {
        if (disposed) throw new Error('This avatar has been disposed.');
        const controller = createAnimationController(model, animations, { animations: release.animations, motionRoot: motion, ...settings });
        const disposeController = controller.dispose;
        controller.dispose = () => { disposeController(); controllers.delete(controller); };
        controllers.add(controller); return controller;
      },
    };
  } catch (error) { dispose(); throw error; }
}
