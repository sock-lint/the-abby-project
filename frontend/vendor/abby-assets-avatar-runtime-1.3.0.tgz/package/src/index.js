export { loadAvatar, loadRelease } from './loader.js';
export { loadAssetPack, loadAsset, loadCompanionAppearance, loadAppearanceTransition } from './asset-loader.js';
export { attachAppearance, attachEquipment, applyEmission, exportEquippedGlb } from './assembly.js';
export { createAnimationController } from './animation.js';
export { disposeObject } from './resources.js';
