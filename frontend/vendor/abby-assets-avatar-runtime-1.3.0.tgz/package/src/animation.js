import { AnimationMixer, LoopOnce, LoopRepeat, Matrix4, Vector3 } from 'three';

/** Each controller owns one mixer. Movement belongs to the application; this
 * controller can cancel horizontal source translation while retaining jump Y. */
export function createAnimationController(model, clips, options = {}) {
  const mixer = new AnimationMixer(model);
  const definition = options.animations || {};
  const actions = definition.actions || definition.semantic_actions || {};
  const motionRoot = options.motionRoot;
  const rootNode = model.getObjectByName(definition.root_node || options.rootNodeName || 'JumpRoot');
  const initialMotion = motionRoot?.position.clone();
  let current = null, disposed = false, rootMotion = options.rootMotion || 'in-place';
  const rootMatrix = new Matrix4(), currentRoot = new Vector3();
  let initialRoot = null, unsupportedBasis = null;
  const rootInMotionParent = target => {
    if (!motionRoot.matrixAutoUpdate) throw new Error('In-place playback requires an automatically updated motion wrapper matrix.');
    rootMatrix.identity();
    // Compose the actual local chain, including rotated/nonuniformly scaled
    // parents. This is the motion wrapper's parent frame, without depending on
    // application world transforms or an invertible world matrix.
    for (let node = rootNode; node; node = node.parent) {
      if (node.matrixAutoUpdate) node.updateMatrix();
      rootMatrix.premultiply(node.matrix);
      if (node === motionRoot) {
        target.setFromMatrixPosition(rootMatrix);
        if (!target.toArray().every(Number.isFinite)) throw new Error('In-place playback has a non-finite root transform.');
        return target;
      }
    }
    throw new Error('In-place playback requires the motion wrapper to contain the animation root.');
  };
  if (motionRoot && rootNode) {
    try { initialRoot = rootInMotionParent(new Vector3()); }
    catch (error) { unsupportedBasis = error; }
  }
  const requireBasis = value => {
    if (value === 'in-place' && unsupportedBasis) throw unsupportedBasis;
  };
  requireBasis(rootMotion);
  const finishedListeners = new Set();
  const onFinished = event => { if (event.action === current) finishedListeners.forEach(listener => listener(event)); };
  mixer.addEventListener('finished', onFinished);
  const center = () => {
    if (!motionRoot || !initialMotion) return;
    motionRoot.position.copy(initialMotion);
    if (rootMotion === 'in-place' && initialRoot) {
      const displacement = rootInMotionParent(currentRoot).sub(initialRoot);
      motionRoot.position.x -= displacement.x;
      motionRoot.position.z -= displacement.z;
    }
    if (motionRoot.matrixAutoUpdate) motionRoot.updateMatrix();
  };
  return {
    mixer,
    get action() { return current; },
    get time() { return current?.time || 0; },
    play(name, settings = {}) {
      if (disposed) throw new Error('This animation controller has been disposed.');
      const semantic = actions[name], clipName = typeof semantic === 'string' ? semantic : semantic?.clip || semantic?.name || name;
      const clip = clips.find(item => item.name === clipName);
      if (!clip) throw new Error(`Asset animation is unavailable: ${name}`);
      requireBasis(settings.rootMotion || rootMotion);
      const metadata = (definition.clips || []).find(item => item.name === clipName);
      const repeat = settings.loop ?? metadata?.loop ?? (name !== 'jump' && clipName !== actions.jump && clipName !== 'Jump');
      const previous = current, fade = settings.fadeSeconds ?? 0;
      current = mixer.clipAction(clip).reset().setEffectiveWeight(1).setEffectiveTimeScale(settings.speed ?? 1);
      current.setLoop(repeat ? LoopRepeat : LoopOnce, repeat ? Infinity : 1);
      current.clampWhenFinished = !repeat;
      if (previous && previous !== current) {
        if (fade > 0) { previous.fadeOut(fade); current.fadeIn(fade); }
        else previous.stop();
      }
      if (settings.rootMotion) rootMotion = settings.rootMotion;
      current.play(); mixer.update(0); center();
      return current;
    },
    update(delta, { active = true, paused = false, reducedMotion = false, maxDelta = .05 } = {}) {
      if (disposed) return;
      if (active && !paused && !reducedMotion) mixer.update(Math.min(Math.max(Number.isFinite(delta) ? delta : 0, 0), maxDelta));
      center();
    },
    seek(seconds) {
      if (disposed || !current) return;
      current.reset().play(); mixer.setTime(Math.max(0, seconds)); center();
    },
    setRootMotion(value) { requireBasis(value); rootMotion = value; center(); },
    onFinished(listener) { finishedListeners.add(listener); return () => finishedListeners.delete(listener); },
    stop() { mixer.stopAllAction(); current = null; center(); },
    dispose() {
      if (disposed) return;
      disposed = true; mixer.removeEventListener('finished', onFinished); finishedListeners.clear();
      mixer.stopAllAction(); mixer.uncacheRoot(model); current = null;
      if (motionRoot && initialMotion) motionRoot.position.copy(initialMotion);
    },
  };
}
