import { clone } from 'three/addons/utils/SkeletonUtils.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';

export function applyEmission(model, emission) {
  const changed = [], materials = [];
  if (emission?.enabled) model.traverse(node => {
    if (!node.isMesh) return;
    let replaced = false;
    const copy = material => {
      const item = emission.maps.find(item => item.material_names.includes(material.name)), texture = item && emission.textures[item.id];
      if (!item || !texture) return material;
      const next = material.clone(); next.emissiveMap = texture; next.emissive.fromArray(item.emissive_factor); next.emissiveIntensity = 1; materials.push(next); replaced = true; return next;
    };
    const original = node.material, result = Array.isArray(original) ? original.map(copy) : copy(original);
    if (replaced) { changed.push([node, original]); node.material = result; }
  });
  return { dispose() { changed.forEach(([node, material]) => { node.material = material; }); materials.forEach(material => material.dispose()); } };
}

export function attachAppearance(model, appearance, { wireframe = false, shadows = false } = {}) {
  if (!appearance?.catalog?.family_id || appearance.catalog.requires_base_conversion) return { dispose() {} };
  const attached = [], hidden = new Map(), materials = [], skeletons = new Set();
  const restore = () => { attached.forEach(node => node.removeFromParent()); hidden.forEach((visible, node) => { node.visible = visible; }); materials.forEach(material => material.dispose()); skeletons.forEach(skeleton => skeleton.dispose()); };
  try {
    const { catalog, modules, effective } = appearance;
    for (const category of ['head', 'face', 'hair']) {
      // Keep the original visible while its replacement is still loading.
      if (!modules.some(entry => entry.item.category === category) && !(category === 'hair' && effective.hair_style === 'none')) continue;
      for (const name of catalog.replacement_nodes[category] || []) {
        const node = model.getObjectByName(name); if (node) { hidden.set(node, node.visible); node.visible = false; }
      }
    }
    for (const { item, asset } of modules) {
      const socket = model.getObjectByName(item.attachment_node);
      if (!socket) throw new Error(`${item.label || item.id}: no validated ${item.attachment_node} attachment.`);
      const module = clone(asset.gltf.scene); module.name = `Appearance_${item.id}`; module.userData.assetLabAppearance = { id: item.id, category: item.category };
      module.traverse(node => { if (!node.isMesh) return; if (node.skeleton) skeletons.add(node.skeleton); node.castShadow = shadows; node.receiveShadow = shadows;
        const copy = source => { const material = source.clone(); material.wireframe = wireframe; materials.push(material); return material; };
        node.material = Array.isArray(node.material) ? node.material.map(copy) : copy(node.material);
      });
      socket.add(module); attached.push(module);
    }
  } catch (error) { restore(); throw error; }
  return { dispose: restore };
}

// Both preview and export use the same explicit socket contract. The source
// accessory GLBs have the avatar's assembled coordinates, while socket channels
// contain the rig's delta from its bind pose; no viewer normalization belongs here.
export function attachEquipment(model, equipment = [], { wireframe = false, shadows = false } = {}) {
  const attached = [], hidden = new Map(), materials = [], skeletons = new Set();
  try {
    for (const { item, asset } of equipment) {
      const socket = model.getObjectByName(item.attachment_node);
      if (!socket) throw new Error(`${item.label}: this avatar has no ${item.attachment_node} socket.`);
      const accessory = clone(asset.gltf.scene);
      accessory.name = `Equipment_${item.id}`;
      accessory.userData.assetLabAccessory = { id: item.id, slot: item.slot, attachment_node: item.attachment_node };
      accessory.traverse(node => {
        if (!node.isMesh) return;
        node.castShadow = shadows; node.receiveShadow = shadows;
        if (node.skeleton) skeletons.add(node.skeleton);
        const copy = source => { const result = source.clone(); result.wireframe = wireframe; materials.push(result); return result; };
        node.material = Array.isArray(node.material) ? node.material.map(copy) : copy(node.material);
      });
      socket.add(accessory); attached.push(accessory);
      for (const name of item.hide_nodes || []) {
        const node = model.getObjectByName(name);
        if (!node) throw new Error(`${item.label}: replacement node ${name} is missing.`);
        if (!hidden.has(node)) hidden.set(node, node.visible);
        node.visible = false;
      }
    }
  } catch (error) {
    attached.forEach(node => node.removeFromParent()); hidden.forEach((visible, node) => { node.visible = visible; });
    materials.forEach(item => item.dispose()); skeletons.forEach(item => item.dispose());
    throw error;
  }
  return { attached, dispose() {
    attached.forEach(node => node.removeFromParent()); hidden.forEach((visible, node) => { node.visible = visible; });
    materials.forEach(item => item.dispose()); skeletons.forEach(item => item.dispose());
  } };
}

export async function exportEquippedGlb(asset, equipment, metadata, appearance) {
  // The loader's original scene has never been animated or normalized by the lab.
  const raw = clone(asset.gltf.scene), skeletons = new Set();
  raw.traverse(node => { if (node.skeleton) skeletons.add(node.skeleton); });
  let customization, attachments, emission;
  raw.userData.assetLabEquipment = metadata;
  try {
    customization = attachAppearance(raw, appearance);
    attachments = attachEquipment(raw, equipment);
    emission = applyEmission(raw, appearance?.emission);
    raw.updateMatrixWorld(true);
    const result = await new GLTFExporter().parseAsync(raw, { binary: true, onlyVisible: true, animations: asset.gltf.animations });
    if (!(result instanceof ArrayBuffer)) throw new Error('The equipped model did not export as a binary GLB.');
    return result;
  } finally {
    emission?.dispose(); attachments?.dispose(); customization?.dispose(); skeletons.forEach(item => item.dispose());
  }
}
