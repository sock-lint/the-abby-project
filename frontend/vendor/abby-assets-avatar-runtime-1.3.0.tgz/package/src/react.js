import React, { useEffect, useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { loadAvatar } from './loader.js';

/** Loads one owned instance. An old instance remains alive until its primitive
 * unmounts; cancellations dispose late results as well as the current result. */
export function useAvatar(release, configuration, options = {}) {
  const [state, setState] = useState({ avatar: null, loading: Boolean(release), error: null });
  const key = JSON.stringify(configuration || null);
  useEffect(() => {
    const controller = new AbortController(); let current, cancelled = false;
    const cancel = () => controller.abort(options.signal?.reason);
    options.signal?.addEventListener('abort', cancel, { once: true });
    if (options.signal?.aborted) cancel();
    setState({ avatar: null, loading: Boolean(release), error: null });
    if (release) loadAvatar(release, configuration, { ...options, signal: controller.signal }).then(avatar => {
      current = avatar;
      if (cancelled) avatar.dispose(); else setState({ avatar, loading: false, error: null });
    }).catch(error => { if (!cancelled) setState({ avatar: null, loading: false, error }); });
    return () => {
      cancelled = true; controller.abort(); options.signal?.removeEventListener('abort', cancel);
      // React removes the previous primitive before the next paint.
      queueMicrotask(() => current?.dispose());
    };
  }, [release, key, options.baseUrl, options.resolveUrl, options.fetch, options.signal, options.shadows, options.wireframe]);
  return state;
}

function LoadedModel({ avatar, action = 'idle', animation, active = true, paused = false, reducedMotion = false, rootMotion = 'in-place', loop, speed = 1, fadeSeconds = .12, onFinished, onError, ...props }) {
  const [controller, setController] = useState(null), callbacks = useRef({ onError, onFinished });
  callbacks.current = { onError, onFinished };
  useEffect(() => {
    if (!avatar) return;
    const next = avatar.createAnimationController(); setController(next);
    const unlisten = next.onFinished(event => callbacks.current.onFinished?.(event));
    return () => { unlisten(); next.dispose(); };
  }, [avatar]);
  useEffect(() => {
    if (!controller) return;
    try { controller.play(animation || action, { loop, rootMotion, speed, fadeSeconds }); }
    catch (error) { callbacks.current.onError?.(error); }
  }, [controller, action, animation, loop, rootMotion, speed, fadeSeconds]);
  useFrame((_, delta) => controller?.update(delta, { active, paused, reducedMotion }));
  return avatar ? React.createElement('primitive', { ...props, object: avatar.scene, dispose: null }) : null;
}

/** Use inside the application's Canvas. Supply avatar to retain ownership, or
 * release/configuration/baseUrl to let this component own load and disposal. */
export function AvatarModel({ avatar: supplied, release, configuration, baseUrl, resolveUrl, fetch: fetcher, signal, shadows = false, onLoaded, onError, ...props }) {
  const state = useAvatar(supplied ? null : release, configuration, { baseUrl, resolveUrl, fetch: fetcher, signal, shadows });
  const avatar = supplied || state.avatar, callbacks = useRef({ onLoaded, onError });
  callbacks.current = { onLoaded, onError };
  useEffect(() => { if (avatar) callbacks.current.onLoaded?.(avatar); }, [avatar]);
  useEffect(() => { if (state.error) callbacks.current.onError?.(state.error); }, [state.error]);
  return React.createElement(LoadedModel, { ...props, avatar, onError });
}
