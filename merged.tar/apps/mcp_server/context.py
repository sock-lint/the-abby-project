"""Request-scoped user context for MCP tool calls.

Each incoming request (HTTP or stdio) sets the current user in a
`contextvars.ContextVar` via `auth.TokenAuthMiddleware`. Tool handlers read
from it via `get_current_user()` and gate parent-only operations through
`require_parent()`. Using contextvars (rather than thread-locals) keeps this
correct under asyncio, which Starlette / Streamable HTTP use.
"""
from __future__ import annotations

import contextlib
import contextvars
from typing import TYPE_CHECKING, Any, Iterator, Optional

from .errors import MCPNotFoundError, MCPPermissionDenied

if TYPE_CHECKING:
    from apps.accounts.models import User
    from django.db.models import Model


_CURRENT_USER: contextvars.ContextVar[Optional["User"]] = contextvars.ContextVar(
    "mcp_current_user", default=None,
)


_CURRENT_SCOPES: contextvars.ContextVar[frozenset[str]] = contextvars.ContextVar(
    "mcp_current_scopes", default=frozenset(),
)


def set_current_scopes(scopes: frozenset[str]) -> contextvars.Token:
    return _CURRENT_SCOPES.set(scopes)


def reset_current_scopes(token: contextvars.Token) -> None:
    _CURRENT_SCOPES.reset(token)


def get_current_scopes() -> frozenset[str]:
    return _CURRENT_SCOPES.get()


def require_scope(scope: str) -> None:
    get_current_user()
    if scope not in get_current_scopes():
        raise MCPPermissionDenied(f"This connection requires the {scope} permission. Reconnect to authorize it.")


def set_current_user(user: Optional["User"]) -> contextvars.Token:
    """Set the user for the current context. Returns a token for reset()."""
    return _CURRENT_USER.set(user)


def reset_current_user(token: contextvars.Token) -> None:
    _CURRENT_USER.reset(token)


def get_current_user() -> "User":
    """Return the authenticated user, or raise MCPPermissionDenied."""
    user = _CURRENT_USER.get()
    if user is None:
        raise MCPPermissionDenied("No authenticated user in context.")
    return user


def require_parent() -> "User":
    """Return the current user if they are a parent, else raise."""
    user = get_current_user()
    if getattr(user, "role", None) != "parent":
        raise MCPPermissionDenied("This tool is restricted to parent accounts.")
    return user


def require_staff_parent() -> "User":
    """Return the current user if they are a STAFF parent, else raise.

    Use this on MCP tools that mirror REST endpoints gated by
    ``IsStaffParent`` — global content authoring (Skills, Badges, Lorebook,
    sprite catalog, etc.). A self-signup parent has ``is_staff=False`` and
    must NOT be able to mutate content visible to every other family.
    Founding superusers (``createsuperuser``) get ``is_staff=True``
    automatically; the seed-data parent does too.
    """
    user = require_parent()
    if not getattr(user, "is_staff", False):
        raise MCPPermissionDenied(
            "This tool is restricted to staff parents (global content authoring).",
        )
    return user


def is_parent() -> bool:
    user = _CURRENT_USER.get()
    return user is not None and getattr(user, "role", None) == "parent"


def resolve_target_user(user: "User", requested_id: int | None) -> "User":
    """Return the target user, enforcing child → self + same-family scoping.

    If ``requested_id`` is ``None`` or matches the caller, return the caller.
    Otherwise the caller must be a parent and the requested user must (a)
    exist and (b) belong to the same family. A cross-family request raises
    ``MCPNotFoundError`` (NOT permission-denied — don't leak existence).
    """
    from apps.accounts.models import User as UserModel
    if requested_id is None or requested_id == user.id:
        return user
    if getattr(user, "role", None) != "parent":
        raise MCPPermissionDenied("Children can only view their own data.")
    try:
        target = UserModel.objects.get(pk=requested_id)
    except UserModel.DoesNotExist:
        raise MCPNotFoundError(f"User {requested_id} not found.")
    if target.family_id != getattr(user, "family_id", None):
        raise MCPNotFoundError(f"User {requested_id} not found.")
    return target


def resolve_child_in_family(parent: "User", child_id: int) -> "User":
    """Resolve a child by id, enforcing parent + same-family scope.

    Companion to ``resolve_target_user`` for the parent-targets-child write
    path (``record_payout``, ``adjust_coins``, ``adjust_payment``,
    ``create_habit`` on-behalf, ``export_portfolio``). The semantics differ
    from ``resolve_target_user``:

      * The caller MUST be a parent (no self-resolve).
      * The target MUST be a child (filters ``role="child"`` on the lookup).
      * Cross-family / non-existent / wrong-role ids all raise
        ``MCPNotFoundError`` — never permission-denied — so probing tools
        can't distinguish "doesn't exist" from "exists in another family"
        from "exists but is a parent".

    Use this anywhere an MCP tool currently does
    ``User.objects.get(pk=params.user_id)`` for a parent-on-behalf write.
    """
    from apps.accounts.models import User as UserModel
    if getattr(parent, "role", None) != "parent":
        raise MCPPermissionDenied("This tool is restricted to parent accounts.")
    family_id = getattr(parent, "family_id", None)
    if family_id is None:
        # Defense in depth — every parent should have a family by now, but
        # if one slips through (legacy data, broken migration), fail closed.
        raise MCPNotFoundError(f"User {child_id} not found.")
    try:
        target = UserModel.objects.get(
            pk=child_id, role="child", family_id=family_id,
        )
    except UserModel.DoesNotExist:
        raise MCPNotFoundError(f"User {child_id} not found.")
    return target


def get_in_family(
    model: type["Model"],
    pk: Any,
    *,
    actor: "User",
    family_path: str = "user__family",
) -> Any:
    """Fetch a single row by primary key, scoped to ``actor``'s family.

    The default ``family_path="user__family"`` works for any model with a
    direct ``user`` FK to a family-bearing User row (Habit, SavingsGoal,
    Creation, ChronicleEntry, RewardRedemption, HomeworkSubmission, Quest's
    ``QuestParticipant``-anchored lookups). Override for other shapes:

      * ``"assigned_to__family"`` — Project, HomeworkAssignment
      * ``"family"`` — Reward, ProjectTemplate, Chore (per-family content)
      * ``"submission__user__family"`` — HomeworkProof
      * ``"created_by__family"`` — parent-authored QuestDefinition
        (system-content rows are caller-handled — they're family-agnostic)

    Cross-family / nonexistent / family-less actor all raise
    ``MCPNotFoundError`` — never permission-denied — so probing tools can't
    distinguish "doesn't exist" from "exists in another family". This is the
    same existence-leak doctrine used by ``resolve_target_user`` and
    ``resolve_child_in_family``.

    Audit C8: the bare ``Model.objects.get(pk=...)`` pattern was repeated
    across 25+ MCP tool files after a ``require_parent()`` check, with no
    family scoping — letting any parent enumerate, edit, approve, or delete
    any other family's data via the MCP channel. This helper is the single
    chokepoint that closes the pattern.
    """
    if getattr(actor, "family_id", None) is None:
        raise MCPNotFoundError(f"{model.__name__} {pk} not found.")
    try:
        return model.objects.get(**{"pk": pk, family_path: actor.family})
    except model.DoesNotExist:
        raise MCPNotFoundError(f"{model.__name__} {pk} not found.")


@contextlib.contextmanager
def override_user(
    user: Optional["User"], *, scopes: frozenset[str] | None = None,
) -> Iterator[None]:
    """Explicit local test/stdio identity override; never used by HTTP authentication.

    Local callers may exercise all scopes by default. HTTP middleware always sets
    only the token's exact validated scopes and cannot enter this override.
    """
    from .tool_policy import MCP_SCOPES
    token = set_current_user(user)
    scope_token = set_current_scopes(MCP_SCOPES if scopes is None else scopes)
    try:
        yield
    finally:
        reset_current_scopes(scope_token)
        reset_current_user(token)
