from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from config.viewsets import StaffParentWritePermissionMixin, WriteReadSerializerMixin
from apps.rpg.catalog_icons import category_catalog_icon

from .models import Badge, Skill, SkillCategory, SkillProgress, Subject, UserBadge
from .serializers import (
    BadgeSerializer, BadgeWriteSerializer, SkillCategorySerializer,
    SkillProgressSerializer, SkillSerializer, SkillWriteSerializer,
    SubjectSerializer, SubjectWriteSerializer, UserBadgeSerializer,
)
from .services import SkillService


# All four ViewSets author GLOBAL content shared across every family in a
# deployment. Gate writes on IsStaffParent so a signup-created parent in one
# family can't rename/delete a Skill or Badge that other families' children
# are progressing toward. Reads stay open to any authenticated user.
class SkillCategoryViewSet(StaffParentWritePermissionMixin, viewsets.ModelViewSet):
    queryset = SkillCategory.objects.all()
    serializer_class = SkillCategorySerializer


class BadgeViewSet(WriteReadSerializerMixin, StaffParentWritePermissionMixin, viewsets.ModelViewSet):
    queryset = Badge.objects.all()
    serializer_class = BadgeSerializer
    write_serializer_class = BadgeWriteSerializer

    def get_queryset(self):
        user = self.request.user
        if getattr(user, "is_staff", False) and getattr(user, "role", None) == "parent":
            return super().get_queryset()
        from .availability import availability_for_request, visible_badges
        return visible_badges(super().get_queryset(), user, availability=availability_for_request(self.request))


class UserBadgeViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = UserBadgeSerializer

    def get_queryset(self):
        return UserBadge.objects.filter(
            user=self.request.user
        ).select_related("badge")


class SubjectViewSet(WriteReadSerializerMixin, StaffParentWritePermissionMixin, viewsets.ModelViewSet):
    queryset = Subject.objects.select_related("category").all()
    serializer_class = SubjectSerializer
    write_serializer_class = SubjectWriteSerializer


class SkillViewSet(WriteReadSerializerMixin, StaffParentWritePermissionMixin, viewsets.ModelViewSet):
    queryset = Skill.objects.select_related("category", "subject").all()
    serializer_class = SkillSerializer
    write_serializer_class = SkillWriteSerializer


class SkillProgressViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = SkillProgressSerializer

    def get_queryset(self):
        return SkillProgress.objects.filter(
            user=self.request.user
        ).select_related("skill", "skill__category", "skill__subject")


class SkillTreeView(APIView):
    def get(self, request, category_id):
        try:
            category = SkillCategory.objects.get(id=category_id)
        except SkillCategory.DoesNotExist:
            return Response({"error": "Category not found"}, status=404)

        subjects = SkillService.get_skill_tree(request.user, category)
        summary = SkillService.get_category_summary(request.user, category)

        return Response({
            "category": {
                "id": category.id,
                "name": category.name,
                "icon": category.icon,
                "catalog_icon": category_catalog_icon(category),
                "color": category.color,
            },
            "summary": summary,
            "subjects": subjects,
        })


class AchievementsSummaryView(APIView):
    def get(self, request):
        user = request.user
        badges = UserBadge.objects.filter(user=user).select_related("badge")
        progress = SkillProgress.objects.filter(
            user=user
        ).select_related("skill", "skill__category", "skill__subject")

        categories = {}
        for sp in progress:
            cat_name = sp.skill.category.name
            if cat_name not in categories:
                categories[cat_name] = {
                    "category_id": sp.skill.category_id,
                    "icon": sp.skill.category.icon,
                    "catalog_icon": category_catalog_icon(sp.skill.category),
                    "color": sp.skill.category.color,
                    "skills": [],
                }
            categories[cat_name]["skills"].append(
                SkillProgressSerializer(sp).data
            )

        return Response({
            "badges_earned": UserBadgeSerializer(badges, many=True, context={"request": request}).data,
            "total_badges": self._total_badges(request),
            "skill_categories": categories,
        })

    @staticmethod
    def _total_badges(request):
        from .availability import availability_for_request, visible_badges
        return visible_badges(Badge.objects.all(), request.user, availability=availability_for_request(request)).count()
