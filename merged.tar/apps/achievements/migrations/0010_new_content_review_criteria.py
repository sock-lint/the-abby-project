# Generated for the 2026-04-23 content review — adds 8 new criterion
# types to Badge.CriteriaType, plus ``cosmetic_full_set`` which was
# added in code but missed the 0009 migration.

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('achievements', '0009_alter_badge_criteria_type'),
    ]

    operations = [
        migrations.AlterField(
            model_name='badge',
            name='criteria_type',
            field=models.CharField(
                choices=[
                    ('projects_completed', 'Projects Completed'),
                    ('hours_worked', 'Hours Worked'),
                    ('category_projects', 'Category Projects'),
                    ('streak_days', 'Streak Days'),
                    ('first_project', 'First Project'),
                    ('first_clock_in', 'First Clock In'),
                    ('materials_under_budget', 'Materials Under Budget'),
                    ('perfect_timecard', 'Perfect Timecard'),
                    ('skill_level_reached', 'Skill Level Reached'),
                    ('skills_unlocked', 'Skills Unlocked'),
                    ('skill_categories_breadth', 'Skill Categories Breadth'),
                    ('subjects_completed', 'Subjects Completed'),
                    ('hours_in_day', 'Hours in a Day'),
                    ('photos_uploaded', 'Photos Uploaded'),
                    ('total_earned', 'Total Earned'),
                    ('total_coins_earned', 'Total Coins Earned'),
                    ('days_worked', 'Days Worked'),
                    ('cross_category_unlock', 'Cross-Category Unlock'),
                    ('quest_completed', 'Quest Completed'),
                    ('homework_planned_ahead', 'Homework Planned Ahead'),
                    ('homework_on_time_count', 'Homework On Time Count'),
                    ('pets_hatched', 'Pets Hatched'),
                    ('pet_species_owned', 'Pet Species Owned'),
                    ('mounts_evolved', 'Mounts Evolved'),
                    ('chore_completions', 'Chore Completions Approved'),
                    ('milestones_completed', 'Milestones Completed'),
                    ('perfect_days_count', 'Perfect Days (lifetime)'),
                    ('savings_goal_completed', 'Savings Goal Completed'),
                    ('bounty_completed', 'Bounty Project Completed'),
                    ('reward_redeemed', 'Rewards Redeemed'),
                    ('habit_max_strength', 'Habit Max Strength'),
                    ('streak_freeze_used', 'Streak Freeze Used'),
                    ('early_bird', 'Clock In Before 8 AM'),
                    ('late_night', 'Clock In After 9 PM'),
                    ('fast_project', 'Project Completed Quickly'),
                    ('category_mastery', 'Category Mastery'),
                    ('full_potion_shelf', 'Full Potion Shelf'),
                    ('consumable_variety', 'Consumable Variety'),
                    ('coins_spent_lifetime', 'Coins Spent (lifetime)'),
                    ('grade_reached', 'Grade Reached'),
                    ('birthdays_logged', 'Birthdays Logged'),
                    ('cosmetic_full_set', 'All Cosmetic Slots Equipped'),
                    # Added 2026-04-23 content review
                    ('habit_taps_lifetime', 'Habit Taps (lifetime)'),
                    ('habit_count_at_strength', 'Habit Count at Strength'),
                    ('badges_earned_count', 'Badges Earned (count)'),
                    ('co_op_project_completed', 'Co-op Project Completed'),
                    ('boss_quests_completed', 'Boss Quests Completed'),
                    ('collection_quests_completed', 'Collection Quests Completed'),
                    ('chronicle_milestones_logged', 'Chronicle Milestones Logged'),
                    ('cosmetic_set_owned', 'Cosmetic Set Owned'),
                ],
                max_length=30,
            ),
        ),
    ]
