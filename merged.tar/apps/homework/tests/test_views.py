"""Tests for HomeworkAssignmentViewSet, HomeworkSubmissionViewSet, HomeworkDashboardView."""
from datetime import timedelta
from io import BytesIO
from unittest.mock import patch

from django.test import TestCase
from django.utils import timezone
from PIL import Image
from rest_framework.test import APIClient

from apps.homework.models import HomeworkAssignment, HomeworkProof, HomeworkSubmission
from apps.projects.models import User
from config.tests.base import BaseFamilyAPITestCase


def _fake_image():
    buf = BytesIO()
    Image.new("RGB", (10, 10), "red").save(buf, format="PNG")
    buf.seek(0)
    buf.name = "proof.png"
    return buf


class _Fixture(TestCase):
    def setUp(self):
        self.parent = User.objects.create_user(username="p", password="pw", role="parent")
        self.child = User.objects.create_user(username="c", password="pw", role="child")
        self.client = APIClient()


class HomeworkAssignmentCreateTests(_Fixture):
    @patch("apps.rpg.services.GameLoopService.on_task_completed")
    def test_parent_creates_assignment(self, _gl):
        self.client.force_authenticate(self.parent)
        resp = self.client.post("/api/homework/", {
            "title": "Math ch5",
            "subject": "math",
            "due_date": (timezone.localdate() + timedelta(days=3)).isoformat(),
            "assigned_to": self.child.id,
            "effort_level": 3,
        }, format="json")
        self.assertEqual(resp.status_code, 201)
        self.assertIn("application/json", resp["Content-Type"])
        self.assertEqual(resp.data["title"], "Math ch5")
        self.assertIn("id", resp.data)
        self.assertTrue(HomeworkAssignment.objects.filter(title="Math ch5").exists())
        # Response must NOT include the dead currency fields.
        self.assertNotIn("reward_amount", resp.data)
        self.assertNotIn("coin_reward", resp.data)
        self.assertNotIn("rewards_pending_review", resp.data)

    @patch("apps.rpg.services.GameLoopService.on_task_completed")
    def test_parent_create_without_assigned_to_returns_400(self, _gl):
        # The serializer marks ``assigned_to`` optional so children can omit
        # it (auto-assigned to self in the viewset). For parents, the viewset
        # requires it explicitly — without this guard the service would hit a
        # NOT NULL FK and 500.
        self.client.force_authenticate(self.parent)
        resp = self.client.post("/api/homework/", {
            "title": "test thing",
            "description": "longer test",
            "subject": "math",
            "due_date": (timezone.localdate() + timedelta(days=9)).isoformat(),
            "effort_level": 3,
        }, format="json")
        self.assertEqual(resp.status_code, 400)
        self.assertIn("assigned_to", resp.data)

    @patch("apps.rpg.services.GameLoopService.on_task_completed")
    def test_child_creates_auto_assigns_self(self, _gl):
        self.client.force_authenticate(self.child)
        resp = self.client.post("/api/homework/", {
            "title": "My reading",
            "description": "Read chapter 3",
            "subject": "reading",
            "due_date": (timezone.localdate() + timedelta(days=2)).isoformat(),
            "effort_level": 2,
        }, format="json")
        self.assertEqual(resp.status_code, 201)
        self.assertIn("application/json", resp["Content-Type"])
        self.assertEqual(resp.data["title"], "My reading")
        hw = HomeworkAssignment.objects.get(title="My reading")
        self.assertEqual(hw.assigned_to, self.child)

    @patch("apps.rpg.services.GameLoopService.on_task_completed")
    def test_child_cannot_delete(self, _gl):
        hw = HomeworkAssignment.objects.create(
            title="HW", subject="math",
            due_date=timezone.localdate() + timedelta(days=3),
            assigned_to=self.child, created_by=self.parent,
        )
        self.client.force_authenticate(self.child)
        resp = self.client.delete(f"/api/homework/{hw.pk}/")
        self.assertEqual(resp.status_code, 403)


class HomeworkAssignmentListTests(_Fixture):
    def test_child_sees_own_assignments(self):
        child2 = User.objects.create_user(username="c2", password="pw", role="child")
        HomeworkAssignment.objects.create(
            title="Mine", subject="math",
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )
        HomeworkAssignment.objects.create(
            title="Theirs", subject="math",
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=child2, created_by=self.parent,
        )
        self.client.force_authenticate(self.child)
        resp = self.client.get("/api/homework/")
        self.assertEqual(resp.status_code, 200)
        titles = [r["title"] for r in resp.json()["results"]]
        self.assertIn("Mine", titles)
        self.assertNotIn("Theirs", titles)


class HomeworkAssignmentUpdateTests(_Fixture):
    def test_parent_edits_due_date_without_serializing_the_skill_tag_manager(self):
        from apps.achievements.models import Skill, SkillCategory
        from apps.homework.models import HomeworkSkillTag

        assignment = HomeworkAssignment.objects.create(
            title="Reading log", subject="reading",
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )
        category = SkillCategory.objects.create(name="Learning")
        skill = Skill.objects.create(name="Reading", category=category)
        HomeworkSkillTag.objects.create(assignment=assignment, skill=skill, xp_amount=10)
        due_date = (timezone.localdate() + timedelta(days=3)).isoformat()
        self.client.force_authenticate(self.parent)

        response = self.client.patch(
            f"/api/homework/{assignment.pk}/", {"due_date": due_date}, format="json",
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["due_date"], due_date)
        assignment.refresh_from_db()
        self.assertEqual(assignment.due_date.isoformat(), due_date)
        self.assertEqual(assignment.skill_tags.get().skill_id, skill.pk)
        saved = self.client.get(f"/api/homework/{assignment.pk}/")
        self.assertEqual(saved.status_code, 200)
        self.assertEqual(saved.json()["skill_tags"][0]["skill"], skill.pk)


class HomeworkSubmitTests(_Fixture):
    def setUp(self):
        super().setUp()
        self.hw = HomeworkAssignment.objects.create(
            title="HW1", subject="math",
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )

    @patch("apps.rpg.services.GameLoopService.on_task_completed")
    def test_child_submits_with_proof(self, mock_gl):
        self.client.force_authenticate(self.child)
        resp = self.client.post(
            f"/api/homework/{self.hw.pk}/submit/",
            {"images": _fake_image(), "notes": "Done"},
            format="multipart",
        )
        self.assertEqual(resp.status_code, 201)
        self.assertTrue(
            HomeworkSubmission.objects.filter(assignment=self.hw, user=self.child).exists()
        )

    def test_submit_without_images_fails(self):
        self.client.force_authenticate(self.child)
        resp = self.client.post(
            f"/api/homework/{self.hw.pk}/submit/",
            {"notes": "No proof"},
            format="multipart",
        )
        self.assertEqual(resp.status_code, 400)


class HomeworkSubmissionViewSetTests(_Fixture):
    def test_child_sees_own_submissions(self):
        hw = HomeworkAssignment.objects.create(
            title="HW", subject="math",
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )
        HomeworkSubmission.objects.create(
            assignment=hw, user=self.child, status="pending",
            timeliness="on_time",
        )
        self.client.force_authenticate(self.child)
        resp = self.client.get("/api/homework-submissions/")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(resp.json()["results"]), 1)


class HomeworkSubmissionWithdrawTests(_Fixture):
    def setUp(self):
        super().setUp()
        self.hw = HomeworkAssignment.objects.create(
            title="Essay", subject="writing", effort_level=3,
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )
        self.submission = HomeworkSubmission.objects.create(
            assignment=self.hw, user=self.child, status="pending",
            timeliness="on_time",
        )
        self.proof = HomeworkProof.objects.create(
            submission=self.submission, caption="page 1",
        )

    def test_owner_can_withdraw_pending(self):
        self.client.force_authenticate(self.child)
        resp = self.client.post(f"/api/homework-submissions/{self.submission.id}/withdraw/")
        self.assertEqual(resp.status_code, 204)
        self.assertFalse(HomeworkSubmission.objects.filter(id=self.submission.id).exists())
        # Cascading proofs go with it.
        self.assertFalse(HomeworkProof.objects.filter(id=self.proof.id).exists())
        # Assignment itself stays — only the submission was undone.
        self.assertTrue(HomeworkAssignment.objects.filter(id=self.hw.id).exists())

    def test_parent_cannot_withdraw_others_submission(self):
        self.client.force_authenticate(self.parent)
        resp = self.client.post(f"/api/homework-submissions/{self.submission.id}/withdraw/")
        self.assertEqual(resp.status_code, 403)

    def test_cannot_withdraw_after_approval(self):
        self.submission.status = "approved"
        self.submission.save()
        self.client.force_authenticate(self.child)
        resp = self.client.post(f"/api/homework-submissions/{self.submission.id}/withdraw/")
        self.assertEqual(resp.status_code, 400)



class HomeworkProofDeleteTests(_Fixture):
    def setUp(self):
        super().setUp()
        self.other_child = User.objects.create_user(
            username="c2", password="pw", role="child",
        )
        self.assignment = HomeworkAssignment.objects.create(
            title="Essay", subject="writing", effort_level=3,
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )
        self.submission = HomeworkSubmission.objects.create(
            assignment=self.assignment, user=self.child, status="approved",
            timeliness="on_time",
        )
        self.proof = HomeworkProof.objects.create(
            submission=self.submission, caption="my page",
        )

    def test_owner_can_delete_own_proof(self):
        self.client.force_authenticate(self.child)
        resp = self.client.delete(f"/api/homework-proofs/{self.proof.pk}/")
        self.assertEqual(resp.status_code, 204)
        self.assertFalse(HomeworkProof.objects.filter(pk=self.proof.pk).exists())
        # Submission itself stays — audit trail intact.
        self.assertTrue(HomeworkSubmission.objects.filter(pk=self.submission.pk).exists())

    def test_parent_can_delete_any_proof(self):
        self.client.force_authenticate(self.parent)
        resp = self.client.delete(f"/api/homework-proofs/{self.proof.pk}/")
        self.assertEqual(resp.status_code, 204)
        self.assertFalse(HomeworkProof.objects.filter(pk=self.proof.pk).exists())

    def test_other_child_cannot_delete(self):
        self.client.force_authenticate(self.other_child)
        resp = self.client.delete(f"/api/homework-proofs/{self.proof.pk}/")
        # Audit C2: HomeworkProofViewSet now uses RoleFilteredQuerySetMixin,
        # so a non-owning child sees 404 rather than 403 — matches the
        # "don't leak existence" doctrine used elsewhere.
        self.assertEqual(resp.status_code, 404)
        self.assertTrue(HomeworkProof.objects.filter(pk=self.proof.pk).exists())

    def test_unauthenticated_rejected(self):
        resp = self.client.delete(f"/api/homework-proofs/{self.proof.pk}/")
        self.assertEqual(resp.status_code, 401)


class HomeworkDashboardTests(_Fixture):
    def test_child_dashboard_returns_sections(self):
        self.client.force_authenticate(self.child)
        resp = self.client.get("/api/homework/dashboard/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        self.assertIn("today", data)
        self.assertIn("upcoming", data)
        self.assertIn("overdue", data)
        self.assertIn("pending", data)
        self.assertIn("stats", data)

    def test_parent_dashboard_returns_pending(self):
        self.client.force_authenticate(self.parent)
        resp = self.client.get("/api/homework/dashboard/")
        self.assertEqual(resp.status_code, 200)
        self.assertIn("pending_submissions", resp.json())


class HomeworkChildPendingDashboardTests(BaseFamilyAPITestCase):
    family_parents = [{"username": "pending-parent"}]
    family_children = [{"username": "pending-child"}, {"username": "sibling"}]

    def setUp(self):
        self.client.force_authenticate(self.children[0])

    def make_assignment(self, offset, *, child=None, submission_status="pending"):
        child = child or self.children[0]
        assignment = HomeworkAssignment.objects.create(
            title=f"Homework due {offset}", subject="math",
            due_date=timezone.localdate() + timedelta(days=offset),
            assigned_to=child, created_by=self.parents[0],
        )
        submission = HomeworkSubmission.objects.create(
            assignment=assignment, user=child,
            status=submission_status, timeliness="on_time",
        )
        return assignment, submission

    def test_pending_work_stays_visible_once_regardless_of_due_date(self):
        assignments = [self.make_assignment(offset)[0] for offset in (-1, 0, 1)]
        data = self.client.get("/api/homework/dashboard/").json()
        self.assertEqual([row["id"] for row in data["pending"]], [a.id for a in assignments])
        self.assertTrue(all(row["submission_status"]["status"] == "pending" for row in data["pending"]))
        self.assertEqual(data["today"] + data["upcoming"] + data["overdue"], [])

    def test_pending_section_excludes_another_childs_work(self):
        assignment, _ = self.make_assignment(-1)
        self.make_assignment(-1, child=self.children[1])
        data = self.client.get("/api/homework/dashboard/").json()
        self.assertEqual([row["id"] for row in data["pending"]], [assignment.id])

    def test_reassigned_work_does_not_show_the_previous_childs_submission(self):
        assignment, _ = self.make_assignment(-1)
        assignment.assigned_to = self.children[1]
        assignment.save(update_fields=["assigned_to"])
        self.client.force_authenticate(self.children[1])
        data = self.client.get("/api/homework/dashboard/").json()
        self.assertEqual(data["pending"], [])
        self.assertEqual([row["id"] for row in data["overdue"]], [assignment.id])
        self.assertIsNone(data["overdue"][0]["submission_status"])

    def test_withdrawn_overdue_work_returns_to_overdue(self):
        assignment, submission = self.make_assignment(-1)
        response = self.client.post(f"/api/homework-submissions/{submission.id}/withdraw/")
        self.assertEqual(response.status_code, 204)
        data = self.client.get("/api/homework/dashboard/").json()
        self.assertEqual(data["pending"], [])
        self.assertEqual([row["id"] for row in data["overdue"]], [assignment.id])
        self.assertIsNone(data["overdue"][0]["submission_status"])

    def test_rejected_work_is_overdue_and_approved_work_stays_in_history(self):
        rejected, _ = self.make_assignment(-1, submission_status="rejected")
        self.make_assignment(-1, submission_status="approved")
        data = self.client.get("/api/homework/dashboard/").json()
        self.assertEqual(data["pending"], [])
        self.assertEqual([row["id"] for row in data["overdue"]], [rejected.id])


class HomeworkParentDashboardFamilyScopingTests(TestCase):
    """Parent overview must NOT leak homework across families.

    Pinned because the previous implementation listed all pending submissions
    + active assignments globally — a parent in Family A would see homework
    assigned to Family B's children.
    """

    def setUp(self):
        from config.tests.factories import make_family
        self.a = make_family(
            "Family A",
            parents=[{"username": "ap"}],
            children=[{"username": "ac"}],
        )
        self.b = make_family(
            "Family B",
            parents=[{"username": "bp"}],
            children=[{"username": "bc"}],
        )
        # One assignment + pending submission in each family.
        for fam, label in ((self.a, "A"), (self.b, "B")):
            hw = HomeworkAssignment.objects.create(
                title=f"HW-{label}", subject="math",
                due_date=timezone.localdate() + timedelta(days=2),
                assigned_to=fam.children[0], created_by=fam.parents[0],
            )
            HomeworkSubmission.objects.create(
                assignment=hw, user=fam.children[0],
                status=HomeworkSubmission.Status.PENDING,
                timeliness="on_time",
            )

    def test_parent_sees_only_own_familys_assignments(self):
        client = APIClient()
        client.force_authenticate(self.a.parents[0])
        resp = client.get("/api/homework/dashboard/")
        self.assertEqual(resp.status_code, 200)
        titles = {a["title"] for a in resp.json()["assignments"]}
        self.assertEqual(titles, {"HW-A"})

    def test_parent_sees_only_own_familys_pending_submissions(self):
        client = APIClient()
        client.force_authenticate(self.a.parents[0])
        resp = client.get("/api/homework/dashboard/")
        self.assertEqual(resp.status_code, 200)
        usernames = {s["user_name"] for s in resp.json()["pending_submissions"]}
        # Only Family A's child appears.
        self.assertNotIn("bc", usernames)
        # Family A child is in there (display_name falls back to username).
        a_child = self.a.children[0]
        expected = a_child.display_name or a_child.username
        self.assertIn(expected, usernames)


class HomeworkPlanActionTests(_Fixture):
    """Long-lead self-serve gate on POST /api/homework/<id>/plan/.

    plan_assignment itself is mocked — it calls Anthropic. The tests here
    only verify the permission gate.
    """

    def _make(self, *, due_offset_days, assigned_to=None):
        return HomeworkAssignment.objects.create(
            title="Math project", subject="math", effort_level=4,
            due_date=timezone.localdate() + timedelta(days=due_offset_days),
            assigned_to=assigned_to or self.child,
            created_by=self.parent,
        )

    @patch("apps.homework.views.HomeworkService.plan_assignment")
    def test_child_can_plan_long_lead(self, mock_plan):
        mock_plan.return_value = self._make(due_offset_days=7)
        hw = self._make(due_offset_days=7)
        self.client.force_authenticate(self.child)
        resp = self.client.post(f"/api/homework/{hw.pk}/plan/")
        self.assertEqual(resp.status_code, 200)
        mock_plan.assert_called_once()

    def test_child_blocked_short_lead(self):
        hw = self._make(due_offset_days=1)
        self.client.force_authenticate(self.child)
        resp = self.client.post(f"/api/homework/{hw.pk}/plan/")
        self.assertEqual(resp.status_code, 403)
        self.assertIn("Ask a parent", resp.json()["error"])

    @patch("apps.homework.views.HomeworkService.plan_assignment")
    def test_parent_can_plan_short_lead(self, mock_plan):
        hw = self._make(due_offset_days=1)
        mock_plan.return_value = hw
        self.client.force_authenticate(self.parent)
        resp = self.client.post(f"/api/homework/{hw.pk}/plan/")
        self.assertEqual(resp.status_code, 200)
        mock_plan.assert_called_once()

    def test_unauthenticated_rejected(self):
        hw = self._make(due_offset_days=7)
        resp = self.client.post(f"/api/homework/{hw.pk}/plan/")
        self.assertEqual(resp.status_code, 401)

    def test_child_cannot_plan_other_childs_assignment(self):
        other = User.objects.create_user(
            username="other", password="pw", role="child",
        )
        hw = self._make(due_offset_days=7, assigned_to=other)
        self.client.force_authenticate(self.child)
        resp = self.client.post(f"/api/homework/{hw.pk}/plan/")
        # Filtered out by RoleFilteredQuerySetMixin → 404 (not visible).
        self.assertEqual(resp.status_code, 404)


class HomeworkAssignmentSerializerCanPlanTests(_Fixture):
    """The can_plan field surfaces the same gate to the frontend."""

    def test_can_plan_true_for_child_long_lead(self):
        HomeworkAssignment.objects.create(
            title="HW", subject="math", effort_level=3,
            due_date=timezone.localdate() + timedelta(days=7),
            assigned_to=self.child, created_by=self.parent,
        )
        self.client.force_authenticate(self.child)
        resp = self.client.get("/api/homework/")
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        rows = data["results"] if isinstance(data, dict) else data
        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["can_plan"])

    def test_can_plan_false_for_child_short_lead(self):
        HomeworkAssignment.objects.create(
            title="HW", subject="math", effort_level=3,
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )
        self.client.force_authenticate(self.child)
        resp = self.client.get("/api/homework/")
        data = resp.json()
        rows = data["results"] if isinstance(data, dict) else data
        self.assertFalse(rows[0]["can_plan"])

    def test_can_plan_true_for_parent_short_lead(self):
        HomeworkAssignment.objects.create(
            title="HW", subject="math", effort_level=3,
            due_date=timezone.localdate() + timedelta(days=1),
            assigned_to=self.child, created_by=self.parent,
        )
        self.client.force_authenticate(self.parent)
        resp = self.client.get("/api/homework/")
        data = resp.json()
        rows = data["results"] if isinstance(data, dict) else data
        self.assertTrue(rows[0]["can_plan"])
