from datetime import date
from decimal import Decimal

from django.contrib.auth.models import AbstractUser
from django.db import models, transaction
from django.utils import timezone

from config.base_models import TimestampedModel

from .managers import CustomUserManager


class PendingFileDeletion(TimestampedModel):
    """Private storage outbox, independent of the account rows being removed.

    A delete signal writes this row inside the same database transaction as
    its source deletion. Failed storage calls never discard the only remaining
    pointer. Keys are private operational data and must not be serialized or
    included in task arguments/logs.
    """

    storage_key = models.CharField(max_length=1000, unique=True)
    attempts = models.PositiveIntegerField(default=0)
    retry_at = models.DateTimeField(default=timezone.now, db_index=True)
    last_attempt_at = models.DateTimeField(null=True, blank=True)
    last_error = models.CharField(max_length=32, blank=True)

    class Meta:
        ordering = ["retry_at", "pk"]


class User(AbstractUser):
    class Role(models.TextChoices):
        PARENT = "parent", "Parent"
        CHILD = "child", "Child"

    role = models.CharField(max_length=10, choices=Role.choices, default=Role.CHILD)
    family = models.ForeignKey(
        "families.Family",
        on_delete=models.CASCADE,
        related_name="members",
        db_index=True,
        help_text="Household scope.",
    )
    hourly_rate = models.DecimalField(
        max_digits=5, decimal_places=2, default=Decimal("8.00")
    )
    display_name = models.CharField(max_length=100, blank=True)
    avatar = models.ImageField(upload_to="avatars/", blank=True, null=True)
    theme = models.CharField(
        max_length=20, default="summer",
        choices=[
            ("summer", "Summer"),
            ("winter", "Winter Break"),
            ("spring", "Spring Break"),
            ("autumn", "Autumn"),
        ],
    )
    date_of_birth = models.DateField(null=True, blank=True)
    last_seen_at = models.DateTimeField(
        null=True, blank=True,
        help_text="Stamped on each dashboard fetch — drives the since-last-visit summary.",
    )
    grade_entry_year = models.PositiveIntegerField(
        null=True, blank=True,
        help_text="Calendar year of August they entered 9th grade (e.g. 2025).",
    )
    lorebook_flags = models.JSONField(default=dict, blank=True)

    objects = CustomUserManager()

    class Meta:
        # Preserve original table name so the move is a state-only migration.
        db_table = "projects_user"

    def save(self, *args, **kwargs):
        # Defense-in-depth: any path that lands here without a family
        # (legacy tests, fixtures, ``User.objects.create(...)`` shortcuts)
        # gets stamped to the default family rather than 500'ing on the
        # NOT NULL constraint. Production paths (signup view, ChildViewSet
        # POST) always supply an explicit family.
        if self.family_id is None:
            from apps.families.models import Family
            family, _ = Family.objects.get_or_create(
                slug="default-family",
                defaults={"name": "Default Family"},
            )
            self.family_id = family.id
        sensitive = {"password", "is_active", "family_id", "role"}
        fields = kwargs.get("update_fields")
        if self.pk and (fields is None or sensitive.intersection(fields) or "family" in fields):
            # Serialize changes with exchange/revocation. A savepoint also keeps the
            # invalidation marker atomic with password and membership updates.
            using = kwargs.get("using") or self._state.db or "default"
            with transaction.atomic(using=using):
                previous = type(self).objects.using(using).select_for_update(no_key=True).filter(pk=self.pk).first()
                changed = previous and any(
                    getattr(previous, name) != getattr(self, name)
                    for name in sensitive
                    if fields is None or name in fields or (name == "family_id" and "family" in fields)
                )
                super().save(*args, **kwargs)
                if changed:
                    from apps.google_integration.oauth_exchange import invalidate_google_flows
                    invalidate_google_flows(self.pk, using=using)
        else:
            super().save(*args, **kwargs)

    @property
    def display_label(self) -> str:
        """Human-facing name: display_name when set, otherwise username.

        Single source of truth — imported by serializers (as a CharField
        source) and any code that formats user names (emails, CSV exports,
        MCP payloads).
        """
        return self.display_name or self.username

    def __str__(self):
        return self.display_label

    # ------------------------------------------------------------------
    # Age / grade / chapter derivations
    # ------------------------------------------------------------------

    @property
    def age_years(self) -> int | None:
        if not self.date_of_birth:
            return None
        today = date.today()
        years = today.year - self.date_of_birth.year
        if (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day):
            years -= 1
        return years

    def _chapter_year(self, today: date | None = None) -> int:
        """The August-starting year covering `today`. 2025 = Aug 2025–Jul 2026."""
        today = today or date.today()
        return today.year if today.month >= 8 else today.year - 1

    @property
    def current_grade(self) -> int | None:
        if self.grade_entry_year is None:
            return None
        return 9 + (self._chapter_year() - self.grade_entry_year)

    @property
    def school_year_label(self) -> str | None:
        grade = self.current_grade
        if grade is None:
            return None
        if 9 <= grade <= 12:
            return {9: "Freshman", 10: "Sophomore", 11: "Junior", 12: "Senior"}[grade]
        if grade < 9:
            return f"Grade {grade}"
        # Post-HS: "Age {n} · {yyyy}-{yy}"
        age = self.age_years
        cy = self._chapter_year()
        if age is None or cy is None:
            return None
        return f"Age {age} · {cy}-{str(cy + 1)[-2:]}"

    @property
    def days_until_adult(self) -> int | None:
        if not self.date_of_birth:
            return None
        try:
            eighteenth = self.date_of_birth.replace(year=self.date_of_birth.year + 18)
        except ValueError:
            # Feb 29 → Mar 1 on non-leap 18th year
            eighteenth = date(self.date_of_birth.year + 18, 3, 1)
        return (eighteenth - date.today()).days
