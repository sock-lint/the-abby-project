import base64
import hashlib
import hmac
import json
import logging
import os
from datetime import datetime, timedelta

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from django.conf import settings
from django.db import OperationalError, transaction
from django.db.models import Q
from django.utils import timezone

from .diagnostics import calendar_failure_diagnostics

logger = logging.getLogger(__name__)

# Google OAuth scopes
SCOPES = [
    "openid",
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/userinfo.profile",
    "https://www.googleapis.com/auth/calendar.events.owned",
]

# ``oauthlib`` rejects token responses whose ``scope`` differs from what we
# requested — Google returns scopes in a different order, which is benign
# here. Setting this once at module load time is thread-safe; the previous
# pattern (set/pop around each ``fetch_token`` call) raced under any
# threaded server (Celery workers, async views) because ``os.environ`` is
# process-global. Setting it once is fine because every OAuth flow in this
# module accepts the same relaxed-scope semantics.
os.environ.setdefault("OAUTHLIB_RELAX_TOKEN_SCOPE", "1")


def _derive_legacy_key():
    """Derive the 32-byte key the pre-Fernet ``_legacy_decrypt`` used.

    Kept solely so credentials encrypted before audit H3 landed still
    decrypt — the next refresh re-encrypts with Fernet.
    """
    return hashlib.sha256(settings.SECRET_KEY.encode()).digest()


def _fernet() -> Fernet:
    """Return a Fernet instance keyed off ``SECRET_KEY`` via HKDF.

    Audit H3: replaces a hand-rolled HMAC-keystream-XOR construction with
    a standard, reviewed AEAD. Key derivation is deterministic from
    ``SECRET_KEY`` so no extra env var is needed. Rotating ``SECRET_KEY``
    invalidates stored OAuth tokens (users will need to re-link Google)
    — same operational property as the prior scheme.

    Future rotation note: if you ever need to migrate to a separately-
    managed key, switch this to return ``MultiFernet([new, old])`` and
    keep the legacy ``_decrypt`` path until rows have rolled over.
    """
    secret = settings.SECRET_KEY.encode("utf-8")
    key_bytes = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        # Static app-context salt — we want deterministic keys, not
        # per-message rotation. The label namespaces the derived key in
        # case the same SECRET_KEY is reused for other crypto in the app.
        salt=b"abby:google_oauth:fernet:v1",
        info=b"GoogleAccount.encrypted_credentials",
    ).derive(secret)
    return Fernet(base64.urlsafe_b64encode(key_bytes))


def _encrypt(plaintext_bytes: bytes) -> bytes:
    """Encrypt with Fernet AEAD (audit H3)."""
    return _fernet().encrypt(plaintext_bytes)


def _decrypt(encrypted_bytes) -> bytes:
    """Decrypt Fernet-encrypted credentials.

    Falls back to the pre-Fernet HMAC-XOR construction for tokens minted
    before audit H3 landed. The legacy path is read-only — the next
    ``refresh_if_needed`` save() re-encrypts with Fernet so the legacy
    branch becomes dead code as production rows roll over. All decrypt
    failures collapse to a single ``ValueError`` so callers don't need
    to discriminate.
    """
    encrypted_bytes = bytes(encrypted_bytes)
    try:
        return _fernet().decrypt(encrypted_bytes)
    except InvalidToken:
        # Fall through to the legacy HMAC-XOR scheme.
        try:
            return _legacy_decrypt(encrypted_bytes)
        except (ValueError, IndexError):
            # Both schemes failed — surface a single clean ValueError.
            raise ValueError("Credential decryption failed") from None


def _legacy_decrypt(encrypted_bytes: bytes) -> bytes:
    """Pre-audit-H3 HMAC-XOR decrypt. KEEP until production rows have all
    been re-encrypted with Fernet via ``refresh_if_needed``. Format is
    ``salt(16) || ciphertext || hmac(32)``.
    """
    key = _derive_legacy_key()
    if len(encrypted_bytes) < 48:
        raise ValueError("Encrypted data too short")
    salt = encrypted_bytes[:16]
    tag = encrypted_bytes[-32:]
    ciphertext = encrypted_bytes[16:-32]
    expected_tag = hmac.new(key, salt + ciphertext, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected_tag):
        raise ValueError("Credential integrity check failed")
    stream = b""
    block = salt
    while len(stream) < len(ciphertext):
        block = hmac.new(key, block, hashlib.sha256).digest()
        stream += block
    return bytes(a ^ b for a, b in zip(ciphertext, stream))


def _legacy_encrypt(plaintext_bytes: bytes) -> bytes:
    """Pre-audit-H3 HMAC-XOR encrypt — kept for tests only.

    Production code never calls this; tests use it to generate
    legacy-format ciphertext for the backward-compat decrypt path.
    """
    key = _derive_legacy_key()
    salt = os.urandom(16)
    stream = b""
    block = salt
    while len(stream) < len(plaintext_bytes):
        block = hmac.new(key, block, hashlib.sha256).digest()
        stream += block
    ciphertext = bytes(a ^ b for a, b in zip(plaintext_bytes, stream))
    tag = hmac.new(key, salt + ciphertext, hashlib.sha256).digest()
    return salt + ciphertext + tag


def _lock_account_relations(user, *, calendar=False):
    """Do not wait on child rows already held by an account cascade."""
    from .models import CalendarEventMapping, GoogleAccount
    from .oauth_exchange import AuthorizationBusy, is_lock_conflict

    try:
        list(GoogleAccount.objects.select_for_update(nowait=True).filter(user=user))
        if calendar:
            list(CalendarEventMapping.objects.select_for_update(nowait=True).filter(user=user))
    except OperationalError as exc:
        if is_lock_conflict(exc):
            raise AuthorizationBusy() from None
        raise


class GoogleAuthService:
    """Handles OAuth2 flow and credential management."""

    @staticmethod
    def is_configured():
        """Return True if Google OAuth credentials are set."""
        return bool(settings.GOOGLE_CLIENT_ID and settings.GOOGLE_CLIENT_SECRET)

    @staticmethod
    def get_authorization_url(state=None):
        """Build the Google OAuth consent URL.

        Returns (authorization_url, state).
        """
        from google_auth_oauthlib.flow import Flow

        flow = Flow.from_client_config(
            {
                "web": {
                    "client_id": settings.GOOGLE_CLIENT_ID,
                    "client_secret": settings.GOOGLE_CLIENT_SECRET,
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token",
                }
            },
            scopes=SCOPES,
            redirect_uri=settings.GOOGLE_REDIRECT_URI,
        )
        authorization_url, state = flow.authorization_url(
            access_type="offline",
            include_granted_scopes="true",
            prompt="consent",
            state=state,
        )
        return authorization_url, state, flow.code_verifier

    @staticmethod
    def exchange_code(code, code_verifier=None):
        """Exchange authorization code for credentials.

        Returns (google_id, email, credentials_json).
        """
        import google.auth.transport.requests
        from google.oauth2 import id_token as google_id_token
        from google_auth_oauthlib.flow import Flow

        flow = Flow.from_client_config(
            {
                "web": {
                    "client_id": settings.GOOGLE_CLIENT_ID,
                    "client_secret": settings.GOOGLE_CLIENT_SECRET,
                    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                    "token_uri": "https://oauth2.googleapis.com/token",
                }
            },
            scopes=SCOPES,
            redirect_uri=settings.GOOGLE_REDIRECT_URI,
        )
        # OAUTHLIB_RELAX_TOKEN_SCOPE is set once at module load time; see
        # the comment near the top of this file.
        flow.fetch_token(code=code, code_verifier=code_verifier)
        credentials = flow.credentials

        # Verify the ID token to get user info
        request = google.auth.transport.requests.Request()
        id_info = google_id_token.verify_oauth2_token(
            credentials.id_token, request, settings.GOOGLE_CLIENT_ID
        )
        google_id = id_info["sub"]
        email = id_info.get("email", "")

        credentials_json = {
            "token": credentials.token,
            "refresh_token": credentials.refresh_token,
            "token_uri": credentials.token_uri,
            "client_id": credentials.client_id,
            "client_secret": credentials.client_secret,
            "scopes": list(credentials.scopes or []),
        }
        if credentials.expiry:
            credentials_json["expiry"] = credentials.expiry.isoformat()

        return google_id, email, credentials_json

    @staticmethod
    def encrypt_credentials(credentials_json):
        """Encrypt a credentials dict. Returns bytes."""
        return _encrypt(json.dumps(credentials_json).encode())

    @staticmethod
    def decrypt_credentials(encrypted):
        """Decrypt encrypted credentials. Returns dict."""
        return json.loads(_decrypt(bytes(encrypted)).decode())

    @classmethod
    def get_google_credentials(cls, google_account):
        """Build a google.oauth2.credentials.Credentials from a GoogleAccount."""
        from google.oauth2.credentials import Credentials

        creds_data = cls.decrypt_credentials(google_account.encrypted_credentials)
        creds = Credentials(
            token=creds_data.get("token"),
            refresh_token=creds_data.get("refresh_token"),
            token_uri=creds_data.get("token_uri", "https://oauth2.googleapis.com/token"),
            client_id=creds_data.get("client_id", settings.GOOGLE_CLIENT_ID),
            client_secret=creds_data.get("client_secret", settings.GOOGLE_CLIENT_SECRET),
            scopes=creds_data.get("scopes"),
        )
        if creds_data.get("expiry"):
            creds.expiry = datetime.fromisoformat(creds_data["expiry"])
        return creds

    @classmethod
    def refresh_if_needed(cls, google_account):
        """Refresh credentials if expired and save back."""
        import google.auth.transport.requests

        creds = cls.get_google_credentials(google_account)
        if creds.expired and creds.refresh_token:
            request = google.auth.transport.requests.Request()
            creds.refresh(request)
            # Persist refreshed token
            creds_data = cls.decrypt_credentials(google_account.encrypted_credentials)
            creds_data["token"] = creds.token
            if creds.expiry:
                creds_data["expiry"] = creds.expiry.isoformat()
            google_account.encrypted_credentials = cls.encrypt_credentials(creds_data)
            google_account.save(update_fields=["encrypted_credentials", "updated_at"])
        return creds

    @classmethod
    def link_account(cls, user, google_id, email, credentials_json, linked_by=None):
        """Create or update a GoogleAccount for the given user."""
        from .models import GoogleAccount

        from .oauth_exchange import invalidate_google_flows, lock_users

        with transaction.atomic():
            if user.pk not in lock_users([user.pk]):
                raise ValueError("Account is unavailable")
            _lock_account_relations(user)
            account, _ = GoogleAccount.objects.update_or_create(
                user=user,
                defaults={
                    "google_id": google_id,
                    "google_email": email,
                    "encrypted_credentials": cls.encrypt_credentials(credentials_json),
                    "linked_by": linked_by,
                },
            )
            invalidate_google_flows(user.pk)
        return account

    @staticmethod
    def unlink_account(user):
        """Remove the user's GoogleAccount and all calendar mappings."""
        from .models import CalendarEventMapping, GoogleAccount
        from .oauth_exchange import invalidate_google_flows, lock_users

        with transaction.atomic():
            if user.pk not in lock_users([user.pk]):
                return
            _lock_account_relations(user, calendar=True)
            CalendarEventMapping.objects.filter(user=user).delete()
            GoogleAccount.objects.filter(user=user).delete()
            invalidate_google_flows(user.pk)


class GoogleCalendarService:
    """Pushes app events to Google Calendar."""

    @classmethod
    def get_calendar_client(cls, user):
        """Build an authenticated Calendar API client for a user.

        Returns None if the user has no linked account or sync is disabled.
        """
        from .models import GoogleAccount

        try:
            account = user.google_account
        except GoogleAccount.DoesNotExist:
            return None

        if not account.calendar_sync_enabled:
            return None

        try:
            creds = GoogleAuthService.refresh_if_needed(account)
        except Exception:
            logger.exception("Failed to refresh Google credentials for user %s", user)
            return None

        from googleapiclient.discovery import build

        return build("calendar", "v3", credentials=creds, cache_discovery=False)

    @classmethod
    def _upsert_event(cls, user, content_type, object_id, event_body, calendar_id="primary"):
        """Create or update a Google Calendar event and maintain the mapping."""
        from .models import CalendarEventMapping, GoogleAccount

        service = cls.get_calendar_client(user)
        if service is None:
            return

        try:
            cal_id = user.google_account.calendar_id or "primary"
        except GoogleAccount.DoesNotExist:
            return

        mapping = CalendarEventMapping.objects.filter(
            user=user, content_type=content_type, object_id=object_id
        ).first()

        operation = "update" if mapping else "insert"
        calling_google = True
        try:
            if mapping:
                # Update existing event
                event = (
                    service.events()
                    .update(calendarId=cal_id, eventId=mapping.google_event_id, body=event_body)
                    .execute()
                )
            else:
                # Create new event
                event = (
                    service.events()
                    .insert(calendarId=cal_id, body=event_body)
                    .execute()
                )
                calling_google = False
                CalendarEventMapping.objects.create(
                    user=user,
                    content_type=content_type,
                    object_id=object_id,
                    google_event_id=event["id"],
                )
        except Exception as error:
            logger.exception(
                "Google Calendar API error for %s:%s (user %s)",
                content_type,
                object_id,
                user,
                extra={"google_calendar_failure": calendar_failure_diagnostics(
                    error if calling_google else None, operation=operation,
                )},
            )

    @classmethod
    def delete_event(cls, user, content_type, object_id):
        """Remove a Google Calendar event by mapping lookup."""
        from .models import CalendarEventMapping, GoogleAccount

        mapping = CalendarEventMapping.objects.filter(
            user=user, content_type=content_type, object_id=object_id
        ).first()
        if not mapping:
            return

        service = cls.get_calendar_client(user)
        if service is None:
            mapping.delete()
            return

        try:
            cal_id = user.google_account.calendar_id or "primary"
        except GoogleAccount.DoesNotExist:
            mapping.delete()
            return

        try:
            service.events().delete(calendarId=cal_id, eventId=mapping.google_event_id).execute()
        except Exception:
            logger.exception(
                "Failed to delete Google Calendar event %s for user %s",
                mapping.google_event_id,
                user,
            )
        mapping.delete()

    @classmethod
    def sync_project_due_date(cls, project):
        """Create/update an all-day event for a project's due date."""
        if not project.due_date or not project.assigned_to_id:
            return

        event_body = {
            "summary": f"[Abby] {project.title} due",
            "description": f"Project deadline for {project.assigned_to}",
            "start": {"date": str(project.due_date)},
            # Google Calendar uses an exclusive end for all-day events.
            "end": {"date": str(project.due_date + timedelta(days=1))},
            "reminders": {
                "useDefault": False,
                "overrides": [
                    {"method": "popup", "minutes": 1440},  # 1 day before
                    {"method": "popup", "minutes": 60},  # 1 hour before
                ],
            },
        }
        cls._upsert_event(project.assigned_to, "project_due", project.id, event_body)

    @staticmethod
    def _chore_event_body(chore):
        """Build the same duty event for automatic and manual sync."""
        tz = settings.TIME_ZONE
        today = timezone.localdate()

        # Build recurrence rule based on chore frequency
        if chore.recurrence == "daily":
            rrule = "RRULE:FREQ=DAILY"
        elif chore.recurrence == "weekly":
            rrule = "RRULE:FREQ=WEEKLY"
        else:
            # one_time — no recurrence
            rrule = None

        event_body = {
            "summary": f"[Abby] {chore.title}",
            "description": f"Chore — reward: ${chore.reward_amount}",
            "start": {"date": str(today), "timeZone": tz},
            "end": {"date": str(today + timedelta(days=1)), "timeZone": tz},
            "reminders": {
                "useDefault": False,
                "overrides": [{"method": "popup", "minutes": 30}],
            },
        }
        if rrule:
            event_body["recurrence"] = [rrule]
        return event_body

    @classmethod
    def sync_chore(cls, chore):
        """Create/update a recurring calendar event for eligible children."""
        if not chore.is_active or chore.pending_parent_review or not chore.family_id:
            return

        # The duty's explicit family owns it, even if its creator later moves
        # families. Invalid or outdated assignments must never cross that
        # boundary or deliver child duties to a parent or inactive account.
        children = chore.family.members.filter(role="child", is_active=True)
        if chore.assigned_to_id:
            children = children.filter(pk=chore.assigned_to_id)

        event_body = cls._chore_event_body(chore)
        for child in children:
            cls._upsert_event(child, "chore", chore.id, event_body)

    @classmethod
    def sync_time_entry(cls, time_entry):
        """Create a time block for a completed time entry."""
        if not time_entry.clock_out or not time_entry.user_id:
            return

        from apps.projects.models import Project
        from config.viewsets import filter_projects_accessible_to

        # A historical entry can outlive a project's assignment. Do not
        # export the current title after the user loses project access.
        if not filter_projects_accessible_to(
            time_entry.user, Project.objects.filter(pk=time_entry.project_id),
        ).exists():
            return

        tz = settings.TIME_ZONE
        event_body = {
            "summary": f"[Abby] Worked on: {time_entry.project.title}",
            "start": {
                "dateTime": time_entry.clock_in.isoformat(),
                "timeZone": tz,
            },
            "end": {
                "dateTime": time_entry.clock_out.isoformat(),
                "timeZone": tz,
            },
        }
        cls._upsert_event(time_entry.user, "time_entry", time_entry.id, event_body)

    @classmethod
    def full_sync(cls, user):
        """Manually trigger a full resync of all events for a user."""
        from apps.chores.models import Chore
        from apps.projects.models import Project
        from apps.timecards.models import TimeEntry
        from config.viewsets import filter_projects_accessible_to

        # Sync project due dates
        projects = Project.objects.filter(assigned_to=user, due_date__isnull=False)
        for project in projects:
            cls.sync_project_due_date(project)

        # Sync completed time entries (last 30 days)
        cutoff = timezone.now() - timedelta(days=30)
        entries = TimeEntry.objects.filter(
            user=user, status="completed", clock_out__isnull=False, clock_in__gte=cutoff,
            project__in=filter_projects_accessible_to(user, Project.objects.all()),
        )
        for entry in entries:
            cls.sync_time_entry(entry)

        # Match automatic duty recipients while resyncing only the requesting
        # child's calendar; calling sync_chore here would also touch siblings.
        if user.role != "child" or not user.is_active or not user.family_id:
            return
        chores = Chore.objects.filter(
            family_id=user.family_id, is_active=True, pending_parent_review=False,
        ).filter(Q(assigned_to=user) | Q(assigned_to__isnull=True))
        for chore in chores:
            cls._upsert_event(user, "chore", chore.id, cls._chore_event_body(chore))
