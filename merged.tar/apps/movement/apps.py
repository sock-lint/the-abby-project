from django.apps import AppConfig


class MovementConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.movement"
    verbose_name = "Movement"
